---
name: "precificacao-ncon"
description: "Segunda etapa do fluxo de proposta do NCon (Poli Júnior), chamada pela orquestrador-ncon depois do dimensionamento. Lê o ncon.run, calcula o ITIP, o múltiplo e o preço técnico das opções A (menor) e B (maior, recomendada), com cada fator justificado, valida o preço com o CN e devolve a seção precificacao do run. Não dimensiona, não desenha success fee, não gera o deck e não grava o log."
---

# Precificação NCon (v0.6)

Segunda etapa do fluxo orquestrado: **dimensionamento → precificação → gate do success fee → success fee (se couber) → decisão final → proposta**. Quem chama esta skill é a `orquestrador-ncon`, passando o `ncon.run` (contrato em `orquestrador-ncon/references/contrato-run.md`). Você é a dona da seção `precificacao`.

Esta skill lê o run, calcula o preço técnico de A e B, valida o preço com o Coordenador de Negócios (CN) e devolve o run com a sua seção. Ficam de fora: dimensionar, desenhar success fee, decidir quais estruturas vão ao deck, gerar o deck e gravar o log (tudo da orquestradora ou das outras skills). **Não chame outra skill.**

**Princípios (não negociáveis):**
- O CN sempre tem a palavra final. Há **1 checkpoint obrigatório** (preço). Nunca pule.
- Transparência total: cada número vem com a justificativa e, quando vier da transcrição, com o trecho citado (já está em `run.cliente`).
- Poucas variáveis (80/20): cinco fatores (porte, área, setor, canal, reação na AT). Se o CN não entende o preço, ele não usa.
- **ROI estimado nunca entra no preço.** Pode aparecer na proposta como argumento de valor.
- Na dúvida sobre um fator, use o valor neutro (1,00) e diga isso.
- **Foco na opção B.** A B (maior e mais completa) é sempre a recomendada. A A (menor) ancora a B. **Calcule sempre A e B**, mesmo que a A não vá ao deck: quem decide é a orquestradora com o CN.
- Valores marcados com **(a validar)** são provisórios: use-os, mas sinalize no briefing. Nesta versão, **todos os fatores e todas as bases de ITIP são (a validar)**; os fatores estão na planilha "Fatores de preço NCon", em validação com o CN. Se a planilha validada divergir desta skill, vale a planilha.

## Como perguntar ao CN (questionário)

No checkpoint e nas poucas perguntas da Etapa 1, use a ferramenta de perguntas de múltipla escolha (AskUserQuestion):
- Até 4 perguntas por chamada, 2 a 4 opções cada. A opção "Outro" (texto livre) aparece sozinha: não crie uma.
- Antes do questionário, mostre o resumo em texto; a pergunta precisa se sustentar sozinha, citando o número que está sendo validado.
- Se a sugestão tiver uma opção recomendada, coloque-a primeiro com "(Recomendado)".
- Toda resposta diferente de "De acordo" vira um item em `ajustes_do_cn` (`{campo, de, para, motivo}`). Se o CN ajustou sem dizer o motivo, pergunte o motivo em uma linha.
- Sem a ferramenta (execução agendada), faça as mesmas perguntas por texto, numeradas.

---

## Etapa 1: Entradas do run

Leia, sem buscar nada em Pipedrive, Fathom ou Apollo (isso já foi feito pelo dimensionamento):

- **`run.cliente`:** empresa, canal, setor, faturamento (e faixa), área afetada (core, não-core, misto), interlocutor, sinais de budget e objeção de preço, reação na AT (nota e trechos), visita presencial, se o cliente pediu parte variável, se é pessoa física ou microempresa.
- **`run.dimensionamento`:** portfólio(s) (GP, PM, P&G, GTO, PD ou AI Scan; pode ser híbrido), etapas com semanas, nº de analistas e semanas-analista (sa) de cada opção, escopo de **A** (só essenciais) e de **B** (essenciais + opcionais aplicáveis), `removidos_vs_B`, equipe e prioridade do cliente.
- **`run.validacoes`:** o Checkpoint 1 (dimensionamento) já valeu. Não repita as perguntas dele.

Campos obrigatórios (veja a tabela de passagem do contrato): canal, setor, área, portfólio e `sa`, `semanas` e `analistas` de A e B. Se faltar algum, **devolva à orquestradora com a lista do que falta**; não pergunte ao CN o que o dimensionamento deveria ter trazido. O que pode faltar e você mesma pergunta, em uma pergunta só:
- **Faturamento:** se ausente, peça uma faixa ao CN; não invente. Sem faixa, porte = 1,00, com alerta.
- **Nota de reação na AT:** se `reacao_at.nota` for `null`, pontue pela rubrica da Etapa 2.

## Etapa 2: Reação na AT (0 a 5)

Use a nota de `run.cliente.sinais.reacao_at`; se for `null`, pontue a partir dos `trechos` e dos sinais de budget, pela rubrica abaixo. Mostre 2 a 3 trechos que justificam a nota; o CN pode corrigir no checkpoint.

**Rubrica de reação (0 a 5):**
- 0: cliente desengajado, sem dor clara, sem decisor, reunião morna.
- 1: interesse baixo, dor vaga, decisor ausente, compara só por preço.
- 2: interesse moderado, dor existe, mas sem urgência nem orçamento definido.
- 3: interesse normal, dor clara, decisor presente, sem sinal forte de urgência.
- 4: interesse alto, dor aguda, decisor engajado, pergunta por prazo e próximos passos.
- 5: interesse muito alto, urgência, orçamento sinalizado e pedido de proposta.
- Sinais positivos (+): concorda e complementa o que é proposto; pergunta sobre prazo, início ou próximos passos; traz novas dores ou áreas; decisor presente; menciona budget reservado ou urgência.
- Sinais negativos (−): objeções de preço ou prazo; "vou ver internamente" sem próximo passo; compara com concorrentes; interlocutor sem poder de decisão; respostas curtas ou evasivas.
- Atenção: cordialidade não é concordância. Cliente brasileiro educado não é cliente comprador. Pese ações concretas (pedir proposta rápida, agendar próxima reunião) acima de frases simpáticas.
- Mostre 2 a 3 trechos que justificam a nota. O CN pode corrigir.

## Etapa 3: Precificação

### 3.1 Preço base

```
semanas-analista (sa) = semanas × analistas
Preço base = R$ 1.700 (custo fixo de coordenação) + sa × ITIP_base(portfólio)
```

| Portfólio | ITIP base | Origem |
|---|---|---|
| GTO (Processos e P&G) | R$ 2.100 | Francisco, 14/11 |
| GP e P&G (puros) | R$ 2.100 | Replicam o ITIP de GTO (decisão de 17/11, a validar com um CN). Registre `portfolio_usado = "GTO (replicado)"` |
| PM | R$ 2.150 | Piso da faixa vendida em 2026 (R$ 2.150 a 2.300, 5 vendas). O fixo de R$ 1.700 já eleva o ITIP efetivo. (a validar) |
| PD | R$ 2.500 | Meio da faixa R$ 2.400 a 2.600, sem vendas ainda. Porta de entrada para o Núcleo de Tecnologia; escopo mais técnico. Referência: Arauco, R$ 44.000 em 2 × 8 sa + módulo PM. (a validar) |
| AI Scan | R$ 2.500 | Mesma lógica do PD, sem vendas ainda. As semanas vêm do dimensionamento (2 ou 8). (a validar) |

O custo fixo explica por que projetos de 1 analista têm ITIP implícito alto (Stanley: R$ 3.620). Calibração do banco: preço ≈ R$ 1.700 + R$ 2.130 × sa.

**AI Scan de 2 semanas:** o preço atual é fixo, R$ 8.000 (2 sem × 2 analistas × R$ 2.000, sem múltiplo). A fórmula acima dá cerca de R$ 11.700 antes do múltiplo. Mostre os dois valores no briefing e deixe o CN escolher; não troque o fixo atual sem a confirmação dele.

### 3.2 Múltiplo

Cinco fatores. Todos (a validar) até a planilha de validação voltar do CN.

**Porte (faturamento, vindo de `run.cliente`)**

| Faturamento | Fator |
|---|---|
| até R$ 50M | 0,95 |
| R$ 50M a 500M | 1,00 |
| R$ 500M a 2B | 1,05 |
| R$ 2B a 10B | 1,10 |
| acima de R$ 10B (multinacionais e grandes grupos) | 1,15 |

**Área**

| Área | Fator |
|---|---|
| Core (ligada à geração de receita ou à entrega do produto) | 1,00 |
| Não-core (back office: financeiro, RH, jurídico, TI interna) | 0,95 |
| Misto ou não sei | 1,00 |

**Setor (perfil de margem)**

| Margem | Fator | Setores |
|---|---|---|
| Baixa | 0,95 | logística e transporte; varejo (alimentar, não alimentar e e-commerce, farmacêutico); atacado e distribuição B2B; combustíveis e distribuição de derivados; agronegócio de produção primária e commodities; concessionárias e revenda de veículos e máquinas; serviços intensivos em mão de obra; construção civil e incorporação; construção pesada e infraestrutura; alimentos e bebidas (indústria); têxtil, confecção e calçados; operadoras de planos de saúde; aviação e transporte de passageiros; setor público e terceiro setor |
| Neutra | 1,00 | indústria de transformação em geral (máquinas, bens de capital, material elétrico); materiais de construção e acabamento; química, petroquímica e plásticos; papel, celulose e madeira; embalagens; mineração; siderurgia e metalurgia; indústria automotiva e autopeças; energia elétrica; saneamento e utilities; bioenergia e biocombustíveis; educação; mercado imobiliário e proptech; telecomunicações; mídia, entretenimento e esportes; hotelaria, restaurantes e turismo; bens de consumo e higiene; serviços profissionais e consultoria (inclui engenharia consultiva); franquias e serviços ao consumidor; cooperativas e associações de produtores; **e qualquer setor que não esteja na tabela** |
| Alta | 1,05 | tecnologia e software; data centers e infraestrutura digital; fintechs e meios de pagamento; bancos e instituições financeiras; seguros e previdência; gestoras e mercado de capitais; farmacêutica e biotecnologia; dispositivos e equipamentos médicos; hospitais, clínicas e laboratórios (saúde privada); saúde digital e healthtechs; petróleo e gás; cosméticos e bens de luxo |

Só logística e varejo, como margem baixa, vêm das benchmarks (margem baixa mesmo com faturamento alto). O restante da classificação é julgamento, a validar. Operadoras de planos de saúde ficam na margem baixa mesmo dentro de saúde privada (margens apertadas e regulação forte), exceção também a validar. Setor ausente da tabela: use 1,00 e sinalize no briefing para inclusão.

**Canal de entrada (peso até 5%)**

| Canal | Fator |
|---|---|
| Outbound | 0,97 |
| Inbound | 1,00 |
| Indicação | 1,03 |
| Fidelização | 1,00 |
| Outro ou não sei | 1,00 |

Base: no histórico de 2026, outbound converte cerca de 8%, inbound cerca de 21% e indicação cerca de 18%. O outbound fica no piso. A v0.4 tinha outbound 1,00 e inbound 0,97 (no inbound chegam empresas menores); essa lógica agora é coberta pelo fator de porte. A validar com o CN.

**Reação na AT (peso até 5%)**

| Nota | Fator |
|---|---|
| 0 ou 1 | 0,95 |
| 2 | 0,975 |
| 3 | 1,00 |
| 4 | 1,025 |
| 5 | 1,05 |

**Fora dos fatores:** tipo de trabalho (operacional × analítico) e recorrência (chance de fidelizar) saíram do cálculo em 16/11. ROI estimado também não entra.

```
múltiplo = produto dos cinco fatores, limitado a [0,85 ; 1,25]
Preço técnico do projeto = (Preço base × múltiplo), arredondado para R$ 100
Preço final = Preço técnico do projeto + custo de visita (3.5)
```

No extremo, o produto vai de cerca de 0,79 a 1,31, então as duas travas podem agir em casos extremos.

### 3.3 As 2 opções

O escopo das opções vem do dimensionamento e segue o catálogo de entregáveis da `proposta-ncon` (`references/entregaveis.md`): entregáveis sem a marca "(OPCIONAL)" são essenciais; os marcados "(OPCIONAL)" são opcionais.

- **Opção B, recomendada (maior e mais completa):** essenciais **+ os opcionais aplicáveis ao caso**, com as sa recebidas do dimensionamento. Preço técnico = (1.700 + sa_B × ITIP_base) × múltiplo. É a opção em que o briefing e o CN devem se concentrar.
- **Opção A, enxuta (menor):** só as etapas e os entregáveis **essenciais**, **sem nenhum opcional**, com as sa da A recebidas do dimensionamento. Preço técnico = (1.700 + sa_A × ITIP_base) × múltiplo × 1,05. O prêmio de 5% faz a semana da A sair mais cara que a da B, o que deixa a B mais atraente ("muita diferença de entrega, pouca diferença de preço"). Liste o que sai em relação à B. Se na reunião o CN já tiver prometido um corte por abrangência (ex.: "um valor só para o comercial e outro para a unidade inteira"), a A pode ser esse escopo menor, com o mesmo prêmio de 5%; diga no briefing que a A seguiu o corte prometido.

Não há opção com success fee nesta skill. Se houver sinais de que ele faz sentido (Etapa 4, item 5), a precificação só os sinaliza.

### 3.4 Comercial
- **Escada de negociação:** abrir no preço da opção; concessões possíveis para −5% e −10%, cada uma atrelada a um prazo de fechamento. Descontos acima de 10% só com aprovação dos CPs. As concessões incidem só sobre o preço do projeto, nunca sobre o custo de visita. No histórico de 2026, o desconto não mexe a conversão: use a escada como gatilho de urgência, não como alavanca.
- **Parcelamento:** "em até Nx", com N = 2 + floor(semanas / 4), por opção, sobre o preço final.
- **Outlier:** preço técnico acima de R$ 100k ou múltiplo nos limites (0,85 / 1,25) → sinalizar para validação dos CPs.

### 3.5 Custos de visita presencial (embutidos no preço)

Se o escopo validado tiver visita presencial fora da Grande São Paulo, calcule o custo e **embuta-o no preço de cada opção que inclui a visita**. Ele não aparece separado na proposta ao cliente, só no briefing para o CN.

1. **Pesquise na web** (WebSearch): distância rodoviária e tempo de ônibus a partir de São Paulo; se há voo direto e o preço médio de ida e volta; diária média de hotel em dia útil na cidade.
2. **Modal:** até ~300 km → carro/ônibus, bate-volta se possível. De 300 a 600 km → ônibus noturno ou avião (padrão: avião, se houver voo direto até ~R$ 1.000 ida e volta; mostre o ônibus como alternativa). Acima de 600 km → avião.
3. **Composição por pessoa:** transporte ida e volta + hospedagem (noites = dias de visita, ou dias − 1 com ônibus noturno; 1 quarto por pessoa) + alimentação de R$ 120/dia + transporte local (app até a planta, deslocamento até o aeroporto/rodoviária em SP).
4. **Total** = custo por pessoa × nº de pessoas (padrão: os analistas do projeto) + 10% de contingência, arredondado para R$ 100.
5. O custo de visita **não passa pelo múltiplo** e **não entra nas concessões**.
6. Na Grande SP, considere só transporte (sem hospedagem); em geral é desprezível e pode ser ignorado.

### 3.6 Referências do histórico (para comparar e alertar)

Preços de tabela do banco da `proposta-ncon`, antes de desconto (ITIP implícito = preço ÷ sa):

| Proposta | Portfólio | Analistas × semanas | Preço | ITIP implícito |
|---|---|---|---|---|
| Ascenty | GP | 2 × 7 | R$ 32.100 | R$ 2.293 |
| Sotreq | GP | 2 × 7 | R$ 28.000 | R$ 2.000 |
| Vedacit | GP | 2 × 13 | R$ 54.200 | R$ 2.085 |
| Rayes | GP | 2 × 8 | R$ 32.100 | R$ 2.006 |
| QuintoAndar | GP | 3 × 6 | R$ 34.155 | R$ 1.898 |
| Tenda | GP + P&G | 2 × 9 | R$ 41.400 | R$ 2.300 |
| Tenda | PM | 2 × 6 | R$ 24.100 | R$ 2.008 |
| Bracell | PM | 2 × 5 | R$ 24.100 | R$ 2.410 |
| Stanley | PM | 1 × 5 | R$ 18.100 | R$ 3.620 |
| Mercosul | PM | 1 × 7 | R$ 15.300 | R$ 2.186 |
| T4S | P&G | 2 × 12 | R$ 56.160 | R$ 2.340 |
| FS | P&G | 2 × 7 | R$ 28.200 | R$ 2.014 |
| Arauco | PD | 2 × 8 (+ 1 PM) | R$ 44.000 | R$ 2.750 |

Histórico de 2026 (Pipedrive × decks, 29 vendas limpas; amostras pequenas, com viés de seleção possível):
- ITIP das vendas de GP: mediana R$ 2.000 (P25 1.899, P75 2.067). PM vendidas: R$ 2.171 (5 vendas).
- ITIP efetivo entre R$ 1.800 e 2.000 converte cerca de 23%; a partir de R$ 2.200, cerca de 5 a 9%.
- Propostas de R$ 50 a 70 mil convertem cerca de 21%, contra 8 a 9% nas de R$ 20 a 40 mil. Escopo maior vende melhor que escopo barato, o que reforça o foco na B.

**Alerta de ITIP:** calcule o **ITIP efetivo** de cada opção (preço técnico do projeto ÷ sa, sem a visita). Acima de R$ 2.400, sinalize no briefing. Mostre sempre o ITIP efetivo ao lado da mediana de R$ 2.000 das vendas de GP. Atenção: o custo fixo de R$ 1.700 eleva o ITIP efetivo (em 2 × 8 sa de GTO, com múltiplo 1,00, o efetivo é R$ 2.206).

## Etapa 4: Briefing → CHECKPOINT

Mostre ao CN:
1. Tabela de fatores: valor, justificativa, evidência (marque os "(a validar)").
2. As 2 opções lado a lado: escopo (essenciais × opcionais), semanas × analistas, preço do projeto, custo de visita embutido, preço final, parcelas, ITIP efetivo (sem a visita), concessões.
3. Comparação com o banco (propostas parecidas e seus ITIPs, Etapa 3.6).
4. Alertas: dados faltando, fatores neutros por falta de informação, outliers, ITIP efetivo acima de R$ 2.400, AI Scan de 2 semanas (fixo atual × fórmula).
5. **Sinais para o success fee** (só sinalização; quem decide é o gate da orquestradora). Marque `sugerir = true` se houver ao menos um:
   - porte pequeno (faturamento abaixo de R$ 50M);
   - budget reduzido sinalizado, ou objeção de preço na AT;
   - canal inbound (barreira de entrada mais baixa);
   - cliente pessoa física ou microempresa;
   - cliente pediu para pagar por resultado.

   Liste os sinais encontrados, com o trecho quando houver. A elegibilidade (indicador mensurável, baseline, decisor) é verificada pela `success-fee`, não aqui.

**Checkpoint (questionário):**
1. "Opção B a R$ [preço final] (projeto R$ [x] + visita R$ [y]). De acordo?" → De acordo (Recomendado) · Ajustar um fator · Ajustar o preço final
2. "Modal da visita?" (só se houver visita) → Avião (R$ [x]) · Ônibus (R$ [y])

Ajuste de preço ou de fator → recalcule, mostre de novo só o que mudou e confirme.

## Etapa 5: Resultado da precificação

Com o OK do checkpoint, entregue o resultado em Markdown (briefing do CN) e, depois dele, o **mesmo resultado em JSON**: o run completo (`cliente` e `dimensionamento` como vieram) mais a seção `precificacao`. O JSON é a fonte: a orquestradora, a `success-fee` e a `proposta-ncon` leem dele, e nenhum número pode existir só no texto.

```
RESULTADO DA PRECIFICAÇÃO (precificacao-ncon v0.6)
empresa:
portfólio:
canal:
fatores: porte=…, área=…, setor=…, canal=…, reação=… (cada um com a justificativa e o status "a validar" ou "validado")
múltiplo bruto / aplicado:
ITIP base:
opção A: sa=…, semanas=…, analistas=…, preço do projeto=…, visita=…, preço final=…, parcelas="em até Nx", ITIP efetivo=…
opção B (recomendada): idem
escada de negociação: −5% e −10% por opção, cada uma com prazo de fechamento; acima de 10%, CPs
alertas: …
sugerir success fee: sim | não (com os sinais)
decisão do CN: o que ele ajustou e por quê
```

Seção `precificacao` do JSON: `itip_base` (valor, portfólio usado, status), `custo_fixo`, `fatores` (nome, valor, justificativa, evidência, status "a_validar" ou "validado"), `multiplo` (bruto, aplicado, travado), `opcoes` A e B (id, `recomendada`, sa, preço do projeto, visita, preço final, `parcelas_max`, ITIP efetivo e a escada de concessões com `desconto_pct`, preço e `prazo_fechamento`), `comparacao_banco`, `sinais_success_fee` (`sugerir` e os `motivos` com trecho: porte_pequeno, budget_reduzido, objecao_preco, inbound, pessoa_fisica, cliente_pediu), `outlier` e `ajustes_do_cn`. Acrescente `precificacao` a `etapas_concluidas` e o checkpoint de preço a `validacoes`. Desconhecido = `null`; nunca invente.

## Itens provisórios a validar com um CN

| Item | O que está na skill | Origem |
|---|---|---|
| Todos os fatores | Valores da Etapa 3.2 | Planilha "Fatores de preço NCon", em validação com o CN |
| ITIP base de PM, PD e AI Scan | R$ 2.150, R$ 2.500 e R$ 2.500 | Histórico de 2026, sem vendas de PD e AI Scan; 17/11 |
| Faixa de porte acima de R$ 10B | 1,15 | Francisco, 14/11 |
| Custo de visita | R$ 120/dia de alimentação, 10% de contingência, 1 quarto por pessoa, avião como padrão entre 300 e 600 km | Sugestão do Claude, 14/11, a partir do caso Mosaic |
| Regra da opção A | Só essenciais do catálogo; B = essenciais + opcionais aplicáveis; ou corte por abrangência, se prometido na reunião | Francisco, 14/11; caso Concremat, 15/11 |
| Custo fixo de R$ 1.700 | Mantido, apesar de elevar o ITIP efetivo acima da mediana de R$ 2.000 das vendas de GP | Decisão de 17/11 |

**Ainda em aberto:** AI Scan de 2 semanas (preço fixo) ou 6 a 8 semanas, a validar com um CN; reconciliar o custo fixo de R$ 1.700 com o ITIP efetivo do histórico.
