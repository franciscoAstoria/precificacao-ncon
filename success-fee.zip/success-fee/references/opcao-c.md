# Opção C: métodos de cálculo, fórmula, modelos e exemplos (success-fee v1.3)

Material de apoio das Etapas 2 e 3 (filtros de elegibilidade e do k) e da Etapa 4 (fórmula da C) da skill `success-fee`. Todos os parâmetros são provisórios **(a validar)**: calibrar no backtest e validar com um CN. Os exemplos são hipotéticos, sem visita presencial, e não vêm de nenhum cliente real.

---

## 1. Catálogo de métodos de cálculo do retorno

A C só existe se houver um método **definido, mensurável e aceito pelo cliente**. Escolha o método a partir do indicador da ficha. G = ganho capturado, medido depois do projeto, dentro da janela W. Estimativa de ROI feita antes do projeto **não é método**.

| # | Método | Ganho G | Dado necessário | Risco principal | Portfólio típico |
|---|---|---|---|---|---|
| 1 | Redução de custo unitário | (custo unitário do baseline ajustado − custo unitário realizado) × volume realizado | custo por unidade e volume, mês a mês | insumos (combustível, reajustes), mix e volume: ajustar no protocolo | GTO |
| 2 | Perda, retrabalho, avaria ou refugo | (taxa do baseline − taxa realizada) × volume × custo médio por ocorrência | taxa histórica e custo por ocorrência | mudança de critério de contagem | GTO, AI Scan |
| 3 | Horas convertidas em caixa | horas efetivamente eliminadas × custo-hora, **só quando viram caixa** (hora extra evitada, contratação evitada, terceiro cortado) | folha, horas extras, contratos | disputa alta: hora "liberada" sem destino não conta | GTO, AI Scan |
| 4 | Capital de giro ou estoque | (saldo ou prazo do baseline − realizado) × custo de capital no período | saldos e taxa de custo de capital | sazonalidade | GTO |
| 5 | Receita ou margem incremental | (conversão ou ticket realizado − baseline) × volume × margem | funil comercial e margem | atribuição frágil (mercado, campanhas): só com período comparável ou grupo de controle | uso excepcional |
| 6 | Custo mensal do gargalo | custo mensal do gargalo (Matriz de Dimensionamento de Gargalos do AI Scan) × % de redução medida após a solução | Matriz de Gargalos como baseline | o ganho só aparece se o Núcleo de Dados executar a solução, e a EJ não controla isso; conflito de interesse (quem recomenda também é medido) | AI Scan |
| 7 | KPI sem conversão para R$ | não há G; usar o modelo de atingimento de KPI (seção 4) | série histórica do KPI | metas que o cliente consiga manipular | GTO, PD |
| 8 | Sem método claro, só estimativa ou ROI projetado | **C eliminada** | n/a | n/a | n/a |

PM nunca tem C.

## 2. Protocolo de Mensuração (bloco padrão, obrigatório se a C for apresentada)

Cada campo precisa estar preenchido antes de gerar o deck:

1. **Unidade principal e fórmula** do ganho (um dos métodos da seção 1).
2. **Baseline:** período, fonte do dado e quem fornece; ajustes permitidos e a fórmula de cada um (volume, preço de insumo, reajustes, mix).
3. **Trava de serviço:** indicador de qualidade que não pode piorar (ex.: OTIF, devoluções, avarias). Se piorar, a economia correspondente não conta.
4. **O que conta:** só ganho capturado (realizado), nunca identificado ou estimado. Funil: identificada → validada → implementada → capturada; só a última gera fee.
5. **Iniciativa e janela W:** o ganho é contado por iniciativa, a partir da entrada em operação, por W meses (6 a 12, a validar).
6. **Quem aceita e prazo:** responsável no cliente (controladoria ou financeiro) e prazo de aceite.
7. **Apuração e faturamento:** periodicidade (ex.: mensal para apurar, trimestral para faturar).
8. **Disputa:** rito definido em contrato (rodada de validação entre o responsável da Poli e o do cliente, escalada aos CPs).
9. **Exclusões:** o que fica fora do cálculo (eventos extraordinários, mudanças de escopo do cliente).
10. **Teto e piso:** o teto é obrigatório; o piso é o fixo.

---

## 3. Modelo padrão: ganho compartilhado (gainshare linear)

```
B   = preço técnico do projeto da candidata B (sem visita)
F   = φ × B + custo de visita                      → parte fixa
p   = (1 + λ) × (1 − φ) / (n − H/B)                → percentual da fee
V   = min( p × max(0, G − H) , (k − φ) × B )       → parte variável
Total C = F + V
```

| Parâmetro | Significado | Valor inicial (a validar) |
|---|---|---|
| φ | fração de B que fica fixa | 60% (faixa 50 a 70%) |
| λ | prêmio de risco proporcional ao risco assumido | 0,25 |
| n | múltiplo de B que o projeto precisa capturar para a C chegar à meta | 5 |
| k | teto do projeto, em múltiplos de B | 1,25 / 1,5 / 2,0, escolhido pelo filtro de direcionamento (seção 8); padrão 1,5 |
| H | franquia: ganho que o cliente teria sem o projeto | 0 |
| W | janela de reconhecimento por iniciativa | 6 a 12 meses |
| φ_min | menor fixo permitido | 50% de B, provisório até o time definir o custo por semana-analista |

O **n** é parâmetro de política, não estimativa de ROI do cliente.

**Propriedades (com H = 0):**
- Meta: em G = n×B, o total é B × (1 + λ × (1 − φ)).
- Break-even contra B: G = n/(1 + λ) × B, qualquer que seja o φ: **4 × B** com n = 5 (3,2 × B com n = 4; 4,8 × B com n = 6).
- Fee máxima: (k − φ) × B, atingida em G = (k − φ) × B / p.
- Com H > 0 a conta de p já compensa a franquia: a meta continua em G = n×B.

**Percentual da fee por φ e n (λ = 0,25, H = 0):**

| φ (fixo) | n = 4 | n = 5 | n = 6 |
|---|---|---|---|
| 70% | 9,4% | 7,5% | 6,3% |
| 60% | 12,5% | **10,0%** | 8,3% |
| 50% | 15,6% | 12,5% | 10,4% |

p acima de 10% é sinalizado para os CPs.

Os exemplos 1 a 6 usam k = 1,5 (padrão). Com o filtro de direcionamento (seção 8), o teto pode ser 1,25 ou 2,0.

### Exemplo 1: GTO médio (2 analistas × 10 semanas, φ = 60%, n = 5)

B ≈ R$ 46.000. F = 0,60 × 46.000 = **R$ 27.600**, em até 4x (N = 2 + ⌊10/4⌋). p = 1,25 × 0,40 / 5 = **10%**. Teto: fee máxima = (1,5 − 0,6) × 46.000 = R$ 41.400, atingida com G = R$ 414.000.

| Ganho capturado (G) | Fixo | Fee | Total | vs B |
|---|---|---|---|---|
| R$ 0 | 27.600 | 0 | 27.600 | −40% |
| R$ 92.000 (2×B) | 27.600 | 9.200 | 36.800 | −20% |
| **R$ 184.000 (4×B)** | 27.600 | 18.400 | **46.000** | **= B** |
| R$ 230.000 (5×B) | 27.600 | 23.000 | 50.600 | +10% |
| R$ 414.000 ou mais | 27.600 | 41.400 | 69.000 | +50% (teto) |

Apuração real: custo por unidade de R$ 10,00 no baseline ajustado e R$ 9,40 realizado, 600.000 unidades. G = 0,60 × 600.000 = R$ 360.000. Fee = 10% × 360.000 = R$ 36.000. Total = **R$ 63.600** (1,38 × B). Se a economia *identificada* fosse R$ 600.000 mas só R$ 360.000 fossem capturados, só os R$ 360.000 contam.

Frase para o cliente: "Você paga R$ 27,6 mil pelo projeto e 10% do que for economizado de fato. Se o projeto capturar R$ 184 mil, você paga o mesmo que no preço fechado. Abaixo disso, paga menos."

### Exemplo 2: GTO grande, medição forte (56 sa, φ = 55%, n = 6)

B ≈ R$ 125.000. Indicador já medido, baseline acessível, decisor na AT: o CN reduz o fixo para 55% e sobe n para 6 (justificativa registrada). F = **R$ 68.750**. p = 1,25 × 0,45 / 6 = **9,4%**. Fee máxima = 0,95 × 125.000 = R$ 118.750 (G ≈ R$ 1,27M). Break-even: 4,8 × B = R$ 600.000.

| G | Total | vs B |
|---|---|---|
| R$ 0 | 68.750 | −45% |
| R$ 600.000 | 125.000 | = B |
| R$ 750.000 | 139.062 | +11% |
| R$ 1,27M ou mais | 187.500 | +50% (teto) |

Flag: φ abaixo de 60% vai para os CPs. Com n = 5, p subiria para 11,25% (acima de 10%): a saída é justificar o n = 6 ou voltar para φ = 60%.

### Exemplo 3: cliente pede fixo muito baixo (12 sa, B = R$ 26.900)

O cliente propõe 40% fixo (R$ 10.760), abaixo do piso de 50% (R$ 13.450): **a skill recusa**. Contraproposta φ = 50%: p = 12,5%, acima de 10%, vai para os CPs. Alternativa recomendada, φ = 60%: F = R$ 16.140, p = 10%, break-even em R$ 107.600. O briefing mostra as duas e recomenda a segunda: "projeto pequeno, pouco espaço para risco".

### Exemplo 4: negociação (exemplo 1)

Desconto de 10% só sobre o fixo: F = R$ 24.840, p continua 10%. O break-even sobe para R$ 211.600, porque a fee precisa cobrir R$ 21.160 de diferença para B. Na prática o desconto vira risco adicional para a EJ. Esse é o limite sem aprovação; mais que isso, ou remover o teto, exige os CPs. Plano B interno (só no briefing): se o cliente rejeitar a fee, voltar para a B de R$ 46.000.

### Exemplo 5: C eliminada pelo filtro

O cliente quer "reduzir custo de expedição", mas diz que não mede o custo por unidade hoje. Na pergunta 2 do filtro, a resposta é "Não existe medição": a C sai dos candidatos. O briefing mostra A e B, diz o motivo ("sem baseline, qualquer ganho seria contestado") e o que faria a C voltar: pelo menos 6 meses de histórico do indicador, ou baseline medido antes do início e aceito pela controladoria.


### Exemplo 6: teste de sanidade com o mesmo B e portes diferentes

B = R$ 40.000 (16 sa, sem visita), φ = 70%, n = 5, k = 1,5 (padrão, sem respostas do filtro do k), W = 12 meses. Dor de logística, custo logístico de 9,5% da receita, alcance de 10%, realização de 53% (só diagnóstico e plano). p de política = 7,5%; fixo R$ 28.000; break-even em R$ 160.000; teto do total R$ 60.000. O ganho é o estimado top-down (a validar):

| Cliente (faturamento, alcance) | Ganho anual pessimista / realista / otimista | Total nos 3 cenários | Flag |
|---|---|---|---|
| R$ 2 bi, 10% | R$ 201 mil / 504 mil / 1,01 mi | 43.105 / 60.000 / 60.000 | variável pessimista em 54% do fixo, acima de 40%: p folgado; `p_referencia` = 4,2% |
| R$ 2 bi, 2% (rede com unidade única) | R$ 40 mil / 101 mil / 201 mil | 31.021 / 35.552 / 43.105 | variável pessimista em 11% do fixo, abaixo de 20%; cobrança total acima de 25% do ganho realista; o fixo sozinho já passa do limite: **a C não compensa**, volte para a B |
| R$ 8 bi, 10% | R$ 806 mil / 2,0 mi / 4,0 mi | 60.000 nos três | **DEGENERADA**: o teto prende até no pessimista; o percentual não importa, é um preço fixo disfarçado. Recomende a B ou revise o alcance |

Leitura: o mesmo B e a mesma política dão resultados muito diferentes conforme o porte e o alcance estimados, e o alcance é um julgamento. Por isso o teste só sinaliza, e o CN decide no Checkpoint 2.

---

## 4. Outros modelos (escolher conforme o tipo de indicador)

Nos três modelos abaixo, o **pool** é o valor máximo da parte variável na meta: pool = (1 + λ) × (1 − φ) × B. Com φ = 60%, o pool é 0,5 × B.

| Modelo | Fórmula da fee V | Quando usar | Risco principal |
|---|---|---|---|
| **Ganho compartilhado** (seção 3, padrão) | p × (G − H), com teto | ganho em R$ mensurável (métodos 1 a 4) | disputa sobre a medição |
| **Atingimento de KPI** | V = pool × Σ wₖ·aₖ, com aₖ = clip((xₖ − x_min)/(x_meta − x_min), 0, 1) e Σwₖ = 1 | resultado sem conversão para R$ (lead time, OTIF, taxa de erro; método 7) | metas que o cliente consiga manipular |
| **Marcos binários** | V = Σ bₖ × 1[marco k atingido], com Σbₖ = pool | PD e AI Scan, com entregas verificáveis | tudo ou nada gera atrito |
| **Escalonado** | V = p₁·min(G,G₁) + p₂·faixa 2 + p₃·faixa 3, com p₂ ≈ p₁/2 e p₃ ≈ p₂/2; calibrar p₁ para a receita em G = n×B ficar igual à da fórmula linear **(a validar)** | resultado muito incerto, cliente que quer dividir o upside | complexidade no slide |
| **Fixo = escopo essencial** | F = preço da A sem o prêmio de 5% + visita; φ efetivo = F/B; p pela fórmula da seção 3 | só quando (B − A)/B ≥ 25%; a narrativa é "fixo pelo que é certo, resultado pelo adicional" | se os opcionais forem pequenos, o fixo fica perto de B e a redução quase não aparece |

**Não implementados na v0.5 (avaliar com os CPs):**
- **Conversão para outro núcleo** (fee sobre projetos de Tecnologia ou Dados contratados depois de PD ou AI Scan): risco de conflito de interesse, porque o diagnóstico pode inflar recomendações. Se for implementado, pagar sobre ganho realizado do projeto executado, nunca sobre valor contratado.
- **Garantia com devolução (refund):** piora o caixa da EJ, e a gestão muda todo ano.

## 5. Modelo por portfólio

| Portfólio | Modelo principal | Observação |
|---|---|---|
| GTO | ganho compartilhado quando há R$ medido; atingimento de KPI quando a métrica é operacional | |
| PD | marcos binários ou atingimento de KPI | o ganho em R$ aparece tarde e é difícil de atribuir |
| AI Scan | ganho compartilhado sobre o baseline da Matriz de Gargalos | ver risco do método 6 |
| PM | sem C | |

---

## 6. Fórmulas das análises próprias do briefing

Hipotéticas e sem visita, usando o exemplo 1 (B = R$ 46.000, 20 sa, φ = 60%, n = 5).

| Análise | Fórmula | Exemplo |
|---|---|---|
| Exposição da EJ com G = 0 | B − F, e (1 − φ) em % | 46.000 − 27.600 = R$ 18.400 (40%) |
| ITIP efetivo da C com G = 0 | (φ × B − 1.700) / sa, sem visita; comparar com R$ 1.800 | (27.600 − 1.700) / 20 = R$ 1.295, abaixo do menor ITIP do banco: a EJ só chega perto do preço normal se houver ganho |
| Break-even | G_be = n/(1 + λ) × B (H = 0) | 4 × 46.000 = R$ 184.000 |
| Melhoria necessária | m = G_be / (X × W/12), com X = custo anual do processo ou indicador citado pelo cliente e W a janela em meses | X = R$ 2M, W = 12: m = 9,2%. Comparar com os cases do institucional |
| Break-even sobre faturamento | G_be / faturamento anual | só como ordem de grandeza (Apollo ou faixa do CN) |
| Sensibilidade | p = (1 + λ)(1 − φ)/n e G_be para φ = 50/60/70% e n = 4/5/6 | tabela da seção 3 |

Sem X (o cliente não citou o custo do processo), não estime: peça uma faixa ao CN ou mostre só o break-even em R$.

---

## 7. Script e leitura do teste de sanidade

`scripts/calcula_c.py` faz toda a conta da C: política (fixo, p, break-even, meta, teto, tabela de receita, guardrails) e, se receber os argumentos de estimativa, o teste de sanidade com 3 cenários. Os exemplos 1 a 5 desta referência reproduzem exatamente com ele:

```bash
python scripts/calcula_c.py --B 46000 --sa 20                       # exemplo 1
python scripts/calcula_c.py --B 125000 --phi 0.55 --n 6             # exemplo 2
python scripts/calcula_c.py --B 40000 --sa 16 --phi 0.7 --dor logistica --faturamento 2e9 \
    --custo-log 0.095 --alcance 0.10 --realizacao 0.53 --W 12       # exemplo 6, primeira linha
```

Como o p de referência é calculado: `alvo médio (30%) × fixo do projeto ÷ ganho pessimista na janela`, limitado a 3% a 10%. É só uma referência para o CN. O p de política prevalece, porque o ganho pessimista depende do alcance, e o alcance é o dado mais frágil de toda a estimativa.

---

## 8. Filtro de direcionamento do k: exemplos

O k é escolhido por 5 sinais: baseline, dependência do cliente (do filtro de elegibilidade), atribuição, fonte do dado e sensibilidade a preço (do filtro do k). Qualquer fraqueza dá 1,25; as 4 forças dão 2,0 (CPs); o resto dá 1,5; cliente sensível a preço desce um nível. B = R$ 46.000, sem visita.

| Caso | Respostas | k | Variável máx. | Total máx. |
|---|---|---|---|---|
| Medição forte | baseline com histórico, ganho pouco dependente do cliente, atribuição sim, dado em sistema, cliente sem sinal de preço (φ = 60%) | **2,0** (CPs) | R$ 64.400 | R$ 92.000 |
| Medição forte, cliente compara propostas | as mesmas, com cliente sensível a preço (φ = 60%) | **1,5** | R$ 41.400 | R$ 69.000 |
| Medição mista | baseline com histórico, ganho pouco dependente do cliente, atribuição em parte, dado em planilha (φ = 60%) | **1,5** | R$ 41.400 | R$ 69.000 |
| Medição mista, cliente sensível a preço | as mesmas, com cliente sensível a preço (φ = 60%) | **1,25** | R$ 29.900 | R$ 57.500 |
| Medição fraca | baseline parcial, ganho muito dependente do cliente, atribuição em parte, dado em planilha (φ = 70%) | **1,25** | R$ 25.300 | R$ 57.500 |

Pelo script, o caso "medição fraca" é:

```bash
python scripts/calcula_c.py --B 46000 --phi 0.7 --baseline parcial --dependencia muito \
    --atribuicao parte --fonte planilha --cliente-sensivel-preco nao
```

Com B = R$ 36.900, visita de R$ 4.800 e os mesmos sinais de medição fraca, o variável máximo é R$ 20.295 e o total máximo R$ 50.925 (a visita entra no fixo e fica fora do teto). A meta (R$ 44.468) cabe no teto.

Se o CN usar um k diferente do sugerido (`--k`), o script avisa e o motivo vai para o log. O k = 2,0 sempre gera aviso de CPs.


---

## 9. Argumentos do script vindos da `success-fee` v14

| Argumento | Para que serve |
|---|---|
| `--pessoas N --custo-pessoa R$` | pool por pessoas (multinacional), com `--dor processos` ou `ia`; substitui `--faturamento`, `--sga` e `--fatia` |
| `--budget-min`, `--budget-p25`, `--budget-mediana`, `--budget-p75` | valores do portfólio vindos de `scripts/budget_losts.py`; o script classifica o fixo e o total máximo em zonas de perdas por orçamento (só informativo) |

Saídas novas: `politica.variavel_max_pct_B` (avisa acima de 50%), `politica.perdas_por_orcamento` e `teste_de_sanidade.p_alternativas`: o p de política e o p calibrado no ganho pessimista, no realista e no otimista, cada um com variável e total nos 3 cenários.

```bash
python scripts/calcula_c.py --B 36900 --visita 4800 --phi 0.7 --baseline parcial --dependencia muito \
    --atribuicao parte --fonte planilha --cliente-sensivel-preco nao --sa 16 \
    --budget-min 12100 --budget-p25 27022 --budget-mediana 29750 --budget-p75 34850
```

Com B = R$ 36.900, φ = 70% e k = 1,25, o fixo cobrado (R$ 30.630) e o total máximo (R$ 50.925) ficam acima da mediana das propostas de GP perdidas por Budget (R$ 29.750), e o variável máximo é 55% de B. São avisos informativos: a decisão é do CN.

---

## 10. Arquétipo C2 (diagnóstico + implantação + comprovação): exemplo hipotético

Valores **hipotéticos**, não são dados da Mantiqueira. B = R$ 125.000 já inclui a Fase 2 (Fase 1: 30 sa; Fase 2: 26 sa), sem visita, φ = 70%, filtro com 4 forças menos a atribuição ("em parte"), então k = 1,5.

```bash
python scripts/calcula_c.py --B 125000 --phi 0.7 --sa-fase1 30 --sa-fase2 26 \
    --baseline sim --dependencia pouco --atribuicao parte --fonte sistema
```

Fixo do projeto R$ 87.500, dividido por semanas-analista: R$ 46.875 na Fase 1 e R$ 40.625 na Fase 2 (a visita, se houver, entra na Fase 1). p = 7,5% e k = 1,5, então o variável máximo é R$ 100.000 (0,8 × B) e o total máximo R$ 187.500. A janela W conta por iniciativa a partir da entrada em operação, a apuração é mensal em comitê e o faturamento da fee, trimestral, conforme o Protocolo de Mensuração.
