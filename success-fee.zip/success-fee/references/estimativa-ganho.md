# Estimativa de ganho (top-down): opções, parâmetros, exemplos e origem

> **Uso na `success-fee`.** Este arquivo vem da antiga skill `success-fee` (quiz de precificação), agora o teste de sanidade da skill (Etapa 4). **Use** os blocos 2 e 5 a 10 (estimativa de ganho, que só testa o percentual) e as perguntas extras no fim (alvo de variável pessimista e limite de cobrança total). **Os blocos 1 a 4 (fixo, duração, percentual e teto do variável) estão superados** por `references/opcao-c.md`: o percentual vem da fórmula de política, não do ganho estimado. Mapeamento: fixo → φ; duração T → janela W; teto "variável ≤ x × preço" → k = φ + x. A opção de teto de 25% do preço (k = 0,85 a 0,95) deixa a EJ abaixo de B e **não é usada**. Os blocos 1 a 4 ficam aqui só como histórico das opções e exemplos.

Tudo marcado "(a validar)" é julgamento nosso. "Fonte" indica número de fonte secundária. Não há método público da McKinsey, BCG ou Bain com esses números. Exemplos de propostas são lidos do Drive e do Pipedrive. Onde o escopo exato não foi confirmado, está escrito "confirmar".

Fórmula: `Ganho anual = Faturamento × c_pool(setor, dor) × alcance × melhoria × headroom × realização`, com trava `ganho ≤ pool × alcance × 15–30%`. Três cenários (pessimista, realista, otimista). Mostrar ao cliente só ordem de grandeza e só se o pessimista for maior que 1× o preço.

## Bloco 1: success fee (opção C)

### 1. Fixo (quanto do preço técnico o fixo cobre)
| Opção | Parâmetro | Escolha se | Exemplo | Origem |
|---|---|---|---|---|
| ~100% | variável é bônus | ganho grande e mensurável, e o fixo já paga o projeto | Mantiqueira (R$115,9k) | Julgamento |
| 60–70% | fixo = 0,60–0,70 × preço | risco moderado; baseline ainda a montar | ABB GP/CD (R$54,2k) | Skill v0.4 |
| 40–50% | fixo = 0,40–0,50 × preço | indicador direto e baseline fácil; exige aprovação | Concremat (R$24,1k) | Julgamento |

### 2. Duração T da apuração
| Opção | Parâmetro | Escolha se | Exemplo | Origem |
|---|---|---|---|---|
| Maturação + 6 meses, máx. 12 | T = prazo de maturação + 6, teto 12 | a economia só aparece após implantar | Mantiqueira (10 sem + 8 sem de implantação) | Julgamento; RD Station começa no 6º mês |
| 6 meses após a operação | T = 6 | ganho rápido, sem sazonalidade | Concremat | Caso Mantiqueira |
| 12 meses fixos | T = 12 | indicador sazonal, precisa de ciclo completo | ABB GP/CD | Fonte: padrão sênior 12–24 meses |
| 18–24 meses | T = 18–24 | redesenho de rede ou ativos; ultrapassa o teto da EJ | nenhum caso nosso | Fonte |

### 3. Percentual p sobre a economia capturada (vs. baseline do contrato)
| Opção | Parâmetro | Escolha se | Exemplo | Origem |
|---|---|---|---|---|
| 5–10% | p = 5–10% | fixo de 60–100% e ganho relevante | Mantiqueira | Contexto: NDados 3–15% |
| 3–5% | p = 3–5% | economia de milhões por ano | ABB, se as perdas se confirmarem | Contexto: Bastos/Brandão 3,5–5%; agências 1,5–4% |
| 10–20% | p = 10–20% | ticket e ganho pequenos, indicador direto | Concremat | Fonte: sênior 10–50% com fee quase todo em risco |
| Calcular pela regra | p = alvo × Fixo / (Ganho pessimista × T/12), limitado a 3–10% | já existe ganho pessimista do top-down | Mantiqueira (R$0,83M/ano) | Julgamento |

Sugestão (a validar): ganho pessimista abaixo de ~R$0,3M/ano usa 10–20%; acima disso, 3–10% ou a regra. Com p alto e ganho grande, o teto passa a decidir sozinho.

### 4. Teto do variável
| Opção | Parâmetro | Escolha se | Exemplo | Origem |
|---|---|---|---|---|
| Até 50% do preço técnico | variável ≤ 0,50 × preço técnico (R$57,95k na Mantiqueira) | padrão, baseline razoável | Mantiqueira | Julgamento (ajustado: antes era "50% do fixo") |
| Até 25% do preço técnico | variável ≤ 0,25 × preço técnico | baseline ainda será construído | ABB GP/CD | Julgamento |
| Até 100% do preço técnico | variável ≤ 1,00 × preço técnico | ganho muito mensurável, ticket baixo; exige indicador A | Concremat | Julgamento |
| Escalonado | p menor nas faixas altas | ganho pode ser muito grande | porte da Mantiqueira | Fonte parcial (tightship); faixas a definir |

## Bloco 2: estimativa de ganho (top-down por porte)

### 5. Dor principal (c_pool e melhoria)
| Opção | Parâmetro | Escolha se | Exemplo | Origem |
|---|---|---|---|---|
| Logística e transporte | c_pool = custo logístico/receita (média 9,5%, de 3% a 19,8%); melhoria 2/5/10% | o dinheiro está em frete, armazenagem, perdas | Mantiqueira; ABB GP/CD | ILOS; melhoria é leitura do C.H. Robinson |
| Processos manuais e back office | c_pool = SG&A do setor × fatia da área; melhoria 30–40% só sobre a parte manual | o ganho é tempo de equipe | GP de área administrativa (nenhuma das 4 propostas lidas é puro back office) | Umbrex; 30–40% é exemplo, não benchmark |
| Automação, IA e dados | c_pool = custo do processo automatizável; melhoria 20/27,5/35% | o ganho é trocar trabalho manual por sistema | Concremat GP com IA | McKinsey 2017, não auditado |
| Decisão de mercado (PM) | sem top-down; usar a decisão em jogo | o produto é uma decisão | Ânima PM (R$48k) | Sem benchmark |

### 6. Alcance
| Opção | Parâmetro | Escolha se | Exemplo | Origem |
|---|---|---|---|---|
| Piloto pequeno | 10% | um CD, uma rota ou uma equipe | escopo de um único CD (confirmar na ABB) | Julgamento |
| Unidade única em rede grande | 1 ÷ nº de unidades (ex.: 1 de 45 lojas ≈ 2%) | uma loja, filial ou CD numa rede com dezenas de unidades; **use em vez do piloto de 10%** | confirmar | Julgamento (a validar); aprendizado do backtest Tenda, 16/11 |
| Unidade ou regional | 25% | uma planta ou região | confirmar | Julgamento |
| Área inteira | 50% | uma diretoria ou toda a área | confirmar | Julgamento |
| Empresa toda | 100% | transformação completa | confirmar | Julgamento |

### 7. Entrega (realização)

> **Não é pergunta na `success-fee`.** A realização é derivada do escopo vindo do dimensionamento: só diagnóstico e plano = 53%; plano + acompanhamento no escopo = 70%; implantação assistida + medição (Fase 2) = 85%. A tabela abaixo serve de referência desses três valores.
| Opção | Parâmetro | Escolha se | Exemplo | Origem |
|---|---|---|---|---|
| Só diagnóstico e plano | 53% | o cliente executa sozinho | Mantiqueira, só a Fase 1 | McKinsey: 1/3 perdido no planejamento e 20% na execução |
| Plano + acompanhamento | 70% | acompanhamos, mas sem medição formal | confirmar | Umbrex: piso de 70–85% |
| Implantação assistida + medição | 85% | implantamos e medimos com protocolo | Mantiqueira, Fase 1 + Fase 2 (Protocolo de Mensuração) | Umbrex: teto de 70–85% |

### 8. Headroom
| Opção | Parâmetro | Escolha se | Exemplo | Origem |
|---|---|---|---|---|
| Já madura e otimizada | melhoria × 0,6 | já tem sistema e indicadores acompanhados | cliente com TMS/WMS e KPIs rodando | Julgamento (a validar) |
| Intermediária ou não sei | melhoria × 1,0 | na dúvida, neutro | padrão | Regra do "na dúvida" |
| Fragmentada, com desperdício óbvio | melhoria × 1,5 | perdas sem medição, processo manual solto | ABB: "perdas na casa dos milhões" | Julgamento (a validar) |

### 9. Fatia da área (novo; para processos e IA)
| Opção | Parâmetro | Escolha se | Exemplo | Origem |
|---|---|---|---|---|
| Até 10% do SG&A | fatia = 10% | um processo isolado | GP de um único processo | Julgamento (a validar) |
| ~20% | fatia = 20% | uma área média (financeiro, comercial) | hipótese usada no caso-teste | Julgamento (a validar) |
| ~35% | fatia = 35% | uma diretoria inteira | confirmar | Julgamento (a validar) |
| 50% ou mais | fatia = 50% | quase toda a estrutura administrativa | confirmar | Julgamento (a validar) |

### 10. Parte manual do processo (novo; para processos e IA)
| Opção | Parâmetro | Escolha se | Exemplo | Origem |
|---|---|---|---|---|
| Até 25% manual | fração manual = 0,2 | processo já sistematizado | confirmar | Julgamento (a validar) |
| 25–50% | 0,4 | misto | confirmar | Julgamento (a validar) |
| 50–75% | 0,6 | planilha e e-mail dominam | Concremat: gargalo manual (volume × tempo × custo-hora) | Julgamento (a validar) |
| Acima de 75% | 0,8 | quase tudo manual | confirmar | Julgamento (a validar) |

Faturamento e setor vêm do Apollo.

## Perguntas extras do success fee (pop-up 3)

### Alvo do variável pessimista (% do fixo)
| Opção | Escolha se | Exemplo | Origem |
|---|---|---|---|
| 20% | baseline ainda será construído ou cliente sensível a preço | ABB GP/CD | Julgamento (a validar) |
| 30% (recomendada) | padrão | Mantiqueira | Julgamento (a validar) |
| 40% | indicador medido (nível A) e fixo perto de 60% | Concremat | Julgamento (a validar) |

### Limite da cobrança total (fixo + variável) em % do ganho anual realista
| Opção | Escolha se | Origem |
|---|---|---|
| ≈15% | cliente grande ou que compara propostas | Julgamento, sem fonte |
| ≈20–25% (recomendada) | padrão | Julgamento, sem fonte |
| ≈30% | ganho incerto e fixo baixo (40–50%); exige indicador A | Julgamento, sem fonte |

## Referência de mercado (fontes secundárias)

- Gainshare com consultoria em risco alto: 10–50% do ganho verificado (Umbrex); 25–50% (tightship). Fee em risco típico: 10–30% do fee (crmsoftwareblog). Modelo upside: base baixa perto do custo + % do valor (Slideworks).
- Período de apuração sênior: 12–24 meses; janelas de 60–90 dias por KPI; pagamento mensal ou trimestral com ajuste posterior.
- Brasil: agências 1,5–4% com success fee a partir do 6º mês (RD Station); Bastos/Brandão 3,5–5%; NDados 3–15%.
- Realização do ganho: 70–85% em programas multifuncionais (Umbrex); vazamento de 1/3 no planejamento e 20% na execução em pipelines de compras (McKinsey).
- Custo logístico: média 9,5% da receita, de 3% a 19,8% (ILOS, 2026). SG&A: industrial 10–20%, consumo e varejo 20–30%, serviços de TI 15–25% (Umbrex).
- Não há método público de McKinsey, BCG ou Bain com esses números.

## Propostas usadas como exemplo

Mantiqueira (GP, R$115,9k no Drive; o contexto cita R$121,5k, confirmar qual vale), ABB GP/CD (R$54,2k, 12 semanas), Concremat GP com IA (R$24,1k, 6 semanas), Ânima PM (R$48k, 10 semanas, sem success fee).

---

> Adicionado da `success-fee` v14 (nov/2026). O teto de "≤ 50% do preço técnico" aqui descrito **não** é adotado pela v0.6.2 (ver SKILL.md, 4.3); a amostra serve só como referência de zonas.

## Teto do variável a partir de perdas por budget (Pipedrive, nov/2026)

Amostra: 1.000 negócios perdidos do pipeline de Vendas (jan/2025 a nov/2026; há mais páginas). Valor = preço proposto no momento da perda.

| Portfólio | Perdidos com valor | Perdidos por Budget | Mínimo | P25 | Mediana | P75 | Máximo |
|---|---|---|---|---|---|---|---|
| GP | 71 | 14 | R$12.100 | R$27.022 | R$29.750 | R$34.850 | R$47.520 |
| PM | 19 | 3 | R$19.170 | R$23.685 | R$28.200 | R$29.300 | R$30.400 |
| P&G | 11 | 0 | – | – | – | – | – |
| PD | 0 | 0 | – | – | – | – | – |
| AI Scan | 0 | 0 | – | – | – | – | – |

Regra (a validar): compare fixo + teto com esses valores. Abaixo do mínimo, sem perda por budget registrada; entre o mínimo e a mediana, risco crescente; acima da mediana, onde a maioria das perdas aconteceu. Sem histórico (AI Scan, PD, P&G), use GP como referência e avise. Teto sempre ≤ 50% do preço técnico.

## Pool por pessoas (multinacional)

Pool = pessoas na base × custo anual médio por pessoa (a validar). Use quando o faturamento do grupo não representa o escopo. O alcance continua valendo; evite contar duas vezes (ex.: base de 30 pessoas de um único time com alcance de 25%).
