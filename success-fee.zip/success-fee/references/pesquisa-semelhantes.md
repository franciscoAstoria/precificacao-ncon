# Pesquisar em empresas semelhantes (para dados concretos)

Use quando o CN não tem o dado (custo por pessoa, nº de pessoas, faturamento do escopo, SG&A). O resultado é uma faixa, nunca um número exato, e fica marcado "(a validar)".

## 1. Pipedrive (dimensionamento e preço)
- `getDeals` status `won`, pipeline de Vendas, `limit` 500, com Portfólio e valor. Filtre pelo portfólio do projeto e, se a organização tiver Nº de funcionários (campo 0b2be49f...) ou Setor (6ea1ea74...), por porte e setor parecidos.
- Reporte: nº de ganhos, mediana, P25 e P75 do valor, e o porte dos clientes. Isso calibra preço e escopo, **não** o custo por pessoa. Se o portfólio não tem ganhos (ex.: AI Scan), use GP como referência e diga.

## 2. Apollo (porte e dimensionamento)
- Grátis: `apollo_organizations_lookup` e `apollo_mixed_companies_search` com filtros de faixa de funcionários e setor; dão faixas, não receita nem custo.
- Com crédito: `apollo_organizations_enrich` (1 crédito por empresa) traz receita e funcionários. **Peça aprovação antes**, com o total de créditos do lote: "Enriching [domínio] will consume 1 credit (no charge if not found). Do you want to proceed?". Sem aprovação, não gaste.

## 3. Estimativa
- Custo anual por pessoa ≈ receita das semelhantes ÷ funcionários × fração de custo de pessoal do setor, ou o dado público do setor. Sem enrich, não dá para calcular: mantenha o palpite do CN ou do padrão e diga que é palpite.
- Mostre a faixa (baixa / média / alta), as empresas usadas e a fonte de cada número, e proponha o valor central como "(Recomendado)".
