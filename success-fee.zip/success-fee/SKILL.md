---
name: "success-fee"
description: "Quarta etapa do fluxo de proposta do NCon (Poli Júnior), chamada pela orquestrador-ncon quando o gate do success fee abre. Lê o ncon.run (cliente, dimensionamento e precificação), roda o filtro de elegibilidade e desenha a opção C (fixo reduzido + success fee): fixo, percentual, teto, janela, teste de sanidade, Protocolo de Mensuração, relatório do CN e o Protocolo de Mensuração que a `proposta-ncon` leva ao slide oficial de remuneração. Devolve a seção success_fee do run. Não dimensiona, não precifica, não decide o que vai ao deck e não grava o log."
---

# Success fee NCon (opção C), v1.4

Desenha a **opção C** do NCon (Núcleo de Consultoria da Poli Júnior): parte fixa reduzida mais um success fee sobre o ganho que o projeto gerar e que for medido depois. Quem chama esta skill é a `orquestrador-ncon`, depois da precificação e do gate, passando o `ncon.run` (contrato em `orquestrador-ncon/references/contrato-run.md`). Você é a dona da seção `success_fee`.

**Onde você entra:** dimensionamento → precificação → gate da orquestradora → **success-fee (esta)** → decisão final → proposta. Você **lê** `run.cliente`, `run.dimensionamento` e `run.precificacao` (o preço técnico B vem de `run.precificacao.opcoes[B]`, sem a visita) e termina devolvendo o run com a sua seção. **Não chame outra skill, não recalcule preço base nem múltiplo, não decida quais estruturas vão ao deck e não grave o log.** A C vale para **GP, P&G, GTO, PD e AI Scan** e **nunca para PM**.

**Princípios (não negociáveis):**
- O CN sempre tem a palavra final. Há um checkpoint obrigatório (Etapa 5). Nunca pule.
- **O ROI estimado não entra no preço e nunca é prometido ao cliente.** O preço da C vem do preço técnico B e de parâmetros de política (φ, λ, n, k). A estimativa top-down do ganho só **testa** o percentual: aponta fee degenerada, folgada ou cara demais, mas não o define. Pode aparecer na conversa como argumento de valor, só em ordem de grandeza e só se o cenário pessimista passar de 1× o preço, nunca no slide. O ganho é medido só depois do projeto, contra o baseline do contrato. **(a validar com o time)**: redação proposta no contexto do projeto, decisão pendente.
- **Quem decide chamar esta skill é o gate da orquestradora** (portfólio elegível, indicador mensurável candidato e gatilho: sinais da precificação ou pedido do CN). Aqui dentro, o **filtro de elegibilidade** (Etapa 2) decide se a C é viável. Portfólios elegíveis: **GP, P&G, GTO, PD e AI Scan**. **Nunca PM**: o produto é uma decisão, sem indicador de economia mensurável.
- Sem indicador mensurável e baseline acordado, não há success fee, porque não há como apurar depois.
- **Só fixo reduzido (φ entre 50% e 70%).** A variante C-Segura (fixo ~100% + 2 a 3%, formato da Mantiqueira) **não faz parte da skill** (decisão do CN, 16/11): se o CN quiser, é exceção que ele pede aos CPs fora do fluxo.
- **Cliente que já pediu success fee ou parte variável** é sinal a favor da aceitação e reforça a aderência da C no briefing, mas **não muda a fórmula** nem os filtros (decisão do CN, 16/11).
- O percentual nunca incide sobre o preço do projeto nem sobre a estimativa: incide sobre a **economia capturada**.
- Na dúvida sobre um parâmetro, use o valor neutro e diga isso. Valores marcados com **(a validar)** são provisórios: use-os, mas sinalize no briefing.
- **A estrutura final é escolha do CN**, feita na decisão final da orquestradora (com a C aprovada, o par do deck é B e C e a A é descartada). Esta skill devolve a C pronta e a recomendação.

## Como perguntar ao CN (questionário)

Use a ferramenta de perguntas de múltipla escolha (AskUserQuestion), não perguntas abertas por texto:
- Até 4 perguntas por chamada, 2 a 4 opções cada. A opção "Outro" aparece sozinha: não crie uma.
- Antes do questionário, mostre o resumo em texto; cada pergunta precisa se sustentar sozinha, citando o número validado.
- Opção recomendada primeiro, com "(Recomendado)". Em cada opção escreva o **parâmetro**, o **"escolha se"** e, quando houver, um exemplo de proposta real (`references/estimativa-ganho.md`).
- Toda resposta diferente do recomendado vira um item em `ajustes_do_cn` (`{campo, de, para, motivo}`). Se o CN ajustou sem dizer o motivo, pergunte em uma linha.
- Sem a ferramenta (execução agendada), faça as mesmas perguntas por texto, numeradas.

---

## Entradas (vêm do run)

| Entrada | Onde está | Se faltar |
|---|---|---|
| Portfólio (GP, P&G, GTO, PD ou AI Scan) e opcionais escolhidos | `run.dimensionamento` (Checkpoint 1 já valeu) | devolva à orquestradora; PM encerra a skill com "a C não existe em PM" |
| **B**: preço técnico, múltiplo e fatores, ITIP efetivo | `run.precificacao.opcoes[B]` e `run.precificacao.multiplo` | devolva à orquestradora; **não recalcule o múltiplo aqui** |
| Custo de visita | `run.precificacao.opcoes[B].visita` | 0 se não houver visita |
| sa, semanas, analistas, selo de confiança | `run.dimensionamento.opcoes[B]` | usado só para o ITIP efetivo e as parcelas |
| Contexto do lead: setor, faturamento, funcionários, decisores, visita, sinais de budget, objeção de preço, reação na AT, canal, indicador mensurável candidato (com trechos) | `run.cliente` | pergunte ao CN só o que estiver `null` |
| Fases do projeto (C2): sa da Fase 1 (diagnóstico e plano) e da Fase 2 (implantação assistida e medição) | `run.dimensionamento.opcoes[B].fases` | sem fases, é C1; se a B já inclui implantação assistida, é C2 |

Não refaça as perguntas que já estão em `run.validacoes` (o Checkpoint 1 e a escolha do portfólio já valeram).

## Etapa 1 — Ficha da C (a partir do run)

Monte uma **ficha mínima da C** a partir de `run.cliente` e mostre-a ao CN, citando os trechos já registrados no run:

| Campo | Conteúdo |
|---|---|
| Indicador e método de cálculo do retorno (candidatos) | métrica que o cliente acompanha e que o projeto move; fórmula do ganho em R$ ou KPI (catálogo em `references/opcao-c.md`, seção 1); fonte do dado; quem apura no cliente |
| Sinais para a C | (1) a operação já roda e a melhoria é atribuível ao projeto? (2) decisor e controladoria/financeiro participaram da AT? (3) o cliente falou em resultado, meta ou parte variável? (sinal de aceitação, não pré-requisito). Cada um com trecho citado ou "sem evidência" |
| Sinais de budget e de preço | menções a orçamento, comparação com outras consultorias, objeção de preço, reação na AT (0–5) |

- **Faturamento e porte** vêm do run. **Multinacional:** o faturamento global não representa o escopo. Use o pool por pessoas (`--pessoas` × `--custo-pessoa` no script) e pergunte o nº de pessoas e o custo anual médio por pessoa (a validar).
- **Dados concretos** (custo por pessoa, nº de pessoas, faturamento do escopo, SG&A) que nem o run nem o CN tiverem: toda pergunta desse tipo traz a opção **"Pesquisar em empresas semelhantes"**, seguindo `references/pesquisa-semelhantes.md`. O resultado vira a sugestão "(Recomendado)" e só vale depois da confirmação do CN.
- Pergunte ao CN apenas o que estiver `null` no run e for necessário para o filtro. Sem faturamento, peça uma faixa; não invente.

## Etapa 2 — Filtro de elegibilidade da C

Roda sempre que esta skill é chamada (o gate da orquestradora já confirmou portfólio elegível, indicador candidato e gatilho). Pré-preencha cada pergunta com o que a transcrição mostra (trecho citado, resposta provável primeiro) para o CN só confirmar. Antes do questionário, mostre o indicador e o método de cálculo com o trecho citado. As 4 perguntas são eliminatórias: a resposta marcada com ✗ **remove a C**. A skill diz o motivo e o que faria a C voltar a ser viável.

1. "Existe método de cálculo do retorno de [indicador]?" →
   - Sim, em R$: fórmula e fonte de dado definidas, ex.: [método sugerido] (modelo de ganho compartilhado)
   - Só em KPI operacional (tempo, OTIF, retrabalho), sem conversão para R$ (C só no modelo de atingimento de KPI)
   - Não há método claro, só estimativa ou ROI projetado ✗
2. "O cliente tem e fornece o histórico de [indicador] (baseline)?" →
   - Sim, com pelo menos 6 meses de histórico acessível **(a validar)**
   - Parcial: histórico curto ou só estimativa (a C segue com φ = 70% e o baseline vira entregável da 1ª etapa)
   - Não existe medição ✗
3. "Quem no cliente aceita a apuração do resultado?" →
   - Controladoria ou financeiro já participou ou confirmou
   - Pode ser envolvido, mas ainda não foi (a C segue, e o aceite entra como condição no Protocolo de Mensuração)
   - Ninguém definido, ou o cliente não quer validar a medição ✗
4. "O ganho depende de o cliente executar o plano sozinho depois?" →
   - Pouco: o projeto implanta, ou o ganho vem do próprio processo mapeado
   - Muito: o cliente precisa executar (a C segue só com φ = 70% e alerta aos CPs)

**Eliminações automáticas (sem pergunta):** portfólio PM; piso que não deixa reduzir o fixo (F_min acima de 80% de B **(a validar)**; hoje F_min provisório = 50% de B). Uma terceira condição é checada no checkpoint (Etapa 5): a Poli ter um responsável pela apuração durante a janela.

Se a C foi eliminada, mostre ao CN em uma linha a **C hipotética** (φ = 70%, rode o script só com a política), marcada como não recomendada, com o motivo e o que a faria voltar. O CN pode **reverter a eliminação** (corrigindo a resposta ou assumindo o risco); então a C segue e vai para os CPs. Com a C eliminada e sem reversão, pule as Etapas 3 e 4 e devolva ao CN só a explicação.

## Etapa 3 — Direcionamento do φ e do teto (k)

**φ (fração fixa de B):**

| Situação (ficha + filtro) | φ |
|---|---|
| Padrão | 60% |
| Método em R$, baseline com histórico, aceite da controladoria definido **e** operação rodando com decisor e controladoria na AT | 50 a 55% (vai para os CPs) |
| Baseline parcial, ou o ganho depende muito de o cliente executar | 70% |
| Dois ou mais pontos frágeis ao mesmo tempo (baseline parcial + ganho dependente do cliente + aceite ainda não definido) | não ofereça a C |

**Teto (k).** O teto limita o upside da EJ e protege o cliente: quanto mais frágil a medição, menos upside a EJ consegue defender numa disputa, então o teto desce. **Não use a estimativa de ganho para escolher o k.** Duas respostas já vêm da Etapa 2 (baseline e dependência do cliente), então faça só as 3 perguntas abaixo, pré-preenchidas:

1. "O ganho em [indicador] pode ser atribuído ao projeto sem muita disputa?" → Sim: o indicador só se move pelo que o projeto muda (tempo, retrabalho, processo interno) · Em parte: há fatores externos que o protocolo consegue ajustar (volume, preço de insumo, mix) · Pouco: mercado, sazonalidade ou outras iniciativas do cliente pesam muito
2. "De onde vêm os dados de [indicador]?" → Sistema do cliente (ERP, WMS, BI), auditável · Planilha ou apuração manual do cliente · A Poli teria que construir a coleta
3. "O cliente tende a rejeitar um teto de upside alto?" (compara propostas, objeção de preço na AT, pediu desconto) → Sim: compara propostas ou já objetou preço · Sem sinal · Não: tem orçamento reservado e valoriza dividir o upside

Regra de decisão **(a validar)**:

| Resposta | Sinal |
|---|---|
| Baseline com 6 meses ou mais (Etapa 2) | força |
| Baseline parcial (Etapa 2) | fraqueza |
| Ganho pouco dependente do cliente (Etapa 2) | força |
| Ganho muito dependente do cliente (Etapa 2) | fraqueza |
| Atribuição: sim · em parte · pouco | força · neutra · fraqueza |
| Fonte: sistema · planilha · a Poli constrói | força · neutra · fraqueza |
| Cliente sensível a preço: sim | desce um nível |

- Qualquer fraqueza → **k = 1,25**.
- As 4 forças (baseline, dependência, atribuição e fonte) → **k = 2,0**, que vai para os CPs.
- Demais casos → **k = 1,5**.
- Cliente sensível a preço desce um nível (2,0 → 1,5; 1,5 → 1,25; 1,25 fica) e dá a frase de venda "você nunca paga mais que R$ X".
- Resposta ausente conta como neutra e nunca libera o 2,0.

O script devolve o `teto_k` com o k sugerido e os motivos. O CN pode trocá-lo no checkpoint; se divergir do sugerido, o motivo vai para `ajustes_do_cn`.

## Etapa 4 — Cálculo da C

### 4.0 Arquétipos: C1 e C2 (decisão do CN, 16/11)

| Arquétipo | Escopo | Quando a janela W começa | Fixo |
|---|---|---|---|
| **C1 (pós-projeto)** | só diagnóstico e plano (e acompanhamento leve) | na entrada em operação de cada iniciativa, depois do projeto | φ × B + visita, parcelado só sobre o fixo |
| **C2 (diagnóstico + implantação + comprovação)**, modelo Mantiqueira | Fase 1 (diagnóstico, linha de base, plano) e Fase 2 (implantação assistida e medição mensal) | na entrada em operação de cada iniciativa, que pode ocorrer durante a Fase 2 | φ × B, dividido entre as fases por semanas-analista (`fixo_por_fase` do script); a visita fica na Fase 1 |

No C2 a **B já inclui a Fase 2** em semanas-analista (a `dimensionamento-ncon` entrega as duas fases e a `precificacao-ncon` precifica o total). A fórmula, o filtro e os guardrails são os mesmos do C1, com estas diferenças: (a) o filtro da Etapa 2, pergunta 4, tende a "Pouco", porque o projeto implanta; (b) no teste de sanidade a realização é 85%, derivada da Fase 2 (não se pergunta); (c) a janela W e o responsável pela apuração cobrem também a Fase 2: nomeie o consultor da Fase 2; (d) a apuração mensal em comitê e o faturamento trimestral entram no Protocolo de Mensuração. Passe `--sa-fase1` e `--sa-fase2` ao script no C2.

### 4.1 Fórmula (modelo padrão: ganho compartilhado)

```
B   = preço técnico da candidata B (sem visita), vindo de `run.precificacao`
F   = φ × B + custo de visita                      → parte fixa
p   = (1 + λ) × (1 − φ) / (n − H/B)                → percentual da fee
G   = ganho capturado medido (Protocolo de Mensuração), dentro da janela W
V   = min( p × max(0, G − H) , (k − φ) × B )       → parte variável
Total C = F + V
```

| Parâmetro | Valor inicial (a validar) |
|---|---|
| φ, fração fixa de B | 60% (faixa 50 a 70%) |
| λ, prêmio de risco proporcional ao risco assumido | 0,25 |
| n, múltiplo de B capturado para a C chegar à meta | 5 |
| k, teto do projeto em múltiplos de B | 1,25 / 1,5 / 2,0, pelo filtro da Etapa 3; padrão 1,5 |
| H, franquia | 0 |
| W, janela por iniciativa | 6 a 12 meses |
| F_min, menor fixo permitido | 50% de B, provisório até o time definir o custo por semana-analista; com o custo definido, F_min = custo de coordenação + sa × custo por sa |

- O **n é parâmetro de política**, não estimativa de ROI do cliente: mantenha 5; mudar (4 a 6) exige justificativa registrada **(a validar no backtest)**.
- **Break-even contra B** (H = 0): G = n/(1 + λ) × B, qualquer que seja o φ: **4 × B** com n = 5 (3,2 × B com n = 4; 4,8 × B com n = 6). A meta é G = n × B, em que o total é B × (1 + λ × (1 − φ)).
- Com φ = 60%, n = 5: p = 10%. Com φ = 50%: 12,5%. Com φ = 70%: 7,5%.
- **Por que o p é maior que o da v0.4 (5%) e o da Mantiqueira (2,5%):** nesses casos o fixo cobria quase todo o preço e a fee era upside. Aqui o fixo é **reduzido** (pedido do time), então a fee precisa repor a diferença: p = (1 + λ)(1 − φ)/n. O p cai para 7,5% com φ = 70% e para 2,5% a 3% só com fixo próximo de 100% (C-Segura), formato fora desta skill por decisão do CN (ver 4.0 e "Itens provisórios").
- **Janela W de 6 a 12 meses** (a v0.4 usava 3 a 6 meses depois do projeto): W conta por iniciativa a partir da entrada em operação, como na Mantiqueira, e vem do T da `success-fee` v14 (versão anterior).
- O parcelamento incide só sobre o fixo ("em até Nx", N = 2 + floor(semanas / 4)). A visita entra inteira no fixo e fora do múltiplo, do teto e das concessões. A fee é faturada conforme o Protocolo de Mensuração.
- O teto precisa permitir a meta: k × B ≥ B × (1 + λ × (1 − φ)) e, por padrão, k ≥ 1,25 **(a validar)**. Um teto de "variável ≤ 25% do preço" com fixo de 60% a 70% (k = 0,85 a 0,95) fica abaixo de B: a EJ nunca recebe o preço técnico. Não use.

| k | Quando o filtro sugere | Variável máximo com φ = 60% / 70% |
|---|---|---|
| 1,25 | qualquer fraqueza de medição, ou cliente sensível a preço com sinais neutros | 0,65 × B / 0,55 × B |
| 1,5 | padrão: nenhuma fraqueza e menos de 4 forças | 0,90 × B / 0,80 × B |
| 2,0 | as 4 forças e cliente sem sensibilidade a preço; vai para os CPs | 1,40 × B / 1,30 × B |

### 4.2 Referência de perdas por orçamento (Pipedrive)

Compara o **fixo cobrado** e o **total máximo** da C com o valor das propostas que a Poli já perdeu por Budget. Só informa; não muda φ, p nem k.

1. Busque os negócios perdidos (`getDeals`, status `lost`, pipeline de Vendas, `limit` 500, campos "Portfólio" e valor; use `cursor` para mais páginas). A resposta grande é salva em arquivo: passe os caminhos a `scripts/budget_losts.py`, que devolve, por portfólio, o mínimo, P25, mediana e P75 do valor das propostas perdidas por Budget. O valor é o preço proposto, não o budget declarado. Amostra de referência (nov/2026) em `references/estimativa-ganho.md`.
2. Passe os quatro valores do portfólio ao `calcula_c.py` (`--budget-min`, `--budget-p25`, `--budget-mediana`, `--budget-p75`). O script classifica o fixo e o total máximo: abaixo do mínimo = sem perda por budget registrada; entre o mínimo e a mediana = risco crescente; acima da mediana = onde a maioria das perdas por budget aconteceu.
3. Portfólio sem perdas por budget (hoje P&G, PD e AI Scan): use GP como referência e diga isso.
4. A `success-fee` v14 (versão anterior) limitava o variável a 50% do preço técnico. Aqui vale o k: o variável máximo é (k − φ) × B, que passa de 50% de B com k = 1,5 e φ = 60%. Limitar a 50% de B levaria o k abaixo de 1,25 e contraria o guardrail 8. O script mostra `variavel_max_pct_B` e avisa acima de 50%. **Decisão do CN em 16/11: manter o k, com aviso acima de 50% de B** (as outras opções eram adotar o cap de 50% da v14 ou usar o menor dos dois).

### 4.3 Teste de sanidade do percentual

Roda quando a C for candidata (passou no filtro) ou o CN reverteu a eliminação. A estimativa é **top-down por porte (a validar)**: não vem de imersão, tem erro grande e **não define o percentual**. Só mostra se o p de política faz sentido para o tamanho do cliente.

1. **Dados.** Faturamento e setor da Etapa 1. Custo logístico/receita ou SG&A/receita: `references/estimativa-ganho.md`. Pré-selecione cada resposta com o que a ficha mostra.
2. **Questionário** (1 chamada, até 4 perguntas): dor (logística e transporte · processos manuais e back office · automação, IA e dados), alcance e headroom. **Não pergunte "até onde a Poli vai" (a entrega):** o escopo já vem do dimensionamento e da precificação, e esta skill não o redefine. A realização sai dele: só diagnóstico e plano (Fase 1, C1) = 53%; diagnóstico, plano e acompanhamento descritos no escopo = 70%; implantação assistida e medição (Fase 2, C2) = 85%. Mostre a realização usada no briefing, com a fase que a justifica; se o escopo não permitir saber, use 53% e avise. Se a dor for processos ou IA, uma 2ª chamada com fatia da área e parte manual. Em cada opção escreva o parâmetro, o "escolha se" e um exemplo (blocos 2 e 5 a 10 de `references/estimativa-ganho.md`). Em rede de lojas ou unidades, o alcance é a participação da unidade na rede (ex.: 1 de 45 lojas ≈ 2%), não a opção de "piloto pequeno" de 10%. PM: sem top-down.
3. **Conta.** `python scripts/calcula_c.py --B [preço técnico] --visita [visita] --phi [φ] --sa [sa] --dor logistica --faturamento [R$] --custo-log [fração] --alcance [fração] --realizacao [fração] --W [meses]`. Para processos e IA, `--sga` e `--fatia` no lugar de `--custo-log` (multinacional: `--pessoas` e `--custo-pessoa` no lugar de `--faturamento`, `--sga` e `--fatia`). Opcionais: `--manual`, `--headroom`, `--lam`, `--n`, `--k`, `--H`, `--limite-total`. Passe as respostas do filtro do k (`--baseline`, `--dependencia`, `--atribuicao`, `--fonte`, `--cliente-sensivel-preco`) e deixe `--k` de fora para o script usar o k sugerido. Sem os argumentos de estimativa, o script devolve só a política. **Faça a conta no script, não de cabeça.** A saída é JSON: formate em tabelas.
4. **Flags** (mostre no briefing):
   - **DEGENERADA**: o teto prende o variável até no pessimista; o "success fee" virou preço fixo disfarçado e o percentual não importa. Recomende a B ou a revisão do alcance; a C só segue se o CN assumir que a fee é cosmética.
   - **Variável pessimista acima de 40% do fixo:** p de política folgado para o porte estimado. Ofereça o `p_referencia` (limitado a 3% a 10%).
   - **Abaixo de 20% do fixo:** a fee pode ser irrelevante no pior caso; confira o ganho estimado.
   - **Cobrança total acima do limite do ganho realista anual:** o cliente paga caro relativo ao que ganha. Limite padrão de 25%; 15% para cliente grande ou que compara propostas; 30% quando o ganho é incerto e o fixo baixo, e só com indicador já medido **(a validar)**.
5. **Alcance incerto.** Se o alcance for o dado mais frágil (quase sempre é), rode também com o alcance imediatamente abaixo e mostre as duas leituras. Só o alcance pode mudar o ganho pessimista em 5 vezes.
6. **Alternativas de p.** O script devolve `p_alternativas`: o p de política e o p calibrado no ganho pessimista, no realista e no otimista, cada um com variável e total nos 3 cenários. O p de política prevalece; só muda se o CN escolher outro no checkpoint, e então valem os guardrails de p. O alvo de 20% a 40% do fixo é julgamento **(a validar)**.
7. **Uso.** A estimativa fica só no briefing e no relatório do CN, rotulada "estimativa top-down, a validar", e fora do slide.

### 4.4 Modelos por tipo de indicador

Ganho em R$ (métodos 1 a 4 do catálogo): fórmula acima. KPI sem conversão para R$: atingimento de KPI. PD e AI Scan com entregas verificáveis: marcos binários. Fórmulas e variantes (escalonado, franquia, fixo = escopo essencial) em `references/opcao-c.md`, seção 4.

### 4.5 Guardrails (o briefing checa e sinaliza)

1. F ≥ F_min. Se φ_min × B não cobre o custo, o projeto é pequeno demais para a C.
2. O total com G = 0 também precisa ser ≥ F_min.
3. p fora de 3% a 10%, ou φ abaixo de 60%, ou n fora de 4 a 6: vai para os CPs.
4. Teto sempre definido; removê-lo exige os CPs. Nunca 100% variável.
5. Conta só economia **capturada**, por iniciativa, dentro da janela W. Nunca economia identificada ou estimada.
6. O ganho do cliente nunca define o preço. Sem número do cliente, use a estimativa do teste de sanidade rotulada "top-down, a validar" ou mostre só o break-even em "ganho necessário".
7. Protocolo de Mensuração completo (`references/opcao-c.md`, seção 2) antes de devolver o run.
8. O teto precisa permitir a meta e, por padrão, k ≥ 1,25 **(a validar)**.
9. Flag DEGENERADA: recomende a B ou a revisão do alcance.
10. Cobrança total acima do limite do ganho realista: sinalize e ofereça reduzir o teto ou voltar à B.
11. O k segue o filtro; se o CN usar outro, o motivo vai para `ajustes_do_cn`. k = 2,0 vai para os CPs.
12. A referência de perdas por orçamento é informativa: total máximo acima da mediana das perdas por budget é sinal de risco de rejeição, mas não elimina a C.

### 4.6 Concessões na C

Desconto de −5% e −10% só sobre o fixo do projeto (nunca sobre a visita); a fee e o teto não entram na escada. Descontos acima de 10% só com os CPs. Negocie um parâmetro por vez. Reduzir φ abaixo de 60%, levar p acima de 10% ou remover o teto exige os CPs. O plano B interno (voltar à B se o cliente rejeitar a parte variável) fica no briefing, nunca no slide.

## Etapa 5 — Briefing da C → CHECKPOINT

Mostre ao CN:

1. **Filtro:** respostas das 4 perguntas, sinais da ficha com trechos citados e, se a C foi eliminada, o motivo e o que a faria voltar.
2. **Parâmetros:** φ, p, n, λ, k, H, W, cada um com justificativa; marque "(a validar)". Para o k, o valor sugerido pelo filtro e os motivos (forças e fraquezas).
3. **Tabela de receita:** G = 0, 2×B, break-even, meta e teto, com total, % em relação à B e ITIP efetivo. Os cenários são só teste de sanidade: nunca promessa.
4. **Teste de sanidade (4.3):** 3 cenários (ganho anual estimado, variável, total, variável em % do fixo, total sobre o ganho realista), flags, `p_alternativas` e as duas leituras de alcance quando ele for o dado mais incerto. O valor esperado com pesos 25/50/25 deve ficar ≥ B.
5. Piso de segurança (F ≥ F_min, total com G = 0 ≥ F_min), ponto em que o teto passa a valer e **zona de perdas por orçamento** (4.2), com o variável máximo em % de B.
6. **Análises próprias** (faça todas, em toda execução; só dados da transcrição, Apollo, Pipedrive ou CN, e diga quando faltar dado; fórmulas em `references/opcao-c.md`, seção 6):
   - **Exposição da EJ:** quanto a EJ deixa de receber se o ganho for zero (B − F, em R$ e %) e o ITIP efetivo da C com G = 0, comparado ao menor ITIP do banco (R$ 1.800).
   - **Plausibilidade do break-even:** a melhoria que o projeto precisa entregar para a C igualar a B, como % do custo anual do processo ou indicador (número do cliente, se citado; senão o pool estimado, rotulado como estimativa) e como % do faturamento; compare com os cases do institucional da `proposta-ncon`. Se exigir melhoria bem acima dos cases, sinalize a C como arriscada.
   - **Sensibilidade:** p e break-even para φ = 50/60/70% e n = 4/5/6.
   - **Aderência ao lead:** cruze sinais de budget, reação na AT, objeção de preço, comparação com concorrentes e histórico no Pipedrive com a C. Objeção de preço favorece a C (menor desembolso inicial); reação fria ou decisor ausente favorece a B ou a A. Se o lead nunca falou em parte variável, escreva uma frase pronta para introduzir a C ("pague menos agora e o restante só se o resultado aparecer"), vendendo a dor resolvida e não a metodologia.
   - **Capacidade da Poli:** quantos contratos com parte variável a EJ já tem em apuração; se o CN não informou, pergunte em uma linha.
   - **Riscos operacionais:** responsável pela apuração durante W (a gestão da EJ muda todo ano), nota fiscal e caixa sobre receita variável (validar com jurídico e financeiro), dependência de dado do cliente.
7. **Recomendação:** levar a C ou voltar à B/A, com a justificativa e "quando eu mudaria de ideia" (ex.: "se a controladoria não aceitar a apuração, volto para a B").

**Checkpoint (questionário):**
1. "Levar a C como candidata? Fixo R$ [F] + [p]% do ganho capturado, teto total R$ [teto]." → Levar a C (Recomendado, se a análise indicar) · Ajustar φ, n ou teto · Escolher outro p, entre as alternativas · Voltar para A ou B
2. (se escolheu outro p) pop-up com uma alternativa por calibração: **política**, **calibrado no pessimista**, **no realista** e **no otimista**. Na descrição de cada uma: o p, quanto a Poli recebe nos 3 cenários (fixo + variável, com o teto) e o motivo para escolhê-la. Marque "(Recomendado)" no p de política, salvo se uma flag indicar outra. Se o teto prende o variável em todas, diga que o p não muda o recebido e recomende o menor p que já atinge o teto. p fora de 3% a 10% vai para os CPs.
3. "Quem na Poli apura o resultado durante os [W] meses de janela?" → o CN que apresenta · um CP do projeto · Ainda não definido ✗ (a C sai: sem responsável nomeado a medição não acontece; volte para a B ou defina antes de apresentar)
4. Se o CN mudou φ, p, n, teto ou k em relação ao sugerido: o motivo, em uma linha, vai para o log.

Peça também, em texto, o que ainda faltar do **Protocolo de Mensuração** (unidade e fórmula, período do baseline, ajustes permitidos, quem aceita e prazo, regra de disputa) antes de devolver o run. Ajustes → recalcule, mostre só o que mudou e confirme.

## Etapa 6 — Entregas

1. **Bloco de entrega da C** (para a decisão final da orquestradora e daí para a `proposta-ncon`): estrutura C com fixo do projeto, visita, fixo cobrado, parcelas (só sobre o fixo), p, janela W, teto do variável, teto total, Protocolo de Mensuração, flags e a recomendação. Devolva esse bloco **na seção `success_fee` do run** (JSON abaixo); a orquestradora o leva à **decisão final**, onde o CN escolhe as estruturas do deck (com a C aprovada, o par é B e C; a A é descartada) e o deck sai de lá. Se a C foi eliminada, devolva só o motivo e o que a faria voltar. As outras candidatas não aparecem em nenhum lugar do deck.
2. **Slide da C: não é seu.** A `proposta-ncon` tem o slide oficial "Modelo de Remuneração" em todos os templates e o preenche sozinha a partir da seção `success_fee` (fixo cobrado, % da fee, janela, teto, base de cálculo, ajustes e trava de serviço, apuração). Você **não gera pptx**. O que você garante é o `protocolo_medicao` completo: cada campo dele vira uma linha do slide, e campo `null` vira pendência para o CN na proposta. **Nunca** ponha ganho estimado nem cenários fora de `interno`.
3. **Relatório do CN (PDF, separado, só para o CN)** com `scripts/relatorio_cn.py` (modelo em `references/relatorio-exemplo.json`): um tópico por escolha (dor, alcance, realização derivada do escopo, headroom, base do pool, parte manual, filtro da C, φ, p, k, janela W), cada um com a opção escolhida e o motivo (evidência da transcrição, Pipedrive ou Apollo), a conferência das contas, os 3 cenários, a zona de perdas por orçamento e a lista "o que conferir". Traz ganho estimado e premissas internas: **nunca** anexe ao deck nem envie ao cliente.
4. **Pop-up "Alterar algum dado?".** Ao entregar, pergunte "Quer alterar algum dado?" → Não, está certo · Sim. Se sim, um pop-up em múltipla seleção com os itens (dor, alcance, headroom, base do pool, parte manual, φ, p, k, janela W; o escopo se altera na `dimensionamento-ncon`, não aqui), depois as opções do item escolhido. Rode o script de novo, mostre antes e depois, regere o relatório e repita até o CN dizer "está certo".

### Resultado em JSON (seção `success_fee` do contrato `ncon.run/1`)

Ao fim da Etapa 6, emita o run completo com a seção `success_fee`: `elegivel`, `motivo_eliminacao`, `o_que_faria_voltar`, `arquetipo` (C1 ou C2), `parametros` (phi, p, n, lambda, k, H, W_meses), `fixo_cobrado` (já com a visita), `fixo_por_fase` (só no C2; `null` no C1), `visita`, `parcelas_max`, `variavel_max`, `teto_total`, `protocolo_medicao` (unidade e fórmula, período do baseline, ajustes, trava de serviço, quem aceita e prazo, disputa, exclusões), `responsavel_apuracao`, `recomendacao` (levar_c, justificativa, mudaria_de_ideia_se), `ajustes_do_cn` e o bloco `interno` (teste de sanidade, `p_alternativas`, flags, zona de perdas por orçamento, plano B). **Tudo em `interno` é só para o CN e os CPs e nunca vai ao deck.** Acrescente `success_fee` a `etapas_concluidas` e o checkpoint da C a `validacoes`. Desconhecido = `null`; nunca invente.

## Itens provisórios a validar com um CN

| Item | O que está na skill | Origem |
|---|---|---|
| Fórmula da C | φ = 60% (50 a 70%), λ = 0,25, n = 5, k = 1,25 / 1,5 / 2,0 (filtro), H = 0, W = 6 a 12 meses; p = (1 + λ)(1 − φ)/(n − H/B) | Sugestão do Claude, 16/11 |
| Piso de segurança | F_min = 50% de B até o time definir o custo por sa; C removida se F_min > 80% de B | Sugestão do Claude, 16/11 |
| Filtro de elegibilidade | 4 perguntas eliminatórias + responsável pela apuração no checkpoint; "6 meses de histórico" | Sugestão do Claude, 16/11 |
| Filtro do k | 5 sinais; qualquer fraqueza → 1,25, 4 forças → 2,0 (CPs); k ≥ 1,25 | Sugestão do Claude, 16/11 |
| Regra do ROI | o ROI estimado não entra no preço nem é prometido; a estimativa top-down só testa o percentual | Redação proposta, decisão pendente do time |
| Teste de sanidade | estimativa top-down por porte; alvo de variável pessimista de 20% a 40% do fixo; limite de cobrança total de 25% (15% / 30% em casos especiais) | `success-fee` (versão anterior), adaptada |
| Alternativas de p | p calibrado no pessimista, realista e otimista, cada um com o total nos 3 cenários | `success-fee` v14 (versão anterior) |
| Perdas por orçamento | zonas pelo mínimo e pela mediana das propostas perdidas por Budget; só informa | `success-fee` v14 (versão anterior) |
| Formato da C | só fixo reduzido (φ 50 a 70%); sem C-Segura; arquétipos C1 e C2; cliente que pediu success fee é só sinal a favor; teto: manter o k com aviso acima de 50% de B | Decisão do CN, 16/11 |
| Alcance em redes | participação da unidade na rede (1 de 45 lojas ≈ 2%) | Backtest Tenda, 16/11 |

**Ainda em aberto:** calibrar o C2 com o backtest da Mantiqueira (falta a transcrição da AT); teto de variável ≤ 50% do preço técnico da `success-fee` v14 (versão anterior) (decidido: manter o k com aviso; revisar com os dados do backtest); amostra de perdas por budget só tem GP (14) e PM (3) com dados; custo por semana-analista da EJ (define o F_min); decisão do time sobre a regra do ROI; calibração dos parâmetros da estimativa top-down e do alvo de 20% a 40%; nota fiscal e caixa sobre receita variável (jurídico e financeiro); backtest da C com propostas que já tiveram success fee.
