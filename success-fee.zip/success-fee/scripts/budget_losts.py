#!/usr/bin/env python3
"""Estatistica dos negocios perdidos por Budget no Pipedrive, por portfolio do NCon.

Uso: python budget_losts.py arquivo1.json [arquivo2.json ...]
Cada arquivo e a resposta de getDeals (status lost, pipeline de Vendas) com o custom field de
Portfolio incluido. Se a resposta for grande, a ferramenta salva em arquivo: passe esses caminhos.

Saida (JSON): por portfolio, quantos negocios com valor foram perdidos, quantos por Budget, e o
minimo, P25, mediana e P75 do valor das propostas perdidas por Budget. O valor e o preco proposto
no momento da perda. Nao e o budget declarado pelo cliente.
"""
import json
import statistics
import sys
from collections import defaultdict

KEY_PORTFOLIO = "e4339ab04542dcd1e1215e4bc17ee2bcf45a9652"  # campo "Portfólio" (set)
NCON = {215: "GP", 216: "PM", 567: "P&G", 713: "PD", 714: "AI Scan"}


def pct(vals, q):
    v = sorted(vals)
    if not v:
        return None
    k = (len(v) - 1) * q
    f = int(k)
    c = min(f + 1, len(v) - 1)
    return round(v[f] + (v[c] - v[f]) * (k - f))


def main(paths):
    deals = {}
    for p in paths:
        data = json.load(open(p))
        for d in data.get("data", data):
            deals[d["id"]] = d  # evita duplicar o mesmo negocio em paginas sobrepostas
    perdidos = defaultdict(list)  # portfolio -> valores de todas as perdas com valor
    budget = defaultdict(list)
    for d in deals.values():
        if not d.get("value"):
            continue
        for pid in d.get("custom_fields", {}).get(KEY_PORTFOLIO) or []:
            if pid in NCON:
                perdidos[NCON[pid]].append(d["value"])
                if d.get("lost_reason") == "Budget":
                    budget[NCON[pid]].append(d["value"])
    out = {}
    for nome in NCON.values():
        b = budget.get(nome, [])
        out[nome] = {
            "perdidos_com_valor": len(perdidos.get(nome, [])),
            "perdidos_por_budget": len(b),
            "minimo": min(b) if b else None,
            "p25": pct(b, 0.25),
            "mediana": round(statistics.median(b)) if b else None,
            "p75": pct(b, 0.75),
            "maximo": max(b) if b else None,
        }
    print(json.dumps({"negocios_lidos": len(deals), "por_portfolio": out}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    main(sys.argv[1:])
