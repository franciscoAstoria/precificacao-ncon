#!/usr/bin/env python3
"""Opcao C do NCon: formula de politica (fixo reduzido + fee) e teste de sanidade.

Duas partes, uma saida JSON:

1. Politica (sempre): fixo, percentual da fee, break-even, meta, teto, tabela de
   receita e guardrails. Depende so do preco tecnico B e dos parametros de politica.
   NAO usa estimativa de ganho do cliente.

2. Teste de sanidade (opcional, so se --dor/--faturamento/--alcance/--realizacao
   forem passados): estimativa top-down do ganho anual em 3 cenarios (a validar).
   Serve para TESTAR o percentual de politica, nunca para defini-lo nem para
   ser prometida ao cliente.

3. Direcionamento do teto k (opcional): com --baseline/--dependencia/--atribuicao/--fonte/
   --cliente-sensivel-preco o script sugere k = 1,25, 1,5 ou 2,0 pelas respostas do filtro
   (SKILL.md, Etapa 3). Sem --k, usa o sugerido; com --k, usa o informado e avisa se diverge.

4. Pool por pessoas (multinacional): --pessoas e --custo-pessoa no lugar de --faturamento/--sga/--fatia.
6. Arquetipo C2 (opcional): --sa-fase1 e --sa-fase2 dividem o fixo por fase.
5. Referencia de perdas por orcamento (opcional): --budget-min/--budget-p25/--budget-mediana/--budget-p75
   classificam o fixo e o total maximo; so informativo.

Parametros (a validar) em references/opcao-c.md e references/estimativa-ganho.md.
"""
import argparse
import json
import sys

MELHORIA = {  # (pessimista, realista, otimista), a validar
    "logistica": (0.02, 0.05, 0.10),
    "processos": (0.30, 0.35, 0.40),
    "ia": (0.20, 0.275, 0.35),
}
NOMES = ("pessimista", "realista", "otimista")
R = lambda x: int(round(x))


def estima_ganhos(x, parser):
    """Estimativa top-down do ganho anual (3 cenarios). Retorna (ganhos, pool_escopo, avisos)."""
    if x.dor == "logistica":
        if x.custo_log is None:
            parser.error("--custo-log e obrigatorio para --dor logistica")
        pool = x.faturamento * x.custo_log
        pool_escopo = pool * x.alcance
        base = pool_escopo
    else:
        if x.sga is None or x.fatia is None:
            parser.error("--sga e --fatia sao obrigatorios para --dor processos/ia")
        pool = x.faturamento * x.sga * x.fatia
        pool_escopo = pool * x.alcance
        base = pool_escopo * x.manual
    ganhos = [base * m * x.headroom * x.realizacao for m in MELHORIA[x.dor]]
    avisos = []
    if ganhos[2] > pool_escopo * 0.30:
        avisos.append("Ganho otimista acima de 30% do pool do escopo: revisar parametros.")
    elif ganhos[2] > pool_escopo * 0.15:
        avisos.append("Ganho otimista acima de 15% do pool do escopo: conferir.")
    return ganhos, pool, pool_escopo, avisos


NIVEIS_K = (1.25, 1.5, 2.0)


def sugere_k(baseline, dependencia, atribuicao, fonte, sensivel):
    """Filtro de direcionamento do teto k (a validar).

    Qualquer fraqueza -> 1,25. As 4 forcas -> 2,0 (vai para os CPs). Demais casos -> 1,5.
    Cliente sensivel a preco: desce um nivel (2,0 -> 1,5; 1,5 -> 1,25; 1,25 fica), o que na pratica
    bloqueia o 2,0.
    Resposta ausente conta como neutra (e nunca libera o 2,0).
    """
    fraquezas, forcas, neutras = [], [], []

    def classifica(valor, forte, fraco, rotulo_forte, rotulo_fraco, rotulo):
        if valor is None:
            neutras.append(f"{rotulo}: sem resposta (neutra)")
        elif valor == forte:
            forcas.append(rotulo_forte)
        elif valor == fraco:
            fraquezas.append(rotulo_fraco)
        else:
            neutras.append(f"{rotulo}: {valor} (neutra)")

    classifica(baseline, "sim", "parcial", "baseline com 6 meses ou mais de historico", "baseline parcial", "baseline")
    classifica(dependencia, "pouco", "muito", "ganho pouco dependente da execucao do cliente",
               "ganho muito dependente da execucao do cliente", "dependencia")
    classifica(atribuicao, "sim", "pouco", "ganho atribuivel ao projeto sem muita disputa",
               "ganho dificil de atribuir ao projeto (fatores externos pesam)", "atribuicao")
    classifica(fonte, "sistema", "construir", "dado em sistema auditavel do cliente",
               "a Poli teria que construir a coleta do dado", "fonte")

    if fraquezas:
        nivel = 0
    elif len(forcas) == 4:
        nivel = 2
    else:
        nivel = 1
    motivos = [f"fraqueza: {f}" for f in fraquezas] + [f"forca: {f}" for f in forcas] + neutras
    if sensivel == "sim":
        if nivel > 0:
            nivel -= 1
        motivos.append("cliente sensivel a preco: desce um nivel (o teto de 2,0 fica bloqueado)")
    return NIVEIS_K[nivel], nivel, motivos


def main():
    a = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    # --- politica ---
    a.add_argument("--B", type=float, required=True, help="preco tecnico do projeto da candidata B, sem visita")
    a.add_argument("--visita", type=float, default=0.0, help="custo de visita embutido no fixo")
    a.add_argument("--sa", type=float, help="semanas-analista (para o ITIP efetivo)")
    a.add_argument("--phi", type=float, default=0.60, help="fracao fixa de B (padrao 0,60; faixa 0,50-0,70)")
    a.add_argument("--lam", type=float, default=0.25, help="premio de risco proporcional (padrao 0,25)")
    a.add_argument("--n", type=float, default=5.0, help="multiplo de B para a meta (padrao 5)")
    a.add_argument("--k", type=float, default=None,
                   help="teto do total em multiplos de B. Sem --k: usa o sugerido pelo filtro (se as respostas "
                        "foram passadas) ou 1,5")
    a.add_argument("--baseline", choices=("sim", "parcial"), help="filtro do k: historico do indicador")
    a.add_argument("--dependencia", choices=("pouco", "muito"), help="filtro do k: ganho depende do cliente executar")
    a.add_argument("--atribuicao", choices=("sim", "parte", "pouco"), help="filtro do k: ganho atribuivel ao projeto")
    a.add_argument("--fonte", choices=("sistema", "planilha", "construir"), help="filtro do k: fonte do dado")
    a.add_argument("--cliente-sensivel-preco", choices=("sim", "nao"), dest="sensivel",
                   help="filtro do k: cliente compara propostas ou ja objetou preco")
    a.add_argument("--H", type=float, default=0.0, help="franquia: ganho que o cliente teria sem o projeto (R$)")
    a.add_argument("--W", type=float, default=12.0, help="janela de reconhecimento em meses")
    a.add_argument("--fmin-pct", type=float, default=0.50, help="piso provisorio do fixo como fracao de B")
    # --- estimativa (opcional) ---
    a.add_argument("--dor", choices=MELHORIA)
    a.add_argument("--faturamento", type=float)
    a.add_argument("--pessoas", type=float, help="multinacional: pessoas na base do pool (processos/ia)")
    a.add_argument("--custo-pessoa", type=float, help="custo anual medio por pessoa em R$ (com --pessoas)")
    a.add_argument("--custo-log", type=float, help="custo logistico / receita (logistica)")
    a.add_argument("--sga", type=float, help="SG&A do setor / receita (processos e ia)")
    a.add_argument("--fatia", type=float, help="fatia da area no SG&A (processos e ia)")
    a.add_argument("--alcance", type=float)
    a.add_argument("--manual", type=float, default=1.0, help="fracao manual (processos e ia)")
    a.add_argument("--headroom", type=float, default=1.0)
    a.add_argument("--realizacao", type=float)
    a.add_argument("--alvo-min", type=float, default=0.20, help="variavel pessimista minimo, fracao do fixo")
    a.add_argument("--alvo-max", type=float, default=0.40, help="variavel pessimista maximo, fracao do fixo")
    a.add_argument("--limite-total", type=float, default=0.25,
                   help="(fixo+variavel)/ganho realista anual maximo (padrao 0,25)")
    a.add_argument("--sa-fase1", type=float, help="C2: semanas-analista da Fase 1 (diagnostico e plano)")
    a.add_argument("--sa-fase2", type=float, help="C2: semanas-analista da Fase 2 (implantacao assistida e medicao)")
    a.add_argument("--budget-min", type=float, help="menor proposta perdida por Budget no portfolio (R$)")
    a.add_argument("--budget-p25", type=float)
    a.add_argument("--budget-mediana", type=float)
    a.add_argument("--budget-p75", type=float)
    x = a.parse_args()
    if x.pessoas is not None:
        if x.custo_pessoa is None or x.dor not in ("processos", "ia"):
            a.error("--pessoas exige --custo-pessoa e --dor processos ou ia")
        x.faturamento, x.sga, x.fatia = x.pessoas * x.custo_pessoa, 1.0, 1.0

    avisos = []
    filtro_k = None
    if any(v is not None for v in (x.baseline, x.dependencia, x.atribuicao, x.fonte, x.sensivel)):
        k_sug, nivel_k, motivos_k = sugere_k(x.baseline, x.dependencia, x.atribuicao, x.fonte, x.sensivel)
        filtro_k = {"k_sugerido": k_sug, "nivel": nivel_k, "motivos": motivos_k}
    if x.k is not None:
        k = x.k
        origem_k = "informado pelo CN"
        if filtro_k and abs(k - filtro_k["k_sugerido"]) > 1e-9:
            avisos.append(f"k informado ({k}) difere do k sugerido pelo filtro ({filtro_k['k_sugerido']}): "
                          "registre o motivo no log.")
    elif filtro_k:
        k = filtro_k["k_sugerido"]
        origem_k = "sugerido pelo filtro"
    else:
        k = 1.5
        origem_k = "padrao (filtro nao respondido)"
    if k >= 2.0:
        avisos.append("k = 2,0 vai para os CPs.")
    B, phi, lam, n, H = x.B, x.phi, x.lam, x.n, x.H
    if not (0 < phi <= 1):
        a.error("--phi deve estar entre 0 e 1")
    if n - H / B <= 0:
        a.error("n - H/B deve ser positivo")

    # ---- politica ----
    F_proj = phi * B                        # fixo do projeto (sem visita)
    F = F_proj + x.visita                   # fixo cobrado (visita entra inteira)
    Fmin = x.fmin_pct * B + x.visita
    p = (1 + lam) * (1 - phi) / (n - H / B) if phi < 1 else 0.0
    cap_var = max((k - phi) * B, 0.0)       # teto do variavel
    meta_G = n * B
    be_G = H + (B - F_proj) / p if p > 0 else float("inf")      # variavel = B - F_proj
    cap_G = H + cap_var / p if p > 0 else float("inf")
    total_meta = F + min(p * max(0, meta_G - H), cap_var)

    def total_em(G):
        v = min(p * max(0.0, G - H), cap_var)
        return v, F + v

    tabela = []
    for rot, G in (("zero", 0.0), ("2xB", 2 * B), ("break-even", be_G), ("meta", meta_G), ("teto", cap_G)):
        if G == float("inf"):
            continue
        v, t = total_em(G)
        tabela.append({"ponto": rot, "ganho_capturado": R(G), "fixo": R(F), "variavel": R(v),
                       "total": R(t), "total_projeto_sem_visita": R(t - x.visita),
                       "vs_B": round((t - x.visita) / B - 1, 4)})

    # guardrails
    g = {
        "F_ge_Fmin": F >= Fmin,
        "total_G0_ge_Fmin": F >= Fmin,
        "p_entre_3_e_10": 0.03 <= p <= 0.10 if p > 0 else None,
        "phi_ge_60": phi >= 0.60,
        "n_entre_4_e_6": 4 <= n <= 6,
        "teto_definido": True,
        "teto_permite_meta": (k * B + x.visita) >= (F + p * max(0, meta_G - H)) - 1e-6,
        "k_ge_1_25": k >= 1.25,
    }
    if not g["F_ge_Fmin"]:
        avisos.append(f"Fixo R${F:,.0f} abaixo do piso R${Fmin:,.0f}: projeto pequeno demais para a C ou reduza r (aumente phi).")
    if g["p_entre_3_e_10"] is False:
        avisos.append(f"p = {p:.2%} fora de 3-10%: vai para os CPs.")
    if not g["phi_ge_60"]:
        avisos.append("phi abaixo de 60%: vai para os CPs.")
    if not g["n_entre_4_e_6"]:
        avisos.append("n fora de 4-6: vai para os CPs e exige justificativa registrada.")
    if not g["teto_permite_meta"]:
        avisos.append("O teto k*B corta a meta: com esse teto a C nunca chega ao preco de meta. Aumente k ou phi.")
    if not g["k_ge_1_25"]:
        avisos.append("k < 1,25 deixa pouco espaco acima de B (a validar): confira se a C compensa o risco.")
    if k * B < B:
        avisos.append("Teto total abaixo de B: a EJ nunca recebe o preco tecnico, mesmo no melhor cenario.")

    out = {
        "politica": {
            "B": R(B), "visita": R(x.visita), "phi": phi, "lambda": lam, "n": n, "k": k, "H": R(H),
            "teto_k": {"k_usado": k, "origem": origem_k, **(filtro_k or {})},
            "fixo_projeto_sem_visita": R(F_proj), "fixo_cobrado": R(F), "fixo_minimo": R(Fmin),
            "p": round(p, 4),
            "exposicao_EJ_G0": R(B - F_proj), "exposicao_EJ_G0_pct": round(1 - phi, 4),
            "break_even_G": R(be_G) if be_G != float("inf") else None,
            "break_even_xB": round(be_G / B, 2) if be_G != float("inf") else None,
            "meta_G": R(meta_G), "total_na_meta": R(total_meta),
            "teto_variavel": R(cap_var), "G_em_que_o_teto_vale": R(cap_G) if cap_G != float("inf") else None,
            "teto_total": R(F + cap_var),
            "parcelamento": "so sobre o fixo",
            "guardrails": g,
        },
        "tabela_receita": tabela,
    }
    out["politica"]["variavel_max_pct_B"] = round(cap_var / B, 3)
    if x.sa_fase1 is not None and x.sa_fase2 is not None and (x.sa_fase1 + x.sa_fase2) > 0:
        tot = x.sa_fase1 + x.sa_fase2
        out["politica"]["fixo_por_fase"] = {
            "arquetipo": "C2",
            "fase1": R(F_proj * x.sa_fase1 / tot + x.visita),
            "fase2": R(F_proj * x.sa_fase2 / tot),
            "obs": "fixo do projeto dividido por semanas-analista; a visita fica na Fase 1; B ja inclui a Fase 2",
        }
    if cap_var / B > 0.50:
        avisos.append(f"Variavel maximo = {cap_var / B:.0%} de B (> 50%): a success-fee v14 limitava o variavel a 50% do "
                      "preco tecnico; aqui vale o k (decisao do time pendente).")
    if x.budget_min is not None and x.budget_mediana is not None:
        def zona(v):
            if v < x.budget_min:
                return "abaixo do minimo: sem perda por budget registrada"
            if v <= x.budget_mediana:
                return "entre o minimo e a mediana: risco crescente"
            return "acima da mediana: onde a maioria das perdas por budget aconteceu"
        out["politica"]["perdas_por_orcamento"] = {
            "minimo": R(x.budget_min), "p25": R(x.budget_p25) if x.budget_p25 is not None else None,
            "mediana": R(x.budget_mediana), "p75": R(x.budget_p75) if x.budget_p75 is not None else None,
            "zona_fixo_cobrado": zona(F), "zona_total_maximo": zona(F + cap_var),
            "obs": "valor perdido = preco proposto, nao o budget declarado; so informativo",
        }
        if F + cap_var > x.budget_mediana:
            avisos.append("Total maximo da C acima da mediana das propostas perdidas por Budget do portfolio: "
                          "risco de rejeicao do preco no teto (so informativo).")
    if x.sa:
        out["politica"]["itip_efetivo_G0_sem_visita"] = R((F_proj - 1700) / x.sa)
        out["politica"]["itip_efetivo_B"] = R(B / x.sa)

    # ---- teste de sanidade (opcional) ----
    if x.dor and x.faturamento and x.alcance is not None and x.realizacao is not None:
        ganhos, pool, pool_escopo, av2 = estima_ganhos(x, a)
        avisos += av2
        per = x.W / 12.0
        cen = {}
        trava_todos = True
        for nome, ga in zip(NOMES, ganhos):
            G = ga * per                       # ganho capturado dentro da janela W
            v, t = total_em(G)
            trava = bool(p > 0 and p * max(0, G - H) >= cap_var - 1e-6)
            trava_todos = trava_todos and trava
            cen[nome] = {
                "ganho_anual_estimado": R(ga), "xB": round(ga / B, 2),
                "ganho_na_janela": R(G), "variavel": R(v), "total": R(t),
                "variavel_pct_do_fixo": round(v / F_proj, 3) if F_proj else None,
                "total_sobre_ganho_anual": round(t / ga, 4) if ga else None,
                "teto_prende": trava,
            }
        pess, real = cen["pessimista"], cen["realista"]
        flags = []
        vp = pess["variavel_pct_do_fixo"]
        if trava_todos:
            flags.append("DEGENERADA: o teto prende o variavel ate no cenario pessimista; o 'success fee' vira preco fixo "
                         "disfarcado e o percentual nao importa. Reveja o alcance (julgamento) ou aumente o teto.")
        elif vp is not None and vp > x.alvo_max:
            flags.append(f"p de politica entrega {vp:.0%} do fixo no pessimista (> {x.alvo_max:.0%}): "
                         "percentual folgado para o porte estimado; considere o p de referencia.")
        elif vp is not None and vp < x.alvo_min:
            flags.append(f"p de politica entrega so {vp:.0%} do fixo no pessimista (< {x.alvo_min:.0%}): "
                         "a fee pode ser irrelevante no pior caso; confira se o ganho estimado esta baixo.")
        if real["total_sobre_ganho_anual"] and real["total_sobre_ganho_anual"] > x.limite_total:
            flags.append(f"Cobranca total passa de {x.limite_total:.0%} do ganho realista anual: o cliente paga caro "
                         "relativo ao que ganha (a validar).")
        if F_proj / real["ganho_anual_estimado"] > x.limite_total if real["ganho_anual_estimado"] else False:
            flags.append("O fixo sozinho ja passa do limite de cobranca total: nao ha espaco para variavel.")
        if pess["xB"] <= 1:
            flags.append("Ganho pessimista nao passa de 1x o preco: nao use a estimativa como argumento de valor.")
        # p de referencia (regra do quiz): so referencia, nunca substitui o p de politica
        G_pess = ganhos[0] * per
        p_ref_raw = ((x.alvo_min + x.alvo_max) / 2) * F_proj / G_pess if G_pess > 0 else 0.0
        p_ref = min(max(p_ref_raw, 0.03), 0.10)
        alvo_med = (x.alvo_min + x.alvo_max) / 2
        alternativas = []
        for rotulo, ga in (("calibrado_no_pessimista", ganhos[0]), ("calibrado_no_realista", ganhos[1]),
                           ("calibrado_no_otimista", ganhos[2])):
            Gc = ga * per
            bruto = alvo_med * F_proj / Gc if Gc > 0 else 0.0
            pa = min(max(bruto, 0.03), 0.10)
            recebido = {}
            for nome, gg in zip(NOMES, ganhos):
                v = min(pa * max(0.0, gg * per - H), cap_var)
                recebido[nome] = {"variavel": R(v), "total": R(F + v)}
            alternativas.append({"alternativa": rotulo, "p": round(pa, 4), "p_bruto": round(bruto, 4),
                                 "recebido": recebido})
        pol = {"alternativa": "p_de_politica", "p": round(p, 4), "p_bruto": round(p, 4), "recebido": {}}
        for nome, gg in zip(NOMES, ganhos):
            v = min(p * max(0.0, gg * per - H), cap_var)
            pol["recebido"][nome] = {"variavel": R(v), "total": R(F + v)}
        alternativas.insert(0, pol)
        out["teste_de_sanidade"] = {
            "AVISO": "Estimativa top-down (a validar). Nunca define o preco, nunca e prometida ao cliente, nunca vai no deck.",
            "pool": R(pool), "pool_escopo": R(pool_escopo),
            "janela_W_meses": x.W,
            "cenarios": cen,
            "p_referencia": round(p_ref, 4),
            "p_referencia_bruto": round(p_ref_raw, 4),
            "p_referencia_obs": "alvo medio de variavel pessimista x fixo / ganho pessimista na janela, limitado a 3-10%; "
                                "so referencia para o CN decidir no Checkpoint 2",
            "p_alternativas": alternativas,
            "flags": flags,
        }
        avisos += [f for f in flags]

    out["avisos"] = avisos
    json.dump(out, sys.stdout, ensure_ascii=False, indent=2)
    print()


if __name__ == "__main__":
    main()
