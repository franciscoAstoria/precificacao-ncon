#!/usr/bin/env python3
"""Relatorio interno (so para o CN) com o motivo de cada escolha do quiz e a conferencia do calculo.

Uso: python relatorio_cn.py entrada.json saida.pdf
entrada.json: {"cliente","data","resumo","secoes":[{"topico","escolha","motivo"}],
  "tabelas":[{"titulo","linhas":[[...],[...]]}], "alertas":[...]}
Nunca anexe este relatorio a proposta nem ao slide: ele traz cenarios de ganho e premissas internas.
"""
import json, sys
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle, KeepTogether

D = "/usr/share/fonts/truetype/dejavu/"
pdfmetrics.registerFont(TTFont("S", D + "DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("SB", D + "DejaVuSans-Bold.ttf"))
pdfmetrics.registerFontFamily("S", normal="S", bold="SB", italic="S", boldItalic="SB")
INK, ACC = colors.HexColor("#1f2933"), colors.HexColor("#0b5cab")
body = ParagraphStyle("b", fontName="S", fontSize=9.5, leading=13.5, textColor=INK, spaceAfter=4)
small = ParagraphStyle("s", parent=body, fontSize=8.5, leading=11, spaceAfter=0)
smallb = ParagraphStyle("sb", parent=small, fontName="SB")
h1 = ParagraphStyle("h1", fontName="SB", fontSize=16, leading=20, textColor=ACC, spaceAfter=4)
h2 = ParagraphStyle("h2", fontName="SB", fontSize=11.5, leading=15, textColor=ACC, spaceBefore=10, spaceAfter=4)
topic = ParagraphStyle("t", parent=body, fontName="SB", spaceBefore=6, spaceAfter=1)
tag = ParagraphStyle("tag", parent=small, textColor=colors.HexColor("#b03a2e"), fontName="SB")


def tabela(linhas, larguras=None):
    n = len(linhas[0])
    larguras = larguras or [17 / n] * n
    data = [[Paragraph(str(c), smallb if r == 0 else small) for c in row] for r, row in enumerate(linhas)]
    t = Table(data, colWidths=[w * cm for w in larguras], repeatRows=1)
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#c5d0dc")),
                           ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eaf1f9")),
                           ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
    return t


def main(entrada, saida):
    d = json.load(open(entrada))
    s = [Paragraph(f"Relatório de validação do cálculo: {d['cliente']}", h1),
         Paragraph("USO INTERNO DO CN. Não anexar à proposta nem ao slide.", tag),
         Paragraph(d.get("data", ""), small), Spacer(1, 6), Paragraph(d["resumo"], body)]
    s.append(Paragraph("Por que cada opção foi escolhida", h2))
    for sec in d["secoes"]:
        s.append(KeepTogether([Paragraph(f"{sec['topico']}: {sec['escolha']}", topic), Paragraph(sec["motivo"], body)]))
    for t in d.get("tabelas", []):
        s.append(KeepTogether([Paragraph(t["titulo"], h2), tabela(t["linhas"], t.get("larguras"))]))
    if d.get("alertas"):
        s.append(Paragraph("O que conferir antes de usar", h2))
        for a in d["alertas"]:
            s.append(Paragraph(a, body, bulletText="•"))
    SimpleDocTemplate(saida, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.8 * cm, bottomMargin=1.8 * cm,
                      title=f"Relatório do CN: {d['cliente']}").build(s)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2])
