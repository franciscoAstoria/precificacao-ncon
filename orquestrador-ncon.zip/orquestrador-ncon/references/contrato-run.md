# Contrato `ncon.run/1` (v0.3, 17/11/2026)

Objeto único que cresce a cada skill. Cada skill recebe o run da anterior, **só acrescenta a sua seção**, e devolve o run completo mais o briefing em Markdown. Correção de dado de outra seção vira item em `correcoes`, nunca edição direta.

Regras de formato:
- JSON em bloco ```json no fim da resposta, depois do briefing, com `"contrato": "ncon.run/1"` na primeira linha.
- Número quantitativo relevante: `valor`, `fonte`, `confirmado` (true quando o CN validou).
- Desconhecido = `null`. Nunca inventar, nunca omitir a chave.
- Ajuste do CN: `{campo, de, para, motivo}`. É o que alimenta o log de calibração.
- Tudo em `interno` (estimativa de ganho, cenários, plano B) nunca vai ao deck nem ao cliente.

## Cabeçalho

```json
{
  "contrato": "ncon.run/1",
  "run_id": "AAAA-MM-DD-empresa-NN",
  "modo": "normal | backtest",
  "backtest_ate": null,
  "cn": "",
  "criado_em": "",
  "etapas_concluidas": [],
  "validacoes": [{"etapa": "", "checkpoint": "", "resultado": "de_acordo|ajustado", "ajustes": []}],
  "correcoes": [{"secao": "", "campo": "", "de": "", "para": "", "origem": "", "motivo": ""}],
  "alertas": [{"origem": "", "nivel": "info|atencao|bloqueio", "texto": ""}],
  "pendencias": [{"origem": "", "pergunta": "", "para": "CP|CN|time"}]
}
```

## `cliente` (escrito pelo dimensionamento)

```json
"cliente": {
  "empresa": "",
  "pipedrive": {"deal_id": null, "org_id": null, "estagio": ""},
  "setor": {"valor": "", "fonte": "apollo|pipedrive|cn"},
  "faturamento_brl": {"valor": null, "faixa": "", "fonte": "", "confirmado": false},
  "funcionarios": null, "decisores": null, "gerentes": null, "pais_escopo": "BR",
  "porte_pessoa_fisica_ou_micro": false,
  "canal": "inbound | outbound | indicacao | fidelizacao",
  "interlocutor": {"nome": "", "cargo": "", "decisor": null},
  "reunioes_fathom": [{"id": "", "data": "", "tipo": "AT|aprofundamento"}],
  "dor_principal": {"texto": "", "trecho": ""},
  "area_afetada": "core | nao_core | misto",
  "sinais": {
    "budget": {"mencionado": false, "trecho": ""},
    "objecao_preco": false, "pediu_parte_variavel": false, "concorrentes": false,
    "reacao_at": {"nota": null, "trechos": []}
  },
  "indicador_candidato": {
    "nome": null, "metodo_calculo": null, "fonte_dado": null, "trechos": [],
    "baseline_meses": null, "operacao_rodando": null, "controladoria_na_at": null
  },
  "visita": {"cidade": null, "dias": null, "pessoas": null},
  "prazo_cliente": null,
  "objetivos": [{"texto": "", "trecho": ""}],
  "contexto_resumo": "",
  "citacoes_candidatas": [{"texto": "", "autor": "", "cargo": "", "literal": true, "reuniao_id": ""}],
  "logo": null,
  "semelhantes_apollo": [{"dado": "", "valor_sugerido": null, "base": "", "confirmado": false}]
}
```

- `objetivos`: de 3 a 5, em linguagem do cliente, cada um com o trecho da AT que o sustenta. A `proposta-ncon` os usa no slide de Objetivos sem voltar ao Fathom.
- `contexto_resumo`: 2 ou 3 parágrafos sobre o negócio do cliente e a dor, para o Sumário da proposta.
- `citacoes_candidatas`: de 2 a 3 falas **literais** da transcrição (`literal: true`) com autor e cargo. Sem transcrição, reconstrução da ata com `literal: false`.
- `logo`: caminho do PNG do logo, se o CN já anexou; `null` caso contrário (a `proposta-ncon` pede).

`semelhantes_apollo`: quando CN e cliente não souberem um dado quantitativo (processos, reuniões, custo por pessoa), a skill oferece estimativa por empresas de porte, faturamento e setor parecidos. Só vale depois de `confirmado = true`.

## `dimensionamento` (escrito pelo dimensionamento-ncon)

```json
"dimensionamento": {
  "portfolios": ["GP"],
  "selo_geral": "F | R | A",
  "prioridade_cliente": {"valor": "agilidade | abrangencia | indefinida", "explicita": false, "trecho": null},
  "opcoes": [
    {"id": "A", "perfil": "menor", "descricao": "",
     "escopo_essenciais": [], "opcionais_incluidos": [], "removidos_vs_B": [],
     "equipe": [{"papel": "consultor", "qtd": 2}, {"papel": "coordenador", "qtd": 1}],
     "semanas": 0, "analistas": 0, "sa": 0,
     "etapas": [{"id": "gp.asis", "nome": "", "portfolio": "GP", "semanas": 0, "semanas_teto": 0,
                 "semana_inicio": 0, "semana_fim": 0, "compartilha_semana_com": null, "opcional": false,
                 "calculo": "", "selo": "R"}],
     "fases": null},
    {"id": "B", "perfil": "maior", "...": "mesma estrutura"}
  ],
  "pd_rota": null,
  "faixa_padrao_teto": {"padrao": 0, "teto": 0},
  "premissas": [{"texto": "", "custo_da_variacao": ""}],
  "referencias_drive": [],
  "avisos_para_precificacao": {"ai_scan_preco_fixo_invalido": false},
  "ajustes_do_cn": []
}
```

- `etapas[].id` vem de `catalogo-etapas.md` (mesmo vocabulário da `proposta-ncon`); `semana_inicio` e `semana_fim` são o calendário, e `semanas` soma o total. `pd_rota` (`"A"` ou `"B"`) só no PD.
- `fases` só no C2: `[{"nome": "", "semanas": 0, "analistas": 0, "sa": 0}]` (Fase 1 diagnóstico e plano; Fase 2 implantação assistida).
- `equipe` é lista de papéis. A `proposta-ncon` e a `precificacao` leem daqui, sem papel fixo embutido.
- Híbrido: `portfolios` com mais de um item; cada etapa traz o portfólio de origem.
- A e B: A = escopo menor, B = escopo maior. `prioridade_cliente` registra o que o CN respondeu (agilidade → escopo menor, ITIP tende a subir; abrangência → escopo maior, duração maior, ITIP tende a cair). `removidos_vs_B` lista o que sai da B para a A, escolhido pelo CN.

## `precificacao` (escrito pela precificacao-ncon)

```json
"precificacao": {
  "itip_base": {"valor": 0, "portfolio_usado": "", "status": "a_validar | validado"},
  "custo_fixo": 1700,
  "fatores": [{"nome": "porte|area|setor|canal|reacao", "valor": 1.0, "justificativa": "", "evidencia": "", "status": "a_validar|validado"}],
  "multiplo": {"bruto": 1.0, "aplicado": 1.0, "travado": false},
  "opcoes": [
    {"id": "A", "sa": 0, "preco_projeto": 0, "visita": 0, "preco_final": 0,
     "parcelas_max": 0, "itip_efetivo": 0,
     "escada": [{"desconto_pct": 5, "preco": 0, "prazo_fechamento": ""}]},
    {"id": "B", "recomendada": true, "...": "idem"}
  ],
  "comparacao_banco": [{"proposta": "", "itip": 0}],
  "sinais_success_fee": {"sugerir": false, "motivos": [{"sinal": "porte_pequeno|budget_reduzido|objecao_preco|inbound|pessoa_fisica|cliente_pediu", "trecho": ""}]},
  "outlier": false,
  "ajustes_do_cn": []
}
```

## `success_fee` (escrito pela success-fee; só se o gate abrir)

```json
"success_fee": {
  "elegivel": true, "motivo_eliminacao": null, "o_que_faria_voltar": null,
  "arquetipo": "C1 | C2",
  "parametros": {"phi": 0.6, "p": 0.10, "n": 5, "lambda": 0.25, "k": 1.5, "H": 0, "W_meses": 12},
  "fixo_cobrado": 0, "fixo_por_fase": null, "visita": 0, "parcelas_max": 0,
  "variavel_max": 0, "teto_total": 0,
  "protocolo_medicao": {"unidade_formula": "", "baseline_periodo": "", "ajustes": [], "trava_servico": "", "quem_aceita": "", "prazo_aceite": "", "disputa": "", "exclusoes": []},
  "responsavel_apuracao": "",
  "interno": {"teste_sanidade": {}, "p_alternativas": [], "flags": [], "zona_perdas_budget": "", "plano_b": ""},
  "recomendacao": {"levar_c": true, "justificativa": "", "mudaria_de_ideia_se": ""},
  "ajustes_do_cn": []
}
```

- `fixo_cobrado` já inclui a visita. `fixo_por_fase` só no C2: `[{"fase": "Fase 1", "valor": 0}]`.

## `decisao_final` (escrito pela orquestradora)

```json
"decisao_final": {
  "estruturas_para_deck": ["B"],
  "estrutura_recomendada": "B",
  "a_apresentada": false,
  "motivo_a": "",
  "desconto": null,
  "plano_b_interno": "",
  "motivo": ""
}
```

Combinações aceitas em `estruturas_para_deck` (no máximo 2; decisão de 17/11):
- `["B","C"]`: quando a C foi aprovada. **A A é sempre descartada quando a C é apresentada.**
- `["A","B"]`: sem C, quando o CN e a orquestradora concordam que a A faz sentido (budget, porte, objeção de preço).
- `["B"]`: sem C e sem A. É o padrão quando não há sinal claro para oferecer a A, ou quando o cliente deixou explícito que quer o escopo mais completo.
- `["A"]`: o cliente deixou explícito que quer algo mais rápido. Só a A vai ao deck. Se a C também foi aprovada, a decisão fica com o CN (a C parte do preço da B), com alerta.
- `["A","C"]` e `["A","B","C"]` não existem.

`decisao_final.desconto`: `null` ou `{"pct": 5, "prazo_fechamento": "AAAA-MM-DD", "estruturas": {"B": 0}}`, onde o número é o preço **já com desconto** de cada estrutura (vem da `escada` da precificação; só sobre o preço do projeto, nunca sobre a visita). Acima de 10%, só com os CPs.

`decisao_final.a_apresentada`: `true | false`, com `motivo_a` (os sinais que levaram a incluir ou descartar a A, citando budget, porte e reação na AT). A A segue calculada em `precificacao.opcoes` mesmo quando não vai ao deck.

## `proposta` (escrito pela proposta-ncon)

```json
"proposta": {
  "entrada": {
    "portfolio_template": "gp | pm | pg | pd | aiscan",
    "modo_escopo": "unico | menor_e_maior | duas_remuneracoes",
    "estruturas": [{"id": "B", "titulo_slide": "", "valor": 0, "parcelas_max": 0, "semanas": 0,
                    "equipe": [{"papel": "consultor", "qtd": 2}], "slide": "comercial | remuneracao"}],
    "contatos": [{"nome": "", "cargo": "", "email": "", "telefone": null}],
    "data_apresentacao": "AAAA-MM-DD", "fonte_data": "calendar | cn",
    "citacao": {"texto": "", "autor": "", "literal": true},
    "objetivos": [], "opcionais": [], "modulo_adicional": null, "logo": null
  },
  "saida": {
    "pptx": "", "pdf": "",
    "base_usada": [{"proposta": "", "etapas": ["gp.asis"]}],
    "adaptacoes": [], "itens_ineditos": [], "placeholders_restantes": [],
    "conferencia": {"ok": true, "itens": [{"campo": "", "esperado": "", "no_deck": "", "ok": true}]},
    "qa": {"ok": true, "falhas": [], "falsos_positivos": []}
  }
}
```

- A **`proposta-ncon` monta `entrada` sozinha** a partir do run (a orquestradora não a preenche) e a grava no run para rastreio. `modo_escopo`: `unico` (`["B"]` ou `["A"]`), `menor_e_maior` (`["A","B"]`: escopos diferentes) e `duas_remuneracoes` (`["B","C"]`: mesmo escopo, remuneração diferente).
- Contatos, data (quando o Calendar não tem evento), escolha da citação e opcionais são perguntados **no único checkpoint da proposta**, não na decisão final.
- `saida.conferencia` compara o deck com o run (valor, parcelas, semanas, equipe, etapas); `placeholders_restantes` lista o que o CN ainda precisa preencher (ex.: telefone); `itens_ineditos` são slides criados sem base no banco (candidatos a entrar nele).

## `log` (escrito pela orquestradora)

```json
"log": {"linha": null, "link": null, "campos_gravados": []}
```

## `registro_atipico` (escrito pela orquestradora)

```json
"registro_atipico": {"atipica": false, "motivos": [], "arquivo_drive": null, "salvo_sem_nome_cliente": false}
```

## Campos obrigatórios na passagem (a orquestradora confere)

| Passagem | Campos que precisam existir |
|---|---|
| dimensionamento → precificação | `dimensionamento.opcoes[].etapas[].id` e `.semana_inicio/.semana_fim`, `cliente.empresa`, `cliente.canal`, `cliente.faturamento_brl` (ou faixa), `cliente.setor.valor`, `cliente.area_afetada`, `dimensionamento.portfolios`, `dimensionamento.opcoes[A,B].sa`, `.semanas`, `.analistas`, `.equipe`, `.escopo_essenciais`, `validacoes` com o checkpoint de escopo |
| precificação → gate | `precificacao.opcoes[B].preco_projeto`, `.preco_final`, `.parcelas_max`, `precificacao.multiplo.aplicado`, `precificacao.sinais_success_fee` |
| gate → success-fee | tudo acima, mais `cliente.indicador_candidato.nome` e o portfólio no conjunto elegível |
| success-fee → decisão final | `success_fee.elegivel` e, se verdadeiro, `parametros`, `fixo_cobrado`, `teto_total`, `protocolo_medicao`, `responsavel_apuracao` |
| decisão final → proposta | `decisao_final.estruturas_para_deck`, `precificacao.opcoes[].preco_final` e `.parcelas_max` de cada estrutura do deck, `dimensionamento.opcoes[].etapas[].id` com semanas e `equipe`, `cliente.objetivos` e `cliente.contexto_resumo`; se a C vai ao deck, `success_fee` completo (fixo, parâmetros, teto, protocolo). Contatos, data e citação a proposta coleta no checkpoint dela |
