# Catálogo de etapas (v0.1, 17/11/2026)

Vocabulário único entre `dimensionamento-ncon` (que emite) e `proposta-ncon` (que lê). Cada item de `dimensionamento.opcoes[].etapas[]` carrega o `id` daqui, em vez de só o nome livre.

## Campos de cada etapa no run

```json
{"id": "gp.asis", "nome": "Mapeamento AS IS", "portfolio": "GP",
 "semanas": 2, "semanas_teto": 3, "semana_inicio": 2, "semana_fim": 3,
 "calculo": "20 reuniões ÷ (4 × 2)", "selo": "F", "compartilha_semana_com": null}
```

- `semanas` é o esforço da etapa e **soma o total** da opção. `semana_inicio` e `semana_fim` são o calendário (a partir da semana 1).
- Etapa que divide a semana com outra (ex.: Documentação Final com os POPs): `semanas = 0`, `semana_inicio = semana_fim =` a semana compartilhada e `compartilha_semana_com` com o id da outra. Não soma semana própria.
- Semana de marcação extra (setor nichado ou sem contatos): entra em `gp.asis` (ou `pm.benchmark`), somada às semanas dele, e o `calculo` explica.
- Etapa de escopo que o catálogo não tem: `id` = `<portfolio>.outro:<slug>`, com `nome` livre. A `proposta-ncon` compõe o slide a partir do banco e lista o item em `itens_ineditos`.
- Opcional entra como etapa normal, com `opcional: true`.

## Ids por portfólio (slides do template na `proposta-ncon`)

| id | Etapa na proposta | Slides do template |
|---|---|---|
| `gp.imersao` | Imersão no contexto | gp 7 |
| `gp.asis` | Mapeamento AS-IS | gp 8-9 |
| `gp.gargalos` | Identificação de gargalos e soluções | gp 10-14 |
| `gp.tobe` | Mapeamento TO-BE | gp 15-16 |
| `gp.pop` | Elaboração de Manuais (POPs) | gp 17-18 |
| `gp.chatbot` | Manual Conversacional (opcional) | sem slide nativo (banco: Sotreq) |
| `gp.doc` | Documentação Final | gp 19-20 |
| `pm.imersao` | Imersão no contexto | pm 7-8 |
| `pm.questionario` | Elaboração do questionário | pm 9-10 |
| `pm.rodagem` | Rodagem (terceirizada) | pm 11 |
| `pm.benchmark` | Entrevistas de benchmark (modo benchmarking) | banco: Mercosul, Stanley |
| `pm.analise` | Análise das respostas (dashboard) | pm 12-13 |
| `pm.planos` | Planos de ação | pm 14-15 |
| `pm.doc` | Documentação Final | pm 16-17 |
| `pg.imersao` | Imersão (1, 1.1 a 1.3) | pg 8-13 |
| `pg.diagnostico` | Diagnóstico de Maturidade (2.1, 2.2) | pg 14-16 |
| `pg.fathom` | Implementação do Fathom | pg 17-18 |
| `pg.benchmark` | Benchmark de referências | pg 19 |
| `pg.papeis` | Papéis e responsabilidades | pg 20-21 |
| `pg.ritos` | Reuniões e ritos | pg 22-24 |
| `pg.cultura` | Cultura e engajamento | pg 25-28 |
| `pg.conhecimento` | Gestão do conhecimento | pg 29-30 |
| `pg.indicadores` | Indicadores | pg 31 |
| `pg.plano` | Plano de implementação | pg 32-33 |
| `pg.doc` | Documentação Final | pg 34-35 |
| `pd.imersao` | Etapa 1, Imersão de contexto | pd 9-12 |
| `pd.campo` | Etapa 2, Evidência de campo (2.1 a 2.3) | pd 13-20 |
| `pd.sintese` | Etapa 3, Síntese e concepção (3.1 a 3.7) | pd 21-32 |
| `pd.especificacao` | Etapa 4, Especificação e prototipação (NTec) | pd 33 |
| `pd.doc` | Etapa 5, Documentação Final | pd 34-35 |
| `ai.imersao` | Fase 1, Imersão no contexto (Semanas 1-2) | aiscan 8-12 |
| `ai.discovery` | Fase 2, Discovery e casos de uso (AS IS, casos de uso, priorização e roadmap: Semanas 3 a N) | aiscan 13-25 |
| `ai.doc` | Fase 3, Documentação Final (Semana N) | aiscan 26-27 |

## Regras de calendário que o dimensionamento aplica

- **GP** (`calcula.py`): `gp.imersao` na semana 1; `gp.asis`; `gp.gargalos`; depois a "documentação" do script se abre em `gp.tobe` (documentação − 1 semana) e `gp.pop` (1 semana, a última). Com documentação de 1 semana, `gp.tobe` e `gp.pop` dividem essa semana (`gp.tobe` com `semanas = 0`). `gp.doc` divide a última semana com `gp.pop` (`semanas = 0`), salvo se o CN tiver incluído a semana opcional de Documentação Final (Tenda), caso em que ela soma 1 semana própria.
- **GTO**: etapas do GP acima (imersão de 2 semanas) mais as etapas de P&G que o CP informar, cada uma com o seu `pg.*`. Sem detalhe do CP, `pg.outro:modulos-pg` com as semanas informadas e um alerta pedindo o detalhe.
- **PM terceirizada:** `pm.imersao`, `pm.rodagem`, `pm.analise`, `pm.doc`. **PM benchmarking:** `pm.imersao`, `pm.benchmark`, `pm.outro:versao-e-ajuste`, `pm.doc`.
- **AI Scan:** `ai.imersao` nas Semanas 1-2; `ai.discovery` da Semana 3 à N−1 (ou N, se `ai.doc` dividir a última); `ai.doc` na Semana N.
- **P&G e PD** (sem regra de cálculo): o CN ou o CP informa as semanas por módulo e a skill registra com os ids acima. No PD, `dimensionamento.pd_rota` = `"A"` (cliente externo, entrevistas) ou `"B"` (cliente interno, mapeamento).
- **Híbridos:** concatene as etapas na ordem do cronograma real; imersão e diagnóstico contam uma vez (um só `*.imersao`, com `portfolio` de origem em cada etapa).
