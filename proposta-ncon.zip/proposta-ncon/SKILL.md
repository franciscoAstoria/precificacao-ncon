---
name: "proposta-ncon"
description: "Sexta e última etapa do fluxo de proposta do NCon (Poli Júnior), chamada pela orquestrador-ncon depois da decisão final. Lê o ncon.run (cliente, dimensionamento, precificação, success fee e decisão final) e gera o deck .pptx e o PDF com o visual exato dos modelos oficiais de GP, GTO, PM, P&G, PD e AI Scan, com uma ou duas estruturas (A, B, ou B e C com o slide de remuneração). Ancora na proposta mais parecida do banco interno, valida o plano com o CN em um único checkpoint, confere o deck contra o run e devolve a seção proposta do run. Não dimensiona, não precifica, não decide estruturas nem desconto, não busca contexto de novo e não grava o log."
---

# Proposta NCon

**Onde você entra:** dimensionamento → precificação → gate → success fee → decisão final → **proposta (esta)**. A `orquestrador-ncon` chama você com o `ncon.run` (contrato em `orquestrador-ncon/references/contrato-run.md`). Você **só monta o deck**: não chame outra skill, não refaça perguntas que o run já responde, não busque Pipedrive, Fathom nem Apollo, não decida estruturas, preço, parcelas ou desconto (vêm do run) e não grave o log. Termina devolvendo o run com a sua seção `proposta`, mais o deck.

## Economia de contexto (regra de ouro)
Leia cada arquivo só no momento indicado. Etapa 2: `references/catalogo-etapas.md` (em `orquestrador-ncon/references/`), `references/indice.md` e **só** o texto da(s) proposta(s)-base em `references/propostas/` (mais `entregaveis.md` se houver opcionais; `institucional.md` só se houver dúvida de portfólio ou o CN pedir case). Portfólio AI Scan: `references/aiscan.md`. PD: `references/pd.md`. Geração: `references/fase3-tecnico.md` (obrigatório, inteiro), a skill pptx e só a seção do template em `references/mapa-templates.md`. Nunca abra todos os textos do banco; use grep; renderize só os slides variáveis ou alterados.

## Princípio central: nunca partir do zero
Ancore sempre na proposta mais parecida do banco. Escopo diferente: componha etapa a etapa com textos de propostas diferentes e crie só o inédito, imitando estilo e nível de detalhe do banco. Proponha, não pergunte em aberto: "baseei na X, adaptei as etapas 2 e 4; confirma?". Modelo anexado pelo CN (.pptx ou Drive) tem prioridade sobre banco e templates: confirme se vale como base de conteúdo, visual ou ambos, e aplique antes `references/modelo-do-usuario.md`. Se for uma proposta boa e inédita, ofereça adicioná-la ao banco.

## Etapa 1: Entradas do run
Leia, sem perguntar ao CN:

| O que | Onde no run |
|---|---|
| Portfólio(s) e template | `dimensionamento.portfolios` (mapa abaixo) |
| Estruturas do deck, recomendada, desconto | `decisao_final.estruturas_para_deck`, `.estrutura_recomendada`, `.desconto` |
| Preço e parcelas "em até Nx" de cada estrutura | `precificacao.opcoes[].preco_final` e `.parcelas_max` (C: `success_fee.fixo_cobrado` e `.parcelas_max`) |
| Etapas, semanas e calendário | `dimensionamento.opcoes[].etapas[]` (`id` do catálogo, `semana_inicio`, `semana_fim`, `opcional`) |
| Equipe | `dimensionamento.opcoes[].equipe` (lista de papéis; a equipe sempre inclui o coordenador) |
| Escopo que sai da A | `dimensionamento.opcoes[A].removidos_vs_B` |
| Empresa, objetivos, contexto, citações, logo, rota do PD | `cliente.empresa`, `.objetivos`, `.contexto_resumo`, `.citacoes_candidatas`, `.logo`, `dimensionamento.pd_rota` |
| Parte variável (se C) | `success_fee` inteiro (parâmetros, teto, `protocolo_medicao`, `fixo_por_fase`) |

Mapa de template: GP → `template-gp`; PM → `template-pm`; P&G → `template-pg`; PD → `template-pd`; AI Scan → `template-aiscan`; **GTO** e híbridos → o template do portfólio principal, com as etapas dos outros compostas a partir do banco e do template do outro portfólio (referência: Tenda-GP-PG; GTO usa `template-gp` mais as etapas de P&G, sem template próprio, decisão de 17/11).

Se faltar algo que **não** é conteúdo do deck (preço, parcelas, etapas, equipe, estruturas), pare e devolva à orquestradora a lista do que falta. Conteúdo do deck que falte (objetivos, contexto, citação, logo) você pede ao CN no checkpoint.

## Etapa 2: Plano do deck (briefing em texto)
Antes de qualquer slide, monte e mostre ao CN, em texto curto:
1. **Template e proposta-base** (de `indice.md`) e, etapa a etapa, de onde vem o texto: "Etapa 1 gp.imersao: Ascenty; gp.chatbot: Sotreq; inédita: …".
2. **Modo de escopo** (derive de `estruturas_para_deck`; grave em `proposta.entrada.modo_escopo`):
   - `unico` (`["B"]` ou `["A"]`): um slide comercial, sem rótulo de opção.
   - `menor_e_maior` (`["A","B"]`): o deck descreve o escopo da B. O que sai na A (`removidos_vs_B`) segue a regra do **módulo adicional**: etapa ou entregável entra com "(Adicional - Opção B)" no título e bloco próprio no cronograma; sub-item solto leva o rótulo no próprio bullet. Dois slides comerciais lado a lado, **"Proposta Comercial - Opção A"** e **"- Opção B"**; a Equipe cobre os dois ("2 Consultores por 5 a 7 semanas"). A recomendada vem primeiro.
   - `duas_remuneracoes` (`["B","C"]`): mesmo escopo e mesma equipe. Slide comercial **"Proposta Comercial - Opção B"** e, logo depois, o slide de remuneração **"Opção C"** (próxima seção).
3. **Contexto, objetivos e citação:** Sumário a partir de `contexto_resumo`; Objetivos a partir de `cliente.objetivos`; citação entre `citacoes_candidatas`.
4. **Itens inéditos** (sem base no banco) e alertas do run que mudam o texto.

## Etapa 3: Checkpoint único (um pop-up, até 4 perguntas)
Pergunte só o que o run não tem. O que passar de 4 vai em texto numerado na mesma mensagem.
1. **Plano:** "Base: [X]; adaptações: [lista]; estruturas: [modo]. De acordo?" → De acordo (Recomendado) · Trocar a base · Ajustar etapas.
2. **Citação:** as 2 ou 3 candidatas com autor → uma delas (a literal primeiro) · Outra. Se só houver reconstrução da ata (`literal: false`), diga que será marcada como reconstrução e peça a validação.
3. **Quem assina e a data:** o nome do CN já está em `cn`; falta o segundo assinante (nome, cargo e e-mail `nome.sobrenome@polijunior.com.br`; nunca deduza da base). Data: Google Calendar (evento de apresentação do lead); sem evento, pergunte. Telefone não informado vira placeholder `XX XXXXX-XXXX` com aviso.
4. **Específicos do portfólio e opcionais:** entregáveis opcionais aplicáveis (1 linha cada, sinalizando interesses citados na AT); AI Scan: slides opcionais a exibir e se mantém os dois cases; PD: rota, se `pd_rota` vier `null`; módulo adicional fechado ou opcional, se houver.

O logo do cliente, se `cliente.logo` for `null`, é pedido em texto na mesma mensagem (PNG, transparente de preferência); sem PNG, busca na web **só com aprovação**, depois de mostrar. Respostas diferentes do recomendado viram `{campo, de, para, motivo}` em `ajustes_do_cn` (de `proposta`).

## Regras de conteúdo
- **Objetivos**: slide PRÓPRIO, separado do Sumário (modelo canônico: template-pm slide 5, "Principais desafios da [Cliente]"; objetivos à esquerda com setas azuis, citação no balão). O Sumário leva só recomendação e "Contexto:" em 2 ou 3 parágrafos, sem bloco de objetivos. Ideal 3 a 4 objetivos, máximo 5. Técnica no `fase3-tecnico.md`.
- **Citação**: fala literal da transcrição, com autor. Reconstrução da ata fica explícita e validada. Nunca invente nem apresente reconstrução como literal.
- **Etapas**: "Etapa N - Nome" + Objetivo Estratégico / Principais Atividades / Entregável de Valor; sub-etapas X.1/X.2 para etapas grandes; slides de exemplo e de entrega intercalam após a etapa. Negrito em termos-chave, nunca num item inteiro. (AI Scan usa "Fase N": ver `aiscan.md`.)
- **Semanas por etapa**: use `semana_inicio` e `semana_fim` do run. Etapa que `compartilha_semana_com` outra divide o bloco no cronograma, separadas por traço.
- **Documentação Final**: última etapa, obrigatória; mescla só se o CN avisar. Mescla não é coincidência de período.
- **Cronograma**: etapas (numeração sequencial imutável) não são blocos de período; paginação por blocos (até 6 por slide; 7 vira 4+3; 8 vira 4+4); uma Entrega ao fim de cada bloco, numerada em sequência (exceção: AI Scan, por etapa); rótulos "Semana N" e "Semanas N-M".
- **BLOQUEADOS**: Proposta Comercial e Esclarecimentos são intocáveis. Únicas edições: data ("...validade de 1 mês a contar da data de sua apresentação DD/MM/AAAA", também na capa), nome do cliente, equipe, duração e investimento **do run**, o rótulo "Opção A/B/C" no título do comercial quando há duas estruturas, e as parcelas "Em até Nx" com N de `parcelas_max` (confira que N = 2 + floor(semanas/4); se divergir, avise e use o do run). Condições só mudam com instrução explícita do CN.
- **Desconto**: só se `decisao_final.desconto` não for nulo. Use a variante comercial com desconto do template (gp 28, pg 40, pd 41), com `pct`, `prazo_fechamento` e o preço já descontado do run. PM e AI Scan não têm variante: acrescente sob o valor a linha "X% de desconto em caso de fechamento até DD/MM/AAAA" (mesma fonte do valor) e registre em `adaptacoes`. Sem desconto, apague a variante.
- **Fixos** (não mexer): institucional, clientes e selos, divisória, cases (trocar só a pedido). **Variáveis**: capa, sumário, objetivos e citação, cronograma, etapas e exemplos, entregas principais, benefícios (gp), equipe, comercial (números), contato.

## Slide de remuneração (Opção C)
Todo template traz o slide "Proposta Comercial - Opção C" como **último slide, oculto**, com as formas nomeadas `rem:*`. Ele é preenchido por script a partir de `success_fee`, nunca à mão. **Rode antes de mexer no resto do deck**, sobre a cópia do template:
- **Com C no deck:** `python scripts/remuneracao.py deck.pptx --run run.json`. Preenche fixo (já com a visita), duração, equipe, % da fee, janela, teto, indicador e linha de base, base de cálculo, ajustes e trava de serviço, apuração e pagamento; tira o "oculto" e o move para depois do último slide comercial. A saída lista `pendencias`: cada campo `null` do `protocolo_medicao` fica como placeholder `XXXX`. Pergunte esses campos ao CN em texto; sem resposta, devolva-os em `placeholders_restantes` e avise (o QA reprova o deck até o placeholder sair).
- **Sem C:** `python scripts/remuneracao.py deck.pptx --remover`.
- Nunca ponha no slide o ganho estimado, os cenários nem nada de `success_fee.interno`.

## Fase 3: Geração e iteração
Leia `references/fase3-tecnico.md` inteiro antes de tocar no template (os templates já vêm com os defeitos de fábrica corrigidos; o arquivo diz o que não refazer). Ordem: copiar o template; rodar `remuneracao.py` (ou `--remover`); logo (`python scripts/logo.py <dir> <logo.png> <media>`); estrutura (apagar e duplicar slides pelos ids de etapa, `add_slide.py`); conteúdo; limpeza; zip; `validate.py --original`. Edite o modelo no lugar, nunca reconstrua. Mostre os slides variáveis renderizados e um PDF de pré-visualização; itere no mesmo arquivo, re-renderizando só o alterado. AI Scan e PD seguem `aiscan.md` e `pd.md`.

## QA e conferência
Rode, depois de cada rodada de edição:
```bash
python scripts/qa.py out.pptx --template assets/template-XX.pptx --run run.json --json-out qa.json \
  --proibidos "ascenty,sotreq,t4s,tenda,nome da empresa,Fala literal,Davi Milk,John Prince,E-mail do vendedor,XX/XX"
```
(ajuste a lista ao template e tire o nome do cliente se coincidir; o QA do AI Scan e do PD tem falsos positivos esperados descritos nos arquivos do portfólio.) Além da forma (resíduos, fragmentos, rodapé, bullets, imagens, cores), o `--run` **confere o deck contra o run**: valor e parcelas de cada estrutura, semanas, equipe, data e e-mails de contato. Divergência numérica é bloqueante: corrija no deck, nunca no run. Placeholders restantes (`XX`, `XXXX`, `X Consultores`) também reprovam.

## Devolução
Entregue o `.pptx` e o PDF e devolva o run completo com a seção `proposta` (contrato): `entrada` (o que você montou a partir do run, mais as respostas do checkpoint) e `saida` com `pptx`, `pdf`, `base_usada` (proposta e etapas de cada), `adaptacoes`, `itens_ineditos`, `placeholders_restantes`, `conferencia` e `qa` (o `qa.json`, com os falsos positivos esperados movidos para `falsos_positivos`). Acrescente `proposta` a `etapas_concluidas`, o checkpoint a `validacoes` e a `alertas`/`pendencias` o que ficou aberto (ex.: telefone, protocolo da C). Se for proposta boa e inédita, ofereça adicioná-la ao banco.

## Escrita
PT-BR, tom consultivo do banco. Nunca travessão (em dash) como pontuação; hífen composto e o " - " dos títulos de slide são ok. Reutilize a redação do banco quando a etapa for equivalente.

## Atualização do banco
markitdown → `references/propostas/` + atualizar `indice.md` (e `entregaveis.md` se necessário) → reempacotar mantendo o nome proposta-ncon. Material institucional novo → `references/institucional.md` (os slides fixos dos templates só mudam com instrução explícita). Primeira proposta de AI Scan aprovada e primeira de PD feita do template-pd: ofereça adicioná-las ao banco.
