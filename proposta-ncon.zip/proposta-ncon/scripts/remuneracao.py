#!/usr/bin/env python3
"""Slide 'Modelo de Remuneração' (Opção C) dos templates da proposta-ncon.

Todo template traz o slide como ÚLTIMO, oculto, com as formas nomeadas 'rem:*'.
  preencher:  python remuneracao.py deck.pptx --run run.json [--out saida.pptx]
              preenche a partir de success_fee, tira o 'oculto' e move o slide para depois do último
              slide comercial. Campo nulo no run deixa o placeholder e vira pendência na saída.
  remover:    python remuneracao.py deck.pptx --remover [--out saida.pptx]   (deck sem a C)
Saída: JSON com o que foi preenchido, as pendências e a posição final do slide.
"""
import argparse, copy, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pptx import Presentation
import ncon_run as R


def nomes(slide):
    return {sh.name: sh for sh in slide.shapes if sh.name.startswith("rem:")}


def eh_remuneracao(slide):
    return "rem:fixo" in nomes(slide)


def eh_comercial(slide):
    if eh_remuneracao(slide):
        return False
    txt = " ".join(sh.text_frame.text for sh in slide.shapes if sh.has_text_frame)
    return "INVESTIMENTO" in txt and "Proposta Comercial" in txt


def set_text(par, text):
    runs = par.runs
    runs[0].text = text
    for r in runs[1:]:
        r._r.getparent().remove(r._r)


def set_shape_text(sh, text):
    set_text(sh.text_frame.paragraphs[0], text)


def juntar(*partes, sep="; "):
    return sep.join(p for p in partes if p)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck")
    ap.add_argument("--run")
    ap.add_argument("--remover", action="store_true")
    ap.add_argument("--out")
    a = ap.parse_args()
    p = Presentation(a.deck)
    slides = list(p.slides)
    rem = [s for s in slides if eh_remuneracao(s)]
    if not rem:
        sys.exit("slide de remuneração não encontrado: use um template com o slide 'rem:*'")
    s = rem[0]
    out = a.out or a.deck
    lst = p.slides._sldIdLst

    if a.remover:
        for sid in list(lst):
            if p.part.related_part(sid.rId) is s.part:
                p.part.drop_rel(sid.rId)
                lst.remove(sid)
        p.save(out)
        print(json.dumps({"removido": True}, ensure_ascii=False))
        return

    if not a.run:
        sys.exit("informe --run run.json (ou --remover)")
    run = R.carregar(a.run)
    sf = run.get("success_fee") or {}
    if not sf.get("elegivel"):
        sys.exit("success_fee.elegivel não é verdadeiro: não há C para o slide (use --remover)")
    b = R.opcao(run, "B")
    pm = sf.get("protocolo_medicao") or {}
    par = sf.get("parametros") or {}
    ind = (run.get("cliente", {}).get("indicador_candidato") or {})
    N = nomes(s)
    espaco = "R$ " in N["rem:fixo"].text_frame.text
    pend, feito = [], []

    def put(chave, texto, faltando):
        if faltando:
            pend.append({"campo": chave, "falta": faltando})
        else:
            set_shape_text(N[f"rem:{chave}"], texto)
            feito.append(chave)

    # blocos superiores
    set_shape_text(N["rem:fixo"], R.brl(sf["fixo_cobrado"], espaco)); feito.append("fixo")
    set_shape_text(N["rem:duracao"], R.semanas_txt(b["semanas"])); feito.append("duracao")
    tf = N["rem:equipe"].text_frame
    linhas = R.equipe_linhas(b["equipe"])
    paras = list(tf.paragraphs)
    while len(paras) < len(linhas):
        tf._txBody.append(copy.deepcopy(paras[0]._p)); paras = list(tf.paragraphs)
    for i, para in enumerate(paras):
        if i < len(linhas):
            set_text(para, " " + linhas[i])
        else:
            para._p.getparent().remove(para._p)
    feito.append("equipe")

    # linhas de texto
    falt = [k for k, v in (("parametros.p", par.get("p")), ("parametros.W_meses", par.get("W_meses"))) if v is None]
    put("fee", f"{R.pct_txt(par.get('p') or 0)} do ganho capturado, apurado nos {par.get('W_meses')} meses após a entrada em operação de cada iniciativa.", falt)
    falt = [k for k, v in (("variavel_max", sf.get("variavel_max")), ("teto_total", sf.get("teto_total"))) if v is None]
    put("teto", f"{R.brl(sf.get('variavel_max') or 0)} (teto total da proposta: {R.brl(sf.get('teto_total') or 0)}).", falt)
    falt = [k for k, v in (("cliente.indicador_candidato.nome", ind.get("nome")), ("protocolo_medicao.baseline_periodo", pm.get("baseline_periodo"))) if not v]
    put("indicador", f"{ind.get('nome')}. Linha de base: {pm.get('baseline_periodo')}.", falt)
    put("base", f"{pm.get('unidade_formula')}.", [] if pm.get("unidade_formula") else ["protocolo_medicao.unidade_formula"])
    falt = [k for k, v in (("protocolo_medicao.ajustes", pm.get("ajustes")), ("protocolo_medicao.trava_servico", pm.get("trava_servico"))) if not v]
    excl = f" Exclusões: {', '.join(pm['exclusoes'])}." if pm.get("exclusoes") else ""
    put("ajustes", f"Ajustes permitidos: {', '.join(pm.get('ajustes') or [])}. Trava de serviço: {pm.get('trava_servico')}.{excl}", falt)
    falt = [k for k, v in (("protocolo_medicao.quem_aceita", pm.get("quem_aceita")), ("protocolo_medicao.prazo_aceite", pm.get("prazo_aceite")), ("protocolo_medicao.disputa", pm.get("disputa"))) if not v]
    put("apuracao", f"Aceite: {pm.get('quem_aceita')}, em {pm.get('prazo_aceite')}. Disputa: {pm.get('disputa')}.", falt)
    n = sf.get("parcelas_max") or R.parcelas_n(b["semanas"])
    fases = ""
    if sf.get("fixo_por_fase"):
        fases = " Fixo por fase: " + "; ".join(f"{x['fase']} {R.brl(x['valor'])}" for x in sf["fixo_por_fase"]) + "."
    put("pagamento", f"Fixo em até {n}x (cartão, boleto ou transferência).{fases} Variável faturado após cada apuração aceita.", [])

    # título, visibilidade e posição
    s._element.attrib.pop("show", None)
    ids = [sid for sid in lst]
    pos_sld = next(i for i, sid in enumerate(ids) if p.part.related_part(sid.rId) is s.part)
    elem = ids[pos_sld]
    lst.remove(elem)
    comerciais = [i for i, sid in enumerate(list(lst)) if eh_comercial(p.part.related_part(sid.rId).slide)]
    destino = (comerciais[-1] + 1) if comerciais else len(lst)
    lst.insert(destino, elem)
    p.save(out)
    print(json.dumps({"preenchido": feito, "pendencias": pend, "posicao_do_slide": destino + 1}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
