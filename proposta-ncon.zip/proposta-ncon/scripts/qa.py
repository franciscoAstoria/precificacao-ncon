#!/usr/bin/env python3
"""QA automatizado da proposta NCon. Roda os checks mensuráveis e imprime PASS/FAIL.

Uso: python qa.py <proposta.pptx> --template <template.pptx> --proibidos "ascenty,sotreq,t4s,tenda"
     [--run run.json] [--json-out qa.json]
Com --run, confere o deck contra o ncon.run: valor e parcelas de cada estrutura, semanas, equipe,
data de apresentação e e-mails de contato (quando o run já tem proposta.entrada).
Checks: resíduos/nomes antigos · fragmentos de palavra (pdftotext) · rodapé em 1 linha ·
bullets ● · quase-pretos · AR de imagens (com fillRect/srcRect) · cores de texto fora da paleta
do modelo · diff de geometria vs template.
"""
import sys, os, re, subprocess, zipfile, argparse, shutil, tempfile

FAIL = 0
RESULTS = []
def check(nome, ok, detalhe=''):
    global FAIL
    print(f"[{'PASS' if ok else 'FAIL'}] {nome}" + (f" — {detalhe}" if detalhe else ''))
    RESULTS.append({'check': nome, 'ok': bool(ok), 'detalhe': detalhe})
    if not ok: FAIL += 1

def slide_xmls(pptx):
    z = zipfile.ZipFile(pptx)
    out = {}
    for n in z.namelist():
        m = re.match(r'ppt/slides/slide(\d+)\.xml$', n)
        if m: out[int(m.group(1))] = z.read(n).decode('utf-8', 'ignore')
    return out, z

CONF = {'ok': True, 'itens': []}

def conf(campo, esperado, no_deck, ok):
    CONF['itens'].append({'campo': campo, 'esperado': esperado, 'no_deck': esperado if ok else no_deck, 'ok': bool(ok)})
    if not ok: CONF['ok'] = False
    check(f'conferência: {campo}', ok, '' if ok else f'esperado {esperado}; no deck: {no_deck}')

def conferir_run(path, md):
    """Confere números e dados do deck contra o ncon.run (valor, parcelas, semanas, equipe, data, contatos)."""
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import ncon_run as R
    run = R.carregar(path)
    texto = re.sub(r'\s+', ' ', md)
    estr = R.estruturas_do_deck(run)
    for e in estr:
        v = e['valor']
        fmt = [R.brl(v, True), R.brl(v, False)]
        conf(f"valor da estrutura {e['id']}", fmt[0], 'ausente', any(f in texto for f in fmt))
        conf(f"semanas da estrutura {e['id']}", R.semanas_txt(e['semanas']), 'ausente',
             re.search(rf"\b{e['semanas']} semanas?\b", texto) is not None)
        for linha in R.equipe_linhas(e['equipe']):
            conf(f"equipe da estrutura {e['id']}: {linha}", linha, 'ausente', linha.lower() in texto.lower())
    esperadas = {e['parcelas_max'] for e in estr if e.get('parcelas_max')}
    achadas = {int(x) for x in re.findall(r'até (\d+)x', texto, re.I)}
    conf('parcelas "em até Nx"', sorted(esperadas), sorted(achadas), esperadas <= achadas and achadas <= esperadas)
    ent = (run.get('proposta') or {}).get('entrada') or {}
    if ent.get('data_apresentacao'):
        a_, m_, d_ = ent['data_apresentacao'].split('-')
        conf('data de apresentação (DD/MM/AAAA)', f'{d_}/{m_}/{a_}', 'ausente', f'{d_}/{m_}/{a_}' in texto)
    for c in ent.get('contatos') or []:
        if c.get('email'):
            conf(f"e-mail de contato {c['email']}", c['email'], 'ausente', c['email'].lower() in texto.lower())
    desc = (run.get('decisao_final') or {}).get('desconto')
    tem = re.search(r'\d+%\s*\|?\s*de desconto|\d+% de desconto', texto, re.I) is not None
    conf('desconto no deck ' + ('(esperado)' if desc else '(não esperado)'), 'sim' if desc else 'não', 'sim' if tem else 'não', bool(desc) == tem)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('pptx'); ap.add_argument('--template', required=True)
    ap.add_argument('--proibidos', default='')
    ap.add_argument('--run'); ap.add_argument('--json-out')
    a = ap.parse_args()

    # 1. Resíduos e nomes antigos (markitdown)
    md = subprocess.run(['markitdown', a.pptx], capture_output=True, text=True).stdout
    # placeholders dos templates (inclui o slide de remuneração) nunca podem sobrar
    termos = [t.strip() for t in a.proibidos.split(',') if t.strip()] + [
        'lorem', r'\bXX\b', r'XX\.XXX', r'XXXX', r'\bX (Consultores|Analistas)']
    ruins = [t for t in termos if re.search(t, md, re.I)] + re.findall(r'FASE \d', md)
    check('sem resíduos/nomes antigos', not ruins, ', '.join(map(str, ruins)))

    tmp = tempfile.mkdtemp()
    subprocess.run(['soffice', '--headless', '--convert-to', 'pdf', a.pptx, '--outdir', tmp],
                   capture_output=True)
    pdf = os.path.join(tmp, os.path.splitext(os.path.basename(a.pptx))[0] + '.pdf')
    if os.path.exists(pdf):
        bbox = subprocess.run(['pdftotext', '-bbox', pdf, '-'], capture_output=True, text=True).stdout
        pages = re.findall(r'<page[^>]*>(.*?)</page>', bbox, re.S)
        # 2. Fragmentos de 1-2 chars (palavra quebrada)
        frags = []
        for pi, body in enumerate(pages, 1):
            words = re.findall(r'<word[^>]*>([^<]*)</word>', body)
            for j, w in enumerate(words):
                if re.fullmatch(r'[A-Za-zÀ-ú]{1,2}-?', w) and w.lower() not in (
                        'a','à','às','ás','o','e','é','de','do','da','em','um','ao','aos','os','as','no','na','se','ou','já','há','x','r','ex','ir','dá','só','vs','ml','kg','h',
                        'is','to','be','ia','ai','ti','rh','bi','ui','ux','eu','tu','tá','má','lá','me','te','mw','gw','c','×'):
                    frags.append(f'p{pi}:"{w}"')
        check('sem fragmentos de palavra quebrada', len(frags) == 0, '; '.join(frags[:8]))
        # 3. Rodapé em 1 linha (Consultoria e Júnior no mesmo y, nas páginas onde o rodapé existe)
        prob = []
        for pi, body in enumerate(pages, 1):
            words = re.findall(r'<word xMin="[\d.]+" yMin="([\d.]+)"[^>]*>([^<]*)</word>', body)
            ys = {}
            for y, t in words:
                if t in ('Consultoria', 'Júnior'):
                    ys.setdefault(round(float(y)), set()).add(t)
            tem_rodape = any('Consultoria' in v for v in ys.values())
            if tem_rodape and not any(v >= {'Consultoria', 'Júnior'} for v in ys.values()):
                prob.append(f'p{pi}')
        check('rodapé em uma linha', not prob, ', '.join(prob))
    else:
        check('render PDF para QA', False, 'soffice falhou')

    slides, z = slide_xmls(a.pptx)
    tslides, tz = slide_xmls(a.template)

    # 4. Bullets ●
    n = sum(x.count('buChar char="●"') for x in slides.values())
    check('sem bullets ● grandes', n == 0, f'{n} restantes')

    # 5. Quase-pretos em texto
    qp = [i for i, x in slides.items() if re.search(r'<a:(rPr|defRPr|endParaRPr)[^>]*>(?:(?!<a:t>).)*?srgbClr val="(20293A|221F1F)"', x, re.S)]
    check('sem quase-pretos em texto', not qp, f'slides {qp}')

    # 6. Cores de texto fora da paleta do modelo
    def cores_txt(xmls):
        c = set()
        for x in xmls.values():
            for m in re.finditer(r'<a:(?:rPr|defRPr|endParaRPr)[^>]*>((?:(?!</a:(?:rPr|defRPr|endParaRPr)>|<a:t>).)*)', x, re.S):
                c |= set(re.findall(r'srgbClr val="([0-9A-Fa-f]{6})"', m.group(1)))
        return c
    extras = cores_txt(slides) - cores_txt(tslides) - {'000000'}
    check('paleta de texto igual ao modelo', not extras, f'novas: {sorted(extras)}')

    # 7. AR de imagens (media vs shape, considerando fillRect/srcRect)
    try:
        from PIL import Image
        import io
        dist = []
        for i, x in slides.items():
            rels_name = f'ppt/slides/_rels/slide{i}.xml.rels'
            if rels_name not in z.namelist(): continue
            rels = dict(re.findall(r'Id="(rId\d+)"[^>]*Target="\.\./media/([^"]+)"', z.read(rels_name).decode()))
            for pic in re.finditer(r'<p:pic>.*?</p:pic>', x, re.S):
                blk = pic.group(0)
                rid = re.search(r'r:embed="(rId\d+)"', blk)
                ext = re.search(r'<a:ext cx="(\d+)" cy="(\d+)"', blk)
                if not (rid and ext and rid.group(1) in rels): continue
                media = 'ppt/media/' + rels[rid.group(1)]
                if media not in z.namelist(): continue
                try: im = Image.open(io.BytesIO(z.read(media)))
                except Exception: continue
                iw, ih = im.size
                # srcRect recorta a imagem
                sr = re.search(r'<a:srcRect([^/]*)/>', blk)
                l=t=r=b=0
                if sr:
                    at = dict(re.findall(r'(\w)="(-?\d+)"', sr.group(1)))
                    l,t,r,b = (int(at.get(k,0))/100000 for k in 'ltrb')
                vw, vh = iw*(1-l-r), ih*(1-t-b)
                # fillRect outset estica o canvas
                fr = re.search(r'<a:fillRect([^/]*)/>', blk)
                if fr:
                    at = dict(re.findall(r'(\w)="(-?\d+)"', fr.group(1)))
                    fl,ft,frr,fb = (int(at.get(k,0))/100000 for k in 'ltrb')
                    vw, vh = vw/max(1e-9, 1-fl-frr), vh/max(1e-9, 1-ft-fb)
                if vh <= 0 or vw <= 0: continue
                ar_img, ar_shape = vw/vh, int(ext.group(1))/max(1, int(ext.group(2)))
                if abs(ar_img-ar_shape)/ar_shape > 0.04:
                    dist.append(f's{i}:{rels[rid.group(1)]} ({ar_img:.2f} vs {ar_shape:.2f})')
        check('nenhuma imagem distorcida', not dist, '; '.join(dist[:6]))
    except ImportError:
        check('auditoria de imagens', False, 'Pillow ausente')

    # 8. Diff de geometria vs template (informativo: lista shapes movidos em slides não estruturais)
    movs = []
    for i in sorted(slides):
        if i in tslides:
            g1 = re.findall(r'<a:off x="(-?\d+)" y="(-?\d+)"/><a:ext cx="(\d+)" cy="(\d+)"/>', slides[i])
            g0 = re.findall(r'<a:off x="(-?\d+)" y="(-?\d+)"/><a:ext cx="(\d+)" cy="(\d+)"/>', tslides[i])
            extra = set(g1) - set(g0)
            if extra: movs.append(f's{i}:{len(extra)} geometrias novas/movidas')
    print(f"[INFO] diff de geometria (justifique cada uma): {'; '.join(movs) if movs else 'nenhuma mudança'}")

    if a.run:
        conferir_run(a.run, md)

    shutil.rmtree(tmp, ignore_errors=True)
    if a.json_out:
        import json
        falhas = [r['check'] + (f" — {r['detalhe']}" if r['detalhe'] else '') for r in RESULTS if not r['ok']]
        json.dump({'qa': {'ok': not falhas, 'falhas': falhas, 'falsos_positivos': []},
                   'conferencia': CONF}, open(a.json_out, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print(f"\n{'='*40}\n{'TUDO PASS' if FAIL == 0 else f'{FAIL} FALHAS: corrija antes de entregar'}")
    sys.exit(1 if FAIL else 0)

if __name__ == '__main__':
    main()
