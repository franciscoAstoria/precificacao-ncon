#!/usr/bin/env python3
"""Troca o logo do cliente num deck DESCOMPACTADO, à prova de renderizador.

Uso: python logo.py <dir_deck> <logo.png> <media1> [media2 ...]
Ex.:  python logo.py work/deck logo.png image23.png image19.png   (template-pm)

NUNCA passe o logo da Poli Júnior como alvo (no template-pm: image7.jpg).

Técnica (lições aprendidas):
- preserva RGBA (JPEG mataria a transparência: viraria preto)
- apara pelo canal alfa (ou diff contra branco)
- assa a proporção do shape de destino num canvas transparente (fillRect/srcRect
  divergem entre renderizadores; canvas na AR do shape + rects zerados é estável)
- um canvas por proporção quando os shapes do mesmo media divergem (gera media novo)
"""
import sys, os, re, glob, io
from PIL import Image

def aparar(img):
    img = img.convert('RGBA')
    bbox = img.getchannel('A').getbbox()
    if bbox is None or bbox == (0, 0, img.width, img.height):
        base = Image.new('RGBA', img.size, (255, 255, 255, 255))
        diff = Image.alpha_composite(base, img).convert('L').point(lambda p: 0 if p > 245 else 255)
        bbox = diff.getbbox() or (0, 0, img.width, img.height)
    return img.crop(bbox)

def canvas_ar(logo, ar, fator=0.90):
    lw, lh = logo.size
    if lw / lh >= ar:
        cw = int(lw / fator); ch = int(cw / ar)
    else:
        ch = int(lh / fator); cw = int(ch * ar)
    cv = Image.new('RGBA', (cw, ch), (0, 0, 0, 0))
    cv.paste(logo, ((cw - lw) // 2, (ch - lh) // 2), logo)
    return cv

def main():
    deck, logo_path, alvos = sys.argv[1], sys.argv[2], sys.argv[3:]
    logo = aparar(Image.open(logo_path))
    print(f'logo aparado: {logo.width}x{logo.height} (AR {logo.width/logo.height:.2f})')

    for alvo in alvos:
        # coletar as ARs dos shapes que usam esse media
        usos = []  # (slide_path, blk, rid, ar)
        for sl in glob.glob(os.path.join(deck, 'ppt/slides/slide*.xml')):
            rp = os.path.join(os.path.dirname(sl), '_rels', os.path.basename(sl) + '.rels')
            if not os.path.exists(rp): continue
            rels = open(rp).read()
            rids = re.findall(r'Id="(rId\d+)"[^>]*Target="\.\./media/' + re.escape(alvo) + '"', rels)
            if not rids: continue
            xml = open(sl).read()
            for pic in re.finditer(r'<p:pic>.*?</p:pic>', xml, re.S):
                blk = pic.group(0)
                rid = re.search(r'r:embed="(rId\d+)"', blk)
                ext = re.search(r'<a:ext cx="(\d+)" cy="(\d+)"', blk)
                if rid and ext and rid.group(1) in rids:
                    usos.append((sl, blk, rid.group(1), int(ext.group(1)) / max(1, int(ext.group(2)))))
        if not usos:
            print(f'AVISO: nenhum uso de {alvo}'); continue

        # agrupar por AR (tolerância 4%)
        grupos = []
        for u in usos:
            for g in grupos:
                if abs(g[0] - u[3]) / g[0] < 0.04:
                    g[1].append(u); break
            else:
                grupos.append([u[3], [u]])
        principal_ar = max(grupos, key=lambda g: len(g[1]))[0]

        for gi, (ar, us) in enumerate(grupos):
            if abs(ar - principal_ar) / principal_ar < 1e-9 or len(grupos) == 1:
                media_nome = alvo
            else:
                base, ext_ = os.path.splitext(alvo)
                media_nome = f'{base}_ar{gi}{ext_}'
            cv = canvas_ar(logo, ar)
            buf = io.BytesIO(); cv.save(buf, 'PNG', optimize=True)
            mp = os.path.join(deck, 'ppt/media', media_nome)
            open(mp, 'wb').write(buf.getvalue())
            print(f'{media_nome}: canvas AR {ar:.2f}, {len(us)} uso(s)')
            # PNG em media que era .jpg: registrar png no Content_Types se preciso
            ct = os.path.join(deck, '[Content_Types].xml')
            cx = open(ct).read()
            if 'Extension="png"' not in cx:
                cx = cx.replace('</Types>', '<Default Extension="png" ContentType="image/png"/></Types>')
                open(ct, 'w').write(cx)
            for sl, blk, rid, _ in us:
                xml = open(sl).read()
                novo = blk
                # zerar rects
                novo = re.sub(r'<a:srcRect[^/]*/>', '', novo)
                novo = re.sub(r'<a:fillRect[^/]*/>', '<a:fillRect/>', novo)
                if '<a:stretch>' not in novo:
                    novo = novo.replace('</p:blipFill>', '<a:stretch><a:fillRect/></a:stretch></p:blipFill>')
                xml = xml.replace(blk, novo)
                open(sl, 'w').write(xml)
                if media_nome != alvo:
                    rp = os.path.join(os.path.dirname(sl), '_rels', os.path.basename(sl) + '.rels')
                    rels = open(rp).read()
                    rels = re.sub(r'(Id="' + rid + r'"[^>]*Target="\.\./media/)' + re.escape(alvo) + '"',
                                  r'\g<1>' + media_nome + '"', rels)
                    open(rp, 'w').write(rels)
    print('OK. Verifique por pixels no render (AR medida = AR do logo aparado, ±3%).')

if __name__ == '__main__':
    main()
