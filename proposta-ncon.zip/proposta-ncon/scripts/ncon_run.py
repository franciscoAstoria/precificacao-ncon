#!/usr/bin/env python3
"""Funções comuns da proposta-ncon para ler o ncon.run (contrato em orquestrador-ncon/references/contrato-run.md)."""
import json

PLURAL = {"consultor": "Consultores", "coordenador": "Coordenadores", "analista": "Analistas",
          "product": "Product", "gerente": "Gerentes"}
SIGLAS = {"ncon": "NCon", "ntec": "NTec", "ia": "IA", "ti": "TI"}


def carregar(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def brl(v, espaco=True):
    """12345 -> 'R$ 12.345,00' (espaco=False: 'R$12.345,00', como nos templates gp e pm)."""
    s = f"{float(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return ("R$ " if espaco else "R$") + s


def pct_txt(p):
    """0.075 -> '7,5%'; 0.1 -> '10%'."""
    x = round(float(p) * 100, 2)
    return (f"{x:.0f}" if x == int(x) else f"{x:.2f}".rstrip("0").replace(".", ",")) + "%"


def parcelas_n(semanas):
    """'Em até Nx': N = 2 + floor(semanas / 4)."""
    return 2 + int(semanas) // 4


def semanas_txt(n):
    return f"{n} semana" if int(n) == 1 else f"{n} semanas"


def papel_txt(papel, qtd):
    toks = papel.replace("_", " ").split()
    nome = []
    for i, t in enumerate(toks):
        base = SIGLAS.get(t.lower())
        if base is None:
            base = (PLURAL.get(t.lower(), t.capitalize()) if (i == 0 and qtd != 1 and t.lower() in PLURAL) else t.capitalize())
        nome.append(base)
    return f"{qtd} {' '.join(nome)}"


def equipe_linhas(equipe):
    return [papel_txt(x["papel"], x["qtd"]) for x in equipe]


def opcao(run, id_):
    for o in run.get("dimensionamento", {}).get("opcoes", []):
        if o["id"] == id_:
            return o
    return None


def preco_opcao(run, id_):
    for o in run.get("precificacao", {}).get("opcoes", []):
        if o["id"] == id_:
            return o
    return None


def estruturas_do_deck(run):
    """Valores esperados no deck, por estrutura de decisao_final.estruturas_para_deck."""
    df = run["decisao_final"]
    desc = (df.get("desconto") or {}).get("estruturas", {}) or {}
    out = []
    for id_ in df["estruturas_para_deck"]:
        if id_ == "C":
            sf, b = run["success_fee"], opcao(run, "B")
            out.append({"id": "C", "valor": sf["fixo_cobrado"], "parcelas_max": sf.get("parcelas_max"),
                        "semanas": b["semanas"], "equipe": b["equipe"], "slide": "remuneracao"})
        else:
            o, p = opcao(run, id_), preco_opcao(run, id_)
            valor = desc.get(id_, p["preco_final"])
            out.append({"id": id_, "valor": valor, "parcelas_max": p.get("parcelas_max") or parcelas_n(o["semanas"]),
                        "semanas": o["semanas"], "equipe": o["equipe"], "slide": "comercial"})
    return out


def modo_escopo(estruturas):
    ids = [e["id"] for e in estruturas]
    if ids == ["A", "B"]:
        return "menor_e_maior"
    if ids == ["B", "C"]:
        return "duas_remuneracoes"
    return "unico"
