# Modelo do usuário: normalizar antes de entregar
Um deck anexado NÃO passou pelas correções dos templates v2 (o template AI Scan limpo já passou; o modelo original do Drive não). Falhas do `qa.py` nele NÃO são "herdadas e aceitáveis": corrija.
- **Estrutura canônica vale também aqui**: se o modelo não tiver o slide de Objetivos no formato da skill (ex.: "Principais dores" com parágrafo de Situação), substitua-o pelo slide 5 do template do portfólio (objetivos com setas + balão), mantendo título, linhas, logos e rodapé do slide do modelo.
- **Escala**: modelos antigos/Google Slides costumam ter 10×5,625in (metade dos templates). Ao portar shapes do template, multiplique por 0,5: `off`/`ext` do topo de cada shape ou grupo, `sz`, `buSzPts`, `spcPts`, `ln w`, insets do `bodyPr` e `marL`/`indent`. Não mexa em `chOff`/`chExt` nem nos filhos de grupos. Troque `schemeClr dk2` por `srgbClr 00468E` (o tema do modelo pode ter outro dk2) e use só cores que já existem no modelo (cinza da atribuição: 434343). Reaproveite media idênticos do modelo (compare por md5) em vez de duplicar.
- **Marcadores (bolinhas enormes no PDF)**: o glifo do `buChar` precisa existir na `buFont`. Montserrat NÃO tem ● (U+25CF) nem ⚬/◦/▪: cada renderizador cai num fallback diferente (no LibreOffice/PDF o ● sai gigante, no PowerPoint/Slides não). Correção: para todo `buChar` fora da fonte, troque a `buFont` para Arial (Arial/Liberation Sans têm • ● ◦ ▪) mantendo `buSzPts`; ⚬ vira ◦. Rode no deck descompactado:
```python
import re,glob,sys
TEM={'Montserrat':set('•–-'),'Arial':set('•●◦▪–-')}
for f in glob.glob(sys.argv[1]+'/ppt/slides/slide*.xml'):
    s=open(f,encoding='utf-8').read()
    def fix(m):
        b=m.group(0); ch=re.search(r'buChar char="([^"]+)"',b).group(1)
        if ch=='⚬': b=b.replace('char="⚬"','char="◦"'); ch='◦'
        fo=re.search(r'buFont typeface="([^"]+)"',b)
        if fo and fo.group(1) not in TEM: return b
        if fo and ch in TEM[fo.group(1)]: return b
        if fo: return b.replace(fo.group(0),'buFont typeface="Arial"')
        return b.replace('<a:buChar ','<a:buFont typeface="Arial"/><a:buChar ',1)
    s2=re.sub(r'<a:pPr\b(?:(?!</a:pPr>).)*?<a:buChar char="[^"]+"/>(?:(?!</a:pPr>).)*?</a:pPr>',fix,s,flags=re.S)
    if s2!=s: open(f,'w',encoding='utf-8').write(s2)
```
Depois disso, o check "sem bullets ● grandes" do `qa.py` continua contando ● (ele só procura o caractere): é esperado SE `grep -o 'buFont typeface="[^"]*"/><a:buChar char="●"' ppt/slides/*.xml | grep -v Arial` voltar vazio. Diga isso ao relatar o QA.
- **Rodapé em Georgia quebrando em 2 linhas**: alargue a caixa para a direita (texto alinhado à esquerda não se desloca) até caber em uma linha.
- **Quase-pretos** (20293A/221F1F) → 000000.
- Fragmentos de 1-2 letras apontados pelo `qa.py` que são siglas legítimas (ex.: "WI", "TI") são falso positivo; o resto se corrige.
