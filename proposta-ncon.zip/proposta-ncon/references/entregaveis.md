# Catálogo de Entregáveis NCon

Entregáveis modulares que entram ou saem de uma proposta conforme o escopo. Para cada um: quando usar, em quais propostas do banco aparece (para copiar a redação e o slide), e onde está a imagem de exemplo.

Imagens: `assets/exemplos/` contém as que NÃO estão nos templates. As demais já estão dentro de `template-gp.pptx`, `template-pm.pptx` ou `template-pg.pptx` (indicado o slide).

## Núcleo (praticamente sempre presentes)
| Entregável | Quando | Referência |
|---|---|---|
| Canvas de Escopo + Cronograma | Etapa 1 de qualquer projeto | Todas |
| Matriz CSD | Etapa 1 de PM (certezas/suposições/dúvidas) | Tenda-PM sl.8, Bracell, Stanley |
| Repositório Online (site personalizado) | Documentação Final de qualquer projeto | template-pm sl.17, template-gp sl.21 |
| Relatório/documentação executiva | Documentação Final | Todas |

## GP
| Entregável | Quando | Referência |
|---|---|---|
| Fluxos AS-IS | Mapeamento de processos | template-gp sl.8 |
| Fluxos TO BE (redesenhados) | Após AS-IS | template-gp sl.15; QuintoAndar, Rayes, Tenda-GP |
| Gargalos e Soluções (GUT + 5W2H) | Etapa de diagnóstico/otimização | template-gp sl.11 |
| Diagrama de Solução (OPCIONAL) | Quando há solução técnica/sistêmica a ilustrar | template-gp sl.12; Rayes |
| Initiative Charter (OPCIONAL) | Quando há iniciativas a priorizar/formalizar | template-gp sl.13; template-pg sl.33 |
| POPs / manuais | Padronização | template-gp sl.17; Vedacit, Tenda-GP |
| ChatBot / Manual Conversacional (OPCIONAL) | Disseminação via IA | template-gp sl.19; T4S-Chatbot |
| Full Vision (OPCIONAL) | Transição de software (detalhamento de campos) | `exemplos/full-vision.png`; QuintoAndar sl.13 |
| Cronoanálise / base de tempos | Processos produtivos/operacionais | Vedacit |
| Estudo de Capacity (OPCIONAL) | Dimensionamento de equipes operacionais | Vedacit |
| Mapa de Macroprocessos | Imersão de GP amplo | Vedacit |

## PM
| Entregável | Quando | Referência |
|---|---|---|
| Fluxograma do questionário | Sempre que houver questionário | template-pm sl.10 |
| Base de respostas | Após rodagem | `exemplos/base-de-respostas.png`; Bracell sl.14 |
| Dashboard interativa | Análise de dados | template-pm sl.13; Bracell |
| Matriz SWOT / SWOT Cruzada | Planos de ação | template-pm sl.15; `exemplos/matriz-swot.png` |
| Análise VRIO (OPCIONAL) | Análise competitiva aprofundada | `exemplos/analise-vrio.png`; Bracell sl.12 |
| Matriz de Concorrentes (OPCIONAL) | Análise competitiva | `exemplos/matriz-concorrentes.png`; Bracell sl.13 |
| Mapa Perceptual (OPCIONAL) | Posicionamento de marca | `exemplos/mapa-perceptual.png`; Bracell sl.17 |
| Cliente oculto (OPCIONAL) | Experiência de compra dos concorrentes | Bracell |
| Benchmark de mercado (OPCIONAL) | Comparação com players de referência | Stanley, FS-PG |
| Planos de Ação / direcionamentos | Fechamento analítico | Todas de PM |
| Gêmeo Digital / TwinLab (OPCIONAL) | Segmentos da pesquisa viram interlocutores que respondem em linguagem natural com base nos números da pesquisa | `institucional.md` (sem slide nos templates) |

## P&G
| Entregável | Quando | Referência |
|---|---|---|
| Organograma AS IS / TO BE | Diagnóstico de estrutura | T4S-PG, FS-PG, Vedacit |
| Cadeia de valor | Imersão | T4S-PG, FS-PG |
| Matriz Diagnóstico AS IS + MMG | Diagnóstico de maturidade de governança | template-pg sl.14-15 |
| Formulário organizacional (OPCIONAL) | Clima/cultura a partir dos colaboradores | template-pg sl.10-11 |
| Matriz RACI (OPCIONAL) | Papéis sobre fluxos mapeados | Tenda-GP |
| Playbook de Papéis e Funções | Etapa de papéis | T4S-PG, FS-PG, Vedacit, Tenda-GP |
| Playbook de Ritos + página de ritos | Etapa de reuniões e ritos | template-pg sl.23-24 |
| Indicadores comerciais/gestão | Etapa de indicadores | template-pg sl.31 |
| Gestão do Conhecimento (OPCIONAL) | Estruturação de conhecimento interno | template-pg sl.29-30 |
| Business Case de Expansão (OPCIONAL) | Crescimento de área | FS-PG |
| Roadmap de implementação | Fechamento de P&G | FS-PG, T4S-PG (Plano de Implementação) |
| Implementação de ferramenta (Fathom etc.) (OPCIONAL) | Quando o cliente adota ferramenta | template-pg sl.17-18 |
| Playbook de Ritos digital (OPCIONAL) | Versão navegável do playbook (catálogo, detalhamento, governança, dashboard) | `institucional.md` (sem slide nos templates) |

## PD (Product Discovery) — template-pd (slides de referência) e Arauco-PD
| Entregável | Quando | Referência |
|---|---|---|
| Canvas de Imersão (personas, MVP, hipóteses) | Entendimento do produto na proposta | template-pd sl.6 |
| Matriz CSD + Registro de Requisitos aberto | Imersão (fato × hipótese) | template-pd sl.9-12 |
| Relatório técnico do produto atual (NTec) | Viabilidade com sistemas e dados atuais | template-pd sl.14 |
| Fichas de entrevista (Teste da Mãe + screener) | Rota A, usuários externos | template-pd sl.15 |
| Mapeamento dos processos + dores por passo | Rota B, cliente interno | template-pd sl.16-18, Arauco-PD |
| Registro de Achados + jornada real | Fim da Evidência de Campo | template-pd sl.19-20 |
| Jobs To Be Done + Opportunity Solution Tree | Concepção | template-pd sl.23-25 |
| Jornada proposta | Concepção | template-pd sl.26-27 |
| Tabela de Hipóteses com Implicações | Fechamento das hipóteses | template-pd sl.28 |
| Registro de Requisitos fechado (user stories, critério de aceite) | Especificação testável | template-pd sl.29-30, Arauco-PD (requisitos de negócio/usuário/técnicos) |
| Relatório de Discovery | Principal entregável da Concepção | template-pd sl.31-32 |
| Protótipo navegável + PRD + roadmap (NTec) | Especificação e Prototipação | template-pd sl.33, Arauco-PD (PRD + Prototipação, Arquitetura do Sistema) |
| Desenvolvimento em escopo aberto (OPCIONAL) | Quando o cliente já quer construir depois do discovery | Arauco-PD (Etapa 6 + comerciais separados) |
| Value Proposition Canvas / priorização por RICE (OPCIONAL) | Escolha da solução e corte de escopo | `institucional.md` (sem slide no template) |

## AI Scan
Os entregáveis e os slides opcionais do AI Scan estão em `references/aiscan.md` (Radar de Oportunidades, Problem Solving e Issue Tree, entregas do Mapa de Causas, da Matriz de Dimensionamento e Workshops). Ofereça só esses.

## Como oferecer opcionais
Na fase de perguntas, apresente os opcionais que fazem sentido para o escopo com uma recomendação de uma linha cada, e deixe o usuário escolher. Se a ata ou a transcrição indicarem interesse do cliente em algo específico, sinalize ("na call, X mencionou interesse em priorização de iniciativas, o que sugere Initiative Charter"). Nunca inclua um opcional por conta própria sem confirmar.
