# Institucional NCon (Núcleo de Consultoria e Gestão Empresarial da Poli Júnior)

Fonte: material institucional / apresentação de portfólio vigente (out/2026). É REFERÊNCIA DE CONHECIMENTO: serve para escolher portfólio, ligar a dor do cliente à oferta certa, sugerir entregáveis e ideias de valor, e escolher um case aderente quando o usuário pedir troca. NÃO altera os slides FIXOS dos templates (institucional, clientes, divisória, cases), que continuam intocáveis.

Quando ler: Fase 2, só se houver dúvida sobre qual portfólio encaixa, se o usuário pedir case/ideias para aumentar o valor da proposta, ou se precisar dos argumentos de PD.

## Números e posicionamento
- Mais de 35 anos; mais de 1.100 projetos de consultoria executados; empresa número um entre as empresas juniores do Brasil.
- Missão do núcleo: impulsionar negócios com estrutura, inteligência de mercado e direção estratégica.
- Diferenciais: capacitação dos analistas com apoio de Bain & Company, McKinsey & Company e Visagio; alunos da USP (melhor faculdade de engenharia da América Latina); consultoria sob medida para cada desafio; direcionamento estratégico com foco em aplicação (estratégia + processos + mercado, valor no curto, médio e longo prazo).
- Clientes no slide de logos: Datora, Hospital Israelita Albert Einstein, VIX, Minerva Foods, Habib's, Banco Pine, Gerdau, Sem Parar, Jusbrasil, DUX Nutrition Lab, Jamef, J.A Saúde Animal.

## Portfólios
Cinco portfólios. GP, PM e P&G têm template e propostas no banco. AI Scan e PD têm template próprio (`template-aiscan.pptx`, `template-pd.pptx`); o PD também tem uma proposta de referência no banco (Arauco-PD).

### GP — Gestão de Processos
- Proposta: análise, redesenho e digitalização de processos internos; eficiência, padronização e gestão do conhecimento.
- Dores típicas (falas que sinalizam GP): falta de clareza sobre processos e métricas, o que dificulta achar problemas e decidir; perda de produtividade com atividades repetitivas, retrabalho, sobrecarga e falta de padronização; conhecimento operacional concentrado em poucas pessoas (se alguém sai, a execução cai).
- Pilares: Mapeamento (gargalos e redesenho com GUT, 5W2H e TO BE) · Reestruturação (cronoanálise e planejamento operacional) · Operacionalização (POPs e manuais) · Digitalização (diagnóstico e recomendação de sistemas para automação).
- Resultados vendidos: padronização e clareza; melhoria contínua; eficiência operacional (menos retrabalho e desperdício via monitoramento e digitalização); crescimento sustentável (base para expansão, certificações e auditorias).

### AI Scan
- Portfólio próximo ao GP, mas medido em custo: descobre onde a IA dá retorno antes de investir nela. Metodologia, etapas, entregáveis e regras de template: `references/aiscan.md` (fonte única).
- Como referência de redação para etapas de IA fora do padrão, o banco tem Rayes-GP-AnaliseIA (gargalos e soluções de IA, TO BE com IA) e T4S-Chatbot (agente de IA standalone).

### PM — Pesquisa de Mercado
- Proposta: transformar dados reais de público, mercado e concorrência em inteligência estratégica; pesquisas quantitativas e qualitativas que orientam decisões, posicionamento, comunicação e diferenciação.
- Dores típicas: falta de dados concretos sobre comportamento e necessidades do público-alvo; pouca clareza sobre concorrentes e como se diferenciar; falta de embasamento para um posicionamento assertivo.
- Etapas encadeadas: Imersão no Contexto (negócio, setor e a decisão que a empresa precisa tomar) · Análises (mercado, setor, concorrência, praça) · Coleta de Respostas (questionários quanti, entrevistas quali, dashboards) · Planos de Ação (recomendações priorizadas, relatório e SWOT).
- Análises recorrentes (escopo montado projeto a projeto a partir da decisão do cliente): Mercadológica (tamanho, tendências, oportunidades) · Setorial (forças, riscos, barreiras) · Concorrentes (players, diferenciais, benchmarking de canais, serviços e discurso de venda) · Praça (regiões, pontos de venda, canais com maior potencial). Também: público-alvo, precificação, portfólio, comunicação; matrizes SWOT, PEST, VRIO.
- Entregável diferenciado: **Gêmeo Digital (TwinLab, "Consumer Digital Twin")** — os segmentos identificados viram interlocutores que respondem em linguagem natural com base nos números da própria pesquisa.
- Resultados vendidos: posicionamento estratégico; conhecimento do público; análise competitiva; visão analítica (matrizes e relatórios interativos).

### P&G — Performance e Governança
- Proposta: estrutura organizacional, governança e gestão de performance; diagnóstico de organograma, papéis e rotinas, e estruturação de governança, indicadores e ritos.
- Dores típicas: dificuldade em saber quem é responsável por cada atividade e como as áreas se coordenam; reuniões e ritos ineficientes, com decisões que não são acompanhadas; desalinhamento entre estratégia, liderança e execução.
- Trilha: Diagnóstico Organizacional (organograma, papéis e interfaces, ritos e indicadores; onde a empresa ganha e perde eficiência; maturidade → plano de atuação) · Papéis e Responsabilidades (redesenho TO BE, playbook) · Reuniões e Ritos (objetivo, frequência, participantes, playbook) · Cultura e Engajamento (gargalos culturais, PDI, feedback) · Indicadores (responsáveis, periodicidade, métricas) · Gestão do Conhecimento (fluxo de informação, documentação, ferramentas e rotinas) · Plano de Implementação (roadmap: o que, em que ordem, com quais responsáveis).
- Entregável diferenciado: **Playbook de Ritos digital** — manual navegável (catálogo de ritos, detalhamento, governança, dashboard) para centralizar e acompanhar os ritos da área.
- Resultados vendidos: clareza organizacional; governança estruturada; gestão orientada a dados; engajamento e desenvolvimento.

### PD — Product Discovery
- Proposta: validar hipóteses de produto com evidência real de comportamento ANTES de investir em desenvolvimento, reduzindo o risco do investimento.
- Dores típicas: ideia de produto na mesa sem saber se o usuário quer (descobrir depois de construir sai caro); dúvida se o que se quer construir é viável com os sistemas e dados atuais (cliente interno); produto com usuários cadastrados que quase não voltam, sem saber por quê (cliente externo).
- Estrutura de origem (o template-pd a detalha em 5 etapas: Imersão de Contexto, Evidência de Campo, Síntese e Concepção, Especificação e Prototipação, Documentação Final): **Descoberta** — imersão com stakeholders para separar fato de hipótese; evidência de campo com usuários reais pelo método do Teste da Mãe; análise técnica do produto atual em paralelo (o que é possível, caro ou inviável). **Concepção** — síntese em oportunidades validadas com Jobs To Be Done e Opportunity Solution Tree; escolha da solução pelo Value Proposition Canvas; priorização de escopo por RICE.
- Resultados vendidos: hipóteses validadas (cada uma fechada por evidência e implicação no produto); conhecimento do usuário (jornada real a partir de episódios concretos); escopo priorizado (por impacto e confiança, com registro do que ficou de fora e por quê); conceito testado (protótipo validado com usuário e comparado com a operação atual).
- Regra: use o `template-pd.pptx` (seção PD do SKILL.md). Na Fase 2, confirme a rota (A: usuários externos; B: processos internos) e a composição da equipe (analistas NCon e NTec).

## Cases do institucional (problema → solução → impacto)
Use para argumentar valor e escolher case aderente QUANDO o usuário pedir troca de case. Não invente números além dos abaixo.

### GP
- **Grupo CBO**: sem controle e previsibilidade de custos com prestadores de serviço → cronoanálise e mapeamento com dados de jornada e acesso, comparação contratado × executado, padronização de controles, melhorias em reconhecimento facial e relatórios de medição → economia potencial acima de R$400 mil.
- **Grande Empresa de Saúde** (anônima): queria automatizar com RPA sem mapeamento → mapeamento de inclusão de beneficiários, faturamento e autorização de procedimentos, cronoanálises, soluções com RPA e OCR → quase 5 horas diárias de trabalho economizadas.
- **Eletromidia**: gestão e manutenção de ativos distribuídos sem padronização nem integração de sistemas → AS-IS/TO-BE, análises financeiras, matriz esforço × impacto → economia anual estimada de R$1,58 milhão, quase eliminação do overbooking, perdas por falhas reduzidas em 50%.
- **Banco Pine**: fechamento contábil manual e sem padronização, com reprocessamentos → mapeamento com mais de 120 funcionários, quick wins (automação de planilhas), AS-IS/TO-BE → cerca de 50% menos tempo no fechamento contábil.
- **Datora Telecom**: pedido de venda despadronizado e CRM próprio com etapas mal definidas → 23 mapeamentos AS-IS, TO-BE com soluções mensuráveis, manual de uso do CRM → 50% menos tempo em uma etapa do CRM em dois meses de projeto.
- **Gerdau**: alta diversidade de produtos, estoques intermediários, não conformidades → estudo A3 em 3 estoques e VSM da fábrica → produtos prontos em cerca de 30% do tempo anterior, economia anual estimada acima de R$2 milhões.
- **Banco BMG** (Financeiro Help): processos manuais, sem integração, risco de erro frente ao crescimento da rede de franquias → 15 reuniões de imersão, 100% dos processos mapeados, 22 gargalos (GUT), 22 soluções (5W2H), TO-BE de 12 processos e 12 manuais → rotinas padronizadas, rastreáveis e escaláveis.
- **Rede Mulher Empreendedora**: 9 áreas sem padronização nem ferramenta única de acompanhamento → 14 entrevistas, 34 processos, cadeia de valor, GUT, 4 softwares avaliados, 19 soluções → 12 TO-BE (incluindo fluxo de solicitações no Asana), 29 gargalos resolvidos.
- **Aegea** (Regenera Rio): cadeia de 5 frentes de lixo urbano sem padronização nem indicadores confiáveis → AS-IS das 5 áreas, 58 gargalos priorizados por impacto × esforço, 27 soluções com responsável, prazo, custo e ganho → vida útil das nanomembranas de 2 meses para 2 anos, economia anual estimada de R$457 mil.
- **Motiva**: sede e unidades regionais (aeroportos de Goiânia e Palmas) sem visão consolidada → entrevistas com mais de 60 funcionários, 218 processos mapeados, GUT, 5W2H, RACI → 96 soluções prontas para implementação.

### P&G
- **Grupo EPR**: verba anual de inovação gerida de forma descentralizada, sem processos, ritos nem área responsável → estruturação do zero da área de Inovação (escopo, governança, ritos), macro e microprocessos, estudo de parceiros e investidores → alinhamento entre unidades, menos retrabalho, posicionamento como organização inovadora.

### PM
- **Mitt Incorporadora**: potencial imobiliário de uma cidade do interior de MG → estudo mercadológico e territorial, concorrentes, pesquisa quantitativa com moradores, mapas de calor → regiões mais promissoras e ticket médio ideal.
- **Turbi**: entender o mercado e oportunidades de expansão → tendências, entrevistas com concorrentes, parceiros e clientes → planos de ação comerciais e de posicionamento.
- **Cory**: lançamento de biscoitos cobertos com chocolate → pesquisa quantitativa com mais de 400 respostas → características-chave dos clientes e Persona para marketing.
- **PlayKids** (Movile): competitividade e expansão no mercado educacional → tendências e modelos de negócio de players no Brasil, EUA, Índia e China → insumos para lançar novos produtos.
- **Cless Cosméticos**: posição em perfumarias sem clareza de percepção de marca → 500 respostas quantitativas e pesquisa presencial em 5 perfumarias (60 respondentes), análise setorial e geográfica → critérios de decisão (preço e recomendação), direcionamento para redes sociais, promotoras e regiões.
