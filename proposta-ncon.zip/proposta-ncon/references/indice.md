# Índice do Banco de Propostas NCon

Cada proposta abaixo tem seu texto completo em `references/propostas/<Arquivo>.md` (extraído com markitdown, um bloco por slide). Use este índice para encontrar a proposta mais similar ao novo escopo ANTES de abrir os textos completos. Leia na íntegra apenas a(s) proposta(s) escolhida(s) como base.

## GP (Gestão de Processos)

### Ascenty-GP — "GP Padrão completo com POP" ⭐ TEMPLATE VISUAL GP
- Escopo: mapeamento e otimização do processo de aquisições e documentação técnica (RFPs de equipamentos de alto valor) da Engenharia de uma empresa de data centers, com soluções de IA.
- Equipe/duração: 2 consultores + 1 coordenador, 7 semanas. Investimento de referência: R$32.100.
- Etapas: 1 Imersão no contexto · 2 Mapeamento AS-IS (até 16 reuniões) · 3 Identificação de gargalos e proposição de soluções, incluindo IA (GUT, 5W2H, Matriz Esforço x Impacto, Diagrama de Solução, Initiative Charter) · 4 Mapeamento TO BE · 5 Elaboração de Manuais (POPs) · 6 Documentação Final.
- Cronograma: 5 blocos (Semana 1 · 2-3 · 4-5 · 6 · 7), Manuais e Doc Final dividindo a Semana 7 com traço.
- Referência de: GP padrão atual, objetivos com citação literal, slide "Entregáveis do projeto" por etapa, Benefícios com mini-cases, variante comercial com desconto.

### Sotreq-GP-Completo — "GP Completo" (template visual GP até set/2026)
- Escopo: padronização e eficiência do processo de Assessment Técnico. GP com 7 etapas, incluindo Manual Conversacional (ChatBot); fonte de texto para etapas de ChatBot.
- Equipe/duração: 2 consultores + 1 coordenador, 7 semanas.
- Etapas: 1 Imersão no contexto · 2 Mapeamento AS-IS · 3 Identificação de gargalos e proposição de soluções (GUT, 5W2H, Diagrama de Solução, Initiative Charter) · 4 Mapeamento TO-BE · 5 Elaboração de manuais (POPs) · 6 Manual Conversacional (ChatBot) · 7 Documentação Final.
- Cronograma: 7 blocos, 1 por semana (Semana 1 a 7).

### Vedacit-GP-Cronoanalise — GP com Cronoanálise
- Escopo: mapeamento + cronoanálise de duas linhas de produção, capacity, papéis.
- Equipe/duração: 2 consultores + 1 coordenador, 13 semanas.
- Etapas: 1.1/1.2 Imersão no Contexto e Diagnóstico de Maturidade · 2 Mapeamento AS IS e Cronoanálise · 3 Padronização e Otimização (GUT + 5W2H) · 4 Análise de Capacity · 5.1/5.2 Papéis e Responsabilidades (organograma TO BE, Playbook) · 6 Mapeamento TO BE · 7 POPs e Documentação Final.
- Referência de: sub-etapas X.1/X.2, cronoanálise, capacity, blocos multi-semana (Semanas 1-2, 3-6, 7-8, 9-10, 11, 12, 13).

### Rayes-GP-AnaliseIA — GP com foco em IA
- Escopo: mapeamento de processos de escritório de advocacia + identificação de oportunidades de IA.
- Equipe/duração: 2 consultores + 1 coordenador, 8 semanas.
- Etapas: 1 Imersão · 2 AS-IS · 3 Identificação de gargalos e soluções de IA (5W2H, Diagrama de Solução) · 4 TO BE com aplicações de IA · 5 Documentação Final.

### QuintoAndar-GP-Software — GP de transição de sistema
- Escopo: mapeamento AS-IS/TO BE para migração ao Salesforce, com Full Vision.
- Equipe/duração: 3 consultores + 1 coordenador, 6 semanas.
- Etapas: 1 Imersão · 2 AS-IS · 3 TO BE · 4 Full Vision e Documentação Final.
- Referência de: Full Vision (detalhamento de campos), transição de software.

### Tenda-GP-PG — Híbrido GP + P&G
- Escopo: diagnóstico + mapeamento + papéis + ritos + manuais + chatbot (9 semanas, 2 consultores).
- Etapas: 1.1/1.2/1.3 Imersão e Diagnóstico (organograma AS IS, Matriz Diagnóstico) · 2 AS-IS · 3 TO BE · 4.1/4.2 Papéis e Responsabilidades (Matriz RACI, Playbook) · 5.1/5.2 Reuniões e Ritos (Playbook de Ritos, página de ritos) · 6 Manuais (POPs) · 7 Manual Conversacional (ChatBot).
- Referência de: proposta em duas frentes GP+P&G num contrato só, Matriz RACI.

### T4S-Chatbot — GP curto de IA (Chatbot)
- Escopo: chatbot de POPs (agente de IA interno). 2 consultores, 4 semanas.
- Etapas: 1 Imersão e Atualização de POPs · 2 Desenvolvimento do Chatbot e Testes.
- Referência de: projeto GP enxuto de 2 etapas, escopo de IA standalone (evolução natural pós-mapeamento).

## PM (Pesquisa de Mercado)

### Tenda-PM-AtracaoTalentos — Pesquisa de atratividade ⭐ TEMPLATE VISUAL PM
- Escopo: percepção de marca empregadora e atração de talentos universitários (questionário 160 respondentes).
- Equipe/duração: 2 consultores + 1 coordenador, 6 semanas. Investimento de referência: R$24.100.
- Etapas: 1 Imersão no contexto (Matriz CSD) · 2 Elaboração do Questionário (fluxograma) · 3 Rodagem · 4 Análise das Respostas (Dashboard) · 5 Planos de Ação (SWOT, SWOT Cruzada) · 6 Documentação Final.
- Cronograma: Semana 1 (Imersão + Elaboração juntas no bloco, separadas por traço) · Semanas 2-4 · Semana 5 · Semana 6. É a referência canônica do formato com traços.

### Bracell-PM — Questionário + Concorrência
- Escopo: pesquisa com questionário, cliente oculto e análise competitiva.
- Equipe/duração: 2 consultores + 1 coordenador, 5 semanas.
- Etapas: 1 Imersão (CSD + lista de concorrentes) · 2 Estruturação de Instrumentos de Pesquisa (fluxograma + roteiro de cliente oculto) · 3 Rodagem do Questionário e Análise Competitiva (VRIO, Matriz de Concorrentes, cliente oculto) · 4 Dashboard e Análise (Mapa Perceptual, SWOT) · 5 Planos de Ação e Documentação Final.
- Referência de: VRIO, Mapa Perceptual, Matriz de Concorrentes, cliente oculto.

### Stanley-PM — Questionário + Benchmark
- Escopo: decisão de frete grátis no e-commerce; questionário + benchmark de mercado.
- Equipe/duração: 1 consultor + 1 coordenador, 5 semanas.
- Etapas: 1 Imersão · 2 Instrumentos de Pesquisa · 3 Rodagem + Benchmark · 4 Dashboard e Análise · 5 Planos de Ação e Documentação Final (exemplo real de mescla de Planos de Ação + Documentação Final numa etapa só).

### Mercosul-PM — Mercadológica + Concorrência
- Escopo: análise mercadológica de cabotagem (sazonalidade, volumetria) + concorrentes.
- Equipe/duração: 1 consultor + 1 coordenador, 7 semanas.
- Etapas: 1 Imersão · 2 Análise Mercadológica · 3 Análise dos Concorrentes · 4 Planos de Ação · 5 Documentação Final.
- Referência de: PM sem questionário (dados secundários).

## P&G (Performance e Governança)

### T4S-PG — Governança comercial completa ⭐ TEMPLATE VISUAL P&G
- Escopo: estruturação de governança da área comercial (12 semanas, 2 consultores). A P&G mais completa do banco.
- Etapas: 1/1.1/1.2/1.3 Imersão (formulário organizacional, cadeia de valor, organograma AS IS) · 2.1/2.2 Diagnóstico de Maturidade de Governança (Matriz Diagnóstico, MMG, Dashboard) · 3 Implementação do Fathom · 4 Benchmark de Referências Comerciais · 5.1/5.2 Papéis e Responsabilidades · 6.1/6.2 Reuniões e Ritos · 7.1/7.2 Cultura e Engajamento · 8 Gestão do Conhecimento · 9 Indicadores · 10 Plano de Implementação (Initiative Charter) · 11 Documentação Final.
- Cronograma: DOIS SLIDES (slides 6 e 7 do template) — referência canônica da paginação quando os blocos não cabem num slide só.

### FS-PG — Expansão de área + governança
- Escopo: diagnóstico da área de energia, benchmark, papéis, ritos e plano de expansão (business case + roadmap).
- Equipe/duração: 2 consultores + 1 coordenador, 7 semanas (proposta alternativa de 15 semanas com 4 consultores no mesmo deck).
- Etapas: 1.1/1.2/1.3 Imersão e Diagnóstico · 2 Benchmark de Estrutura e Práticas · 3.1/3.2 Papéis e Responsabilidades · 4.1/4.2 Reuniões e Ritos · 5.1/5.2 Plano de Expansão (Business Case, Roadmap) · 6 Documentação Final.
- Referência de: Business Case de Expansão, Roadmap, propostas com duas opções de dimensionamento.

## PD (Product Discovery)

### template-pd — Modelo de Proposta Product Discovery ⭐ TEMPLATE VISUAL PD
- Não é proposta de cliente: é o modelo oficial normalizado (`assets/template-pd.pptx`), com textos de metodologia prontos e placeholders. Use-o como base visual E de conteúdo das etapas.
- Equipe/duração padrão: 1 analista NCon + 1 analista NTec + 1 coordenador, 8 semanas.
- Etapas: 1 Imersão de Contexto (Matriz CSD, Registro de Requisitos) · 2 Evidência de Campo (2.1 Análise Técnica NTec · 2.2 Rota A Pesquisa de Campo ou Rota B Mapeamento Interno · 2.3 Registro de Achados) · 3 Síntese e Concepção (3.1 Agrupamento de Achados · 3.2 JTBD · 3.3 Opportunity Solution Tree · 3.4 Jornada Proposta · 3.5 Tabela de Hipóteses · 3.6 Engenharia de Requisitos · 3.7 Relatório de Discovery) · 4 Especificação e Prototipação (protótipo, PRD, roadmap; NTec) · 5 Documentação Final.
- Cronograma: Semana 1 · Semanas 2-4 · Semanas 5-6 · Semanas 7-8 (Especificação + Doc Final divididas por traço).

### Arauco-PD — Discovery técnico de sistema centralizado (Rota B)
- Escopo: discovery técnico para um sistema centralizado de gestão de alertas de manutenção (ferramentas preditivas isoladas, RCM/FMEA/RCA desconectados do SAP) numa fábrica de celulose greenfield: mapeamento dos fluxos de eventos, diagnóstico de dados e integrações, requisitos e protótipo, com opção de desenvolvimento em escopo aberto pelo NTec.
- Equipe/duração: 2 consultores + 1 coordenador + 1 Product Manager (Tecnologia), 8 semanas, R$44.000 (o slide de Equipe diz 9 semanas: inconsistência do original). Opções no mesmo deck: Desenvolvimento em Escopo Aberto (2 consultores + 1 PM, 16 semanas, R$68.200) e Discovery + Desenvolvimento (24 semanas, R$112.200).
- Etapas: 1 Imersão no contexto (kick-off, inventário de sistemas e integrações) · 2 Mapeamento dos processos (entrevistas com 7 pontos focais, BPMN) · 3.1/3.2 Diagnóstico e correlação dos dados (inputs/outputs por ferramenta, lacunas de rastreabilidade) · 4.1/4.2/4.3 Requisitos de Negócio, de Usuário e Técnicos (+ entrega Arquitetura do Sistema) · 5.1 PRD + Prototipação · 5.2 Documentação Final · 6 Escopo Aberto de Desenvolvimento.
- Cronograma: Semana 1 · Semanas 2-3 · Semanas 4-6 · Semana 7 · Semana 8, Entregas 1-4.
- Visual anterior ao template-pd (formato antigo de Objetivos com "Principais dores"): use como base de CONTEÚDO, nunca de layout. Referência de: PD de cliente interno/industrial, requisitos de negócio/usuário/técnicos, PRD, arquitetura de sistema, proposta com opção de desenvolvimento (três cenários comerciais) e Product Manager na equipe.

## AI Scan

Sem proposta de cliente no banco ainda. Tem template próprio (`assets/template-aiscan.pptx`) e a metodologia completa em `references/aiscan.md`: use-os como base visual e de conteúdo. Referências de redação para etapas de IA fora do padrão: Rayes-GP-AnaliseIA e T4S-Chatbot. Quando houver a primeira proposta de AI Scan aprovada, adicione aqui.
