<!-- Slide number: 1 -->

Otimização e padronização de processos com foco em produtividade e redução de custos

Proposta de Parceria
08 de Julho, 2026

![](GoogleShape251p37.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 2 -->

Poli Júnior - Empresa Júnior da Escola Politécnica da USP

A Poli Júnior é uma instituição constituída por alunos de Graduação da Escola Politécnica de Engenharia da USP.

Localizados na melhor faculdade de engenharia da América Latina, seu projeto é impulsionado pelo mais alto rigor e talentos da Escola Politécnica, garantindo o que há de mais inovador em tecnologias, resultando em soluções ágeis e criativas. Além disso, criando uma forte conexão da empresa com a POLI-USP.

Nossa excelência e agilidade é refinada por treinamentos e parcerias com as maiores consultorias do mundo visando aplicar o mesmo padrão de excelência e pensamento estratégico em nossos projetos.

1º
+1100
90%
lugar
entre as Empresas Juniores do Brasil
Projetos concluídos
Índice de Satisfação
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 3 -->

Quem conta com as soluções da Poli Júnior

![](GoogleShape321p39.jpg)

### Notes:

<!-- Slide number: 4 -->

![](GoogleShape351p40.jpg)
Sumário - Nosso Entendimento do Seu Contexto e Objetivos
Uma proposta para padronizar e otimizar as operações da Vedacit, elevando a produtividade e reduzindo os custos operacionais.

Recomendamos o mapeamento AS IS com cronoanálise presencial das operações, a estruturação de papéis e responsabilidades, a padronização e otimização dos processos e uma análise de capacity das equipes, resultando em um mapeamento TO BE orientado a produtividade e redução de custos.
Contexto:
A Vedacit passa por um momento de expansão e concluiu recentemente a mudança de sua fábrica de São Paulo para Itatiba. Com a transição, os processos não foram atualizados para a nova realidade da planta, as operações não ocorrem de forma padronizada entre equipes e turnos, e parte do conhecimento,  já não documentado, foi perdido, gerando variações de execução, retrabalhos e perdas de eficiência.
Nesse cenário, a área identificou a necessidade de revisitar seus processos de ponta a ponta, atuando em duas frentes de operação: a Linha de Mantas e Fitas e a Linha Rotativa Vedapren. O desafio vai além de documentar a operação atual: é preciso padronizar a execução entre equipes e turnos e redesenhar os fluxos para a realidade da nova planta.
O objetivo central é elevar a produtividade e minimizar os custos das operações, com decisões embasadas em dados coletados em campo por meio de cronoanálise e em um dimensionamento adequado das equipes (análise de capacity), garantindo uma operação padronizada, eficiente e preparada para sustentar o crescimento da empresa.

Projetos que integram otimização e tecnologias inovadoras à sua empresa

Entregas frequentes que geram valor rápido
Conexão com a USP e talentos da Escola Politécnica

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 5 -->

Principais objetivos da Vedacit

![](GoogleShape379p41.jpg)

Objetivos:
Mapear os fluxos operacionais da Linha de Mantas e Fitas e da Linha Rotativa Vedapren, refletindo a operação real pós-mudança e documentando o conhecimento da operação.

"Com a mudança para Itatiba, os processos não foram atualizados e cada equipe opera de um jeito."
Realizar cronoanálise presencial das operações, construindo uma base de tempos confiável para embasar as decisões de produtividade.

Padronizar e otimizar os processos, eliminando gargalos e variações de execução entre equipes e turnos que geram perdas e retrabalhos.

Dimensionar a capacidade das equipes (capacity) e avaliar o rendimento dos operadores, garantindo alocação eficiente de recursos e redução dos custos operacionais.

Estruturar papéis e responsabilidades e redesenhar os processos (TO BE), consolidando uma operação padronizada e de maior produtividade.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 6 -->

Cronograma do projeto

Imersão no Contexto e Diagnóstico de Maturidade
Mapeamento AS IS e Cronoanálise
Padronização e Otimização
Análise de Capacity

Entrega 1
Entrega 2
Entrega 4
Entrega 3
Semanas 1-2
Semanas 3-6
Semanas 9-10
Semanas 7-8

Mapear a estrutura formal das áreas de operação, incluindo macroprocessos e organograma.

Estudo de capacidade e dimensionamento das equipes, com foco em produtividade e redução de custos.

Mapear os fluxos (AS IS) da Linha de Mantas e Fitas e da Linha Rotativa Vedapren, com visitas presenciais para cronoanálise.

Identificar e priorizar gargalos (Matriz GUT e Esforço x Impacto) e propor soluções de padronização.

### Notes:

<!-- Slide number: 7 -->

Cronograma do projeto

Desenvolvimento de POPs e Documentação Final
Papéis e Responsabilidades
Mapeamento
TO BE

Entrega 6
Entrega 7
Entrega 5
Semana 13
Semana 12
Semana 11

Consolidar todas as análises e entregas do projeto em documentação executiva e repositório de fácil acesso.

Desenhar os fluxogramas ideais, já padronizados e otimizados, com redução de erros e perdas e ganho de eficiência.

Definir papéis, responsabilidades e hierarquias de forma clara e organizada, consolidados em Matriz RACI.

### Notes:

<!-- Slide number: 8 -->

Etapa 1.1 - Imersão no Contexto e Diagnóstico de Maturidade

Objetivo Estratégico: mapear a estrutura formal das áreas de operação da Vedacit em Itatiba, evidenciando cargos, hierarquias e conexões entre os times das frentes de Linha de Mantas e Fitas e Linha Rotativa Vedapren, como base para o diagnóstico.
Principais Atividades:

Reuniões com a gestão para levantamento da estrutura organizacional atual das áreas envolvidas

Elaboração do organograma AS IS no Lucidspark, destacando cargos, hierarquias e conexões interáreas

Entregável de Valor: organograma AS IS estruturado no Lucidspark, refletindo a estrutura real da área com cargos, hierarquias e conexões entre times.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 9 -->

Etapa 1.2 - Imersão no Contexto e Diagnóstico de Maturidade

Objetivo Estratégico: alinhar os principais pontos do projeto, garantindo conformidade entre as equipes da Vedacit e da Poli Júnior, e estruturar uma visão integrada dos subprocessos das operações.
Principais Atividades:

Realização do kick-off: definição dos pontos focais do projeto e dos alinhamentos iniciais com a equipe da Vedacit;

Construção do Mapa de Macroprocessos das frentes de Linha de Mantas e Fitas e Linha Rotativa Vedapren, identificando subprocessos, interfaces e sequência típica;

Agendamento das reuniões de mapeamento, das visitas presenciais para cronoanálise e dos reports semanais.

Entregável de Valor:  elaboração do Canvas de Escopo, Mapa de Macroprocessos e Cronograma do projeto.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 10 -->

Etapa 2 - Mapeamento AS IS e Cronoanálise
Objetivo Estratégico: construir os fluxogramas das operações da Linha de Mantas e Fitas e da Linha Rotativa Vedapren e, de forma simultânea, coletar dados de tempos em campo por meio de cronoanálise, formando a base para a padronização, otimização e análise de capacity.
Principais Atividades:

Realização de 24 reuniões online de 1 hora para mapeamento das etapas das operações da Linha de Mantas e Fitas (14 reuniões) e da Linha Rotativa Vedapren (10 reuniões), com responsáveis e envolvidos nos processos.

Entendimento do fluxograma (mapeamento e modelagem AS IS):
Atividades e atores que participam nos processos das áreas;
Comunicação entre áreas e canais de informação.

Realização de visitas presenciais à planta de Itatiba para cronoanálise das operações:
Linha de Mantas e Fitas: 1 visita de dia inteiro;
Linha Rotativa Vedapren: 3 visitas de 4 horas;
Medição dos tempos de execução de cada tarefa, com 3 medições por tarefa, garantindo consistência da base de dados.

Entregável de Valor:  fluxogramas AS IS das duas frentes de operação e base de dados de tempos consolidada a partir da cronoanálise.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 11 -->

Etapa 2 - Mapeamento AS IS e Cronoanálise

VALIDAÇÃO
MAPEAMENTO
Validar o mapeamento de um processo com os gestores da área garante maior assertividade nas análises e documentação.
O mapeamento permite a consolidação de processos e análise mais assertiva da execução das atividades do dia a dia da empresa.

FERRAMENTA UTILIZADA

Já utilizamos plataformas como Bizagi Modeler, Figma e Lucid Chart para a construção dos fluxogramas, permitindo a edição e facilidade de acesso, o que, por sua vez, permite a manutenção dos fluxos.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 12 -->

Etapa 3 - Padronização e Otimização
Objetivo Estratégico: orientar a proposição de soluções a partir da identificação de gaps, gargalos e despadronizações nos processos mapeados, atacando causas raiz com foco em produtividade e redução de custos operacionais.
Principais Atividades:

Após realização do mapeamento AS IS do processo:
Identificar os principais gaps, gargalos e oportunidades de padronização e automatização (variações entre turnos, atividades que não agregam valor, retrabalhos e perdas);
Uso de ferramentas estratégicas para priorização: Matriz de decisão, GUT, esforço X impacto, entre outras ferramentas pertinentes ao projeto.

Desenvolvimento de soluções de curto, médio e longo prazo que permitam a padronização, otimização e ganho de eficiência da operação. As recomendações propostas para implementação serão reportadas com auxílio da matriz 5W2H.

Entregável de Valor:  diagnóstico de gargalos priorizado (GUT) e plano de soluções (5W2H) orientado a produtividade e redução de custos.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 13 -->

Etapa 3 - Padronização e Otimização

PRIORIZAÇÃO DE GARGALOS
IDENTIFICAÇÃO DE GARGALOS
Priorizar os gargalos que possuem maior impacto  nos objetivos estratégicos da empresa possibilita maior direcionamento dos planos de ação e uso dos recursos.
Entrevistas com analistas e colaboradores envolvidos nos processos mapeados, visando o entendimento das dores do dia-a-dia e fluxos das informações entre as áreas.
FERRAMENTAS UTILIZADAS
Processos manuais e burocráticos;
Meios de comunicação ineficazes;
Má gestão de tempo;
Processos despadronizados;
Pouca documentação das atividades;
Falta de métricas e indicadores de performance.
Matriz GUT;
Diagramas de Ishikawa;
Matriz Esforço X Impacto;
Análises de Custo X Benefícios.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 14 -->

Etapa 4 - Análise de Capacity
Objetivo Estratégico: dimensionar a capacidade produtiva das equipes da Linha de Mantas e Fitas e da Linha Rotativa Vedapren, garantindo a alocação eficiente de recursos e embasando decisões de produtividade com dados coletados em campo.
Principais Atividades:

Consolidação dos tempos coletados na cronoanálise em tempos padrão por atividade;

Cálculo da taxa de ocupação das equipes por função e por turno;

Avaliar o rendimento do operador, entendendo o tempo esperado para cada atividade e, com base nas cronometragens, classificá-los como acima, abaixo ou dentro do esperado

Comparação entre capacidade instalada e demanda das operações, identificando ociosidades e sobrecargas.

Entregável de Valor: estudo de capacity com taxa de ocupação das equipes e avaliação de rendimento dos operadores por frente de operação.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 15 -->

Etapa 5.1 - Papéis e Responsabilidades
Objetivo Estratégico: identificar os gargalos de atribuição de funções e propor uma estrutura organizacional otimizada, garantindo maior clareza de hierarquias e conexões entre áreas.
Principais Atividades:

Reuniões com gestores para analisar ritos e processos da área

Identificação dos gargalos de clareza no escopo e nas responsabilidades de cada função

Elaboração do organograma TO BE no Lucidspark com base nos gargalos identificados

Definição de cargos, hierarquias, conexões interáreas e critérios de acompanhamento

Entregável de Valor: gargalos de atribuição de funções identificados e organograma TO BE estruturado no Lucidspark
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 16 -->

Etapa 5.2 - Papéis e Responsabilidades
Objetivo Estratégico: consolidar as melhorias de responsabilidades em um documento executivo, garantindo maior clareza na governança e coordenação entre áreas.
Principais Atividades:

Definição das melhorias na estrutura de responsabilidades com base nos gargalos priorizados

Preenchimento do Playbook de Papéis e Funções consolidando as propostas de solução

Entregável de Valor: Playbook de Papéis e Funções com as responsabilidades formalizadas e as melhorias propostas documentadas.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 17 -->

Etapa 5.2 - Papéis e Responsabilidades

Entregável de Valor:  Página online de armazenamento de papéis.

![](GoogleShape671p53.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 18 -->

Etapa 6 - Mapeamento TO BE dos processos
Objetivo Estratégico: redesenhar os processos operacionais da Vedacit incorporando as melhorias identificadas, com foco em padronização, produtividade e clareza operacional entre os diferentes turnos e níveis hierárquicos.
Principais Atividades:

Estruturação dos novos processos (modelagem TO-BE):
Construção dos processos ideais visando sua otimização, padronização e clareza, facilitando a visualização e o conhecimento dos gestores;
Elaborar um mapeamento com os processos revisados, otimizados e sustentáveis, garantindo adesão dos quick wins identificados no novo procedimento padrão.

Garantir uma melhor execução do processo, aproveitando oportunidades, mitigando erros e perdas de material, tornando a operação mais fluida e produtiva.

Entregável de Valor: novos mapeamentos (TO BE) com a correção dos principais gaps, overlaps e despadronizações percebidas.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 19 -->

Etapa 6 - Mapeamento TO BE dos processos

Fluxos redesenhados

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 20 -->

Etapa 7 - Desenvolvimento de POPs e Documentação Final

Objetivo Estratégico: transformar conhecimento tácito em conhecimento institucional, assegurando eficiência, qualidade e continuidade dos resultados.
Principais Atividades:

Desenvolvimento de documentos POP das atividades:
Passo a passo detalhado do processo;
Fluxograma das etapas;
Ferramentas utilizadas;
Glossário com siglas, caso necessário.

Criação de um site específico e personalizado para uso interno da Stanley, contendo os documentos produzidos pela equipe.

Elaboração de uma apresentação executiva com todos os dados coletados e as análises feitas, trazendo os principais insights e planos de ação para o time da Stanley.

Entregável de Valor: Documentação executiva e site repositório do projeto & POPs padronizados e validados
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 21 -->

Etapa 7 - Desenvolvimento de POPs e Documentação Final

Entrega: POPS

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 22 -->

Etapa 7 - Desenvolvimento de POPs e Documentação Final

Entrega: Repositório Online

![](GoogleShape758p58.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 23 -->

Equipe Dedicada ao Projeto e Parceria

![](GoogleShape780p59.jpg)
2 Consultores por 13 semanas
Graduandos Engenheiros Politécnicos da USP da área de Gestão Empresarial e Consultoria da Poli Júnior

1 Coordenador
Membro sênior de projetos da área na empresa
Como será nossa parceria?
Serão realizados reports semanais entre os stakeholders e a equipe para alinhamentos sobre os pontos de atuação e revisão dos resultados;
Os stakeholders colaboram facilitando os insumos necessários (como acesso a documentos e contatos) e com a validação das entregas;
Serão realizadas constantes consultas de experiência e satisfação no decorrer da execução e após sua implementação.
A Poli Júnior se propõe a realizar termos aditivos para contratação de serviços adicionais.

### Notes:

<!-- Slide number: 24 -->

Cases de Sucesso

![](GoogleShape791p60.jpg)

### Notes:

<!-- Slide number: 25 -->
PROBLEMA
SOLUÇÃO
Gerdau

Gestão de Processos
 A equipe responsável realizou o estudo A3, que envolveu a análise e otimização de 3 diferentes
estoques da empresa. Foi executado também um estudo do VSM da fábrica que levou a um maior entendimento dos processos e a várias melhorias em diversos processos internos, alcançando um alto nível de produtividade.
Uma das unidades da Gerdau produzia uma grande diversidade de produtos, variando tanto no tamanho quanto na especificidade química dos produtos, fazendo com que os processos se tornem complexos e sujeitos a gargalos. Sendo assim, a empresa apresentava um alto volume de estoques intermediários, um número de movimentações alto, grande número de produtos não conformes, estoques bagunçados com diversas peças se perdendo no processo e armazenagem incorreta.

IMPACTO

Após análises profundas da equipe e entendimento do estado atual, foi criado
soluções personalizadas junto a um estado futuro em que os produtos poderiam estar prontos em cerca de 30% dos valores anteriores. A Gerdau conseguiu otimizar os seus processos industriais, reduzindo os erros e reprocessamentos internos. Isso gerou uma economia anual estimada em mais de R$2M.

### Notes:

<!-- Slide number: 26 -->

Proposta Comercial
Proposta Comercial

![](GoogleShape873p62.jpg)

![](GoogleShape874p62.jpg)

EQUIPE
DURAÇÃO
INVESTIMENTO

2 Consultores
1 Coordenador

R$ 54.200,00
13 semanas
Cartão, boleto ou transferência. Parcelamento em até 6x.
Pagamento:

### Notes:

<!-- Slide number: 27 -->

Cronograma do projeto - Frente Única

Imersão no Contexto e Diagnóstico de Maturidade
Mapeamento AS IS e Cronoanálise
Padronização e Otimização
Análise de Capacity

Entrega 1
Entrega 2
Entrega 4
Entrega 3
Semanas 1
Semanas 2-3
Semana 5
Semana 4

Mapear a estrutura formal das áreas de operação, incluindo macroprocessos e organograma.

Estudo de capacidade e dimensionamento das equipes, com foco em produtividade e redução de custos.

Mapear os fluxos (AS IS) da Linha de Mantas e Fitas ou da Linha Rotativa Vedapren, com visitas presenciais para cronoanálise.

Identificar e priorizar gargalos (Matriz GUT e Esforço x Impacto) e propor soluções de padronização.

### Notes:

<!-- Slide number: 28 -->

Cronograma do projeto - Frente Única

Desenvolvimento de POPs e Documentação Final
Papéis e Responsabilidades
Mapeamento
TO BE

Entrega 6
Entrega 7
Entrega 5
Semana 8
Semana 7
Semana 6

Consolidar todas as análises e entregas do projeto em documentação executiva e repositório de fácil acesso.

Desenhar os fluxogramas ideais, já padronizados e otimizados, com redução de erros e perdas e ganho de eficiência.

Definir papéis, responsabilidades e hierarquias de forma clara e organizada, consolidados em Matriz RACI.

### Notes:

<!-- Slide number: 29 -->

Proposta Comercial
Proposta Comercial - Frente Única

![](GoogleShape984p65.jpg)

![](GoogleShape985p65.jpg)

EQUIPE
DURAÇÃO
INVESTIMENTO

2 Consultores
1 Coordenador

R$ 33.354,00
8 semanas
Cartão, boleto ou transferência. Parcelamento em até 3x.
Pagamento:

### Notes:

<!-- Slide number: 30 -->

Esclarecimentos Comerciais

![](GoogleShape999p66.jpg)
Nossa minuta padrão contratual - que engloba questões jurídicas como garantias, deveres e responsabilidades, entre outras informações - está disponível neste link.

O CNAE (Classificação Nacional de Atividades Econômicas) da Poli Júnior, a empresa júnior da Escola Politécnica da USP, é 7112-0/00 - Serviços de Engenharia. Essa classificação engloba atividades como consultoria, projetos e outros serviços relacionados à engenharia.

Pareceres: Nossa proposta está em conformidade com a legislação aplicável e nos comprometemos com a qualidade do projeto - assim como para todos nossos clientes. Estamos disponíveis para tiragens de dúvidas durante todo o contato (dados ao final do documento).

Em caso de necessidade de números de contas bancárias, estatuto social, cartão CNPJ, Inscrição Municipal ou outras questões, entrar em contato.

Nosso valor engloba todos os custos estabelecidos pelo projeto, incluindo impostos.

### Notes:

<!-- Slide number: 31 -->

Esclarecimentos Comerciais

![](GoogleShape1011p67.jpg)
Para esta proposta comercial, são válidas as seguintes condições:

No decorrer do projeto, serão realizadas reuniões entre a equipe da Poli Júnior e o cliente para coleta de dados, discussão do andamento do projeto e apresentação de resultados – o cliente se compromete em ter disponibilidade para tais encontros e troca de informações;
As atividades têm início e fim a partir das datas que serão estabelecidas no contrato, documento elaborado mediante a aprovação desta proposta por ambas as partes, Poli Júnior e cliente;
As informações contidas nesta proposta são confidenciais, não devendo ser utilizadas ou apresentadas por qualquer outra pessoa sem o consentimento de ambas as partes;
A equipe da Poli Júnior não trabalhará durante as semanas de prova da Escola Politécnica;
Essa proposta comercial possui validade de 1 mês a contar da data de sua apresentação 08/07/2026;
O projeto poderá ser iniciado 15 dias úteis após a assinatura do contrato;
A contratante deve agir com respeito a todos os envolvidos no serviço em questão, sob pena de rescisão do contrato;
Serão realizadas coletas de satisfação em relação ao projeto no decorrer da execução e ao final do projeto;
No caso de atraso no pagamento de até 10 dias úteis, o projeto será congelado, com retomada prevista em até 5 dias úteis após o devido pagamento ter sido realizado.

### Notes:

<!-- Slide number: 32 -->

Nosso Contato e Próximos Passos

![](GoogleShape1069p68.jpg)

Gabriel Cury Beyruti

Gabriel Torres

Coordenador de Negócios

Consultor de Negócios

gabriel.beyruti@polijunior.com.br

gabriel.torres@polijunior.com.br

11 97561-6380

11 99721-3492

Próximos Passos:
Aprovação Verbal até data estipulada
Validação jurídica da minuta contratual
Assinatura do contrato pelos representantes

### Notes:
