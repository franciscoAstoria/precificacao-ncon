<!-- Slide number: 1 -->

Eficiência e automação com IA no mapeamento de processos

Proposta de Parceria
17 de Junho, 2026

![](GoogleShape67p13.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 2 -->

Poli Júnior - Empresa Júnior da Escola Politécnica da USP

A Poli Júnior é uma instituição constituída por alunos de Graduação da Escola Politécnica de Engenharia da USP.

Localizados na melhor faculdade de engenharia da América Latina, seu projeto é impulsionado pelo mais alto rigor e talentos da Escola Politécnica, garantindo o que há de mais inovador em tecnologias, resultando em soluções ágeis e criativas. Além disso, criando uma forte conexão da empresa com a POLI-USP.

Nossa excelência e agilidade é refinada por treinamentos e parcerias com as maiores consultorias do mundo visando aplicar o mesmo padrão de excelência e pensamento estratégico em nossos projetos.

1º
+1100
90%
lugar
entre as Empresas Juniores do Brasil
Projetos concluídos
Índice de Satisfação
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 3 -->

Quem conta com as soluções da Poli Júnior

![](GoogleShape137p15.jpg)

### Notes:

<!-- Slide number: 4 -->

![](GoogleShape168p16.jpg)

Sumário - Nosso Entendimento do Seu Contexto e Objetivos

Recomendamos a imersão no escritório e o Mapeamento AS IS dos processos, com identificação de gargalos, oportunidades de IA e proposição de soluções, a fim de padronizar o método de execução dos processos entre as áreas.
Contexto:
A Rayes & Fagundes, escritório de advocacia de grande porte com cerca de 100 colaboradores, organiza sua operação em áreas e núcleos cujos processos, parte deles construída pelas próprias equipes, não estão mapeados em sua maior parte. Com o crescimento do volume de processos na última década, a transição do ambiente analógico para o digital não foi acompanhada de uma documentação efetiva e padronizada, o que gera retrabalho, fricção e gargalos como a elaboração manual de relatórios, ainda agravados pela dificuldade de integrar o Spider a outras ferramentas.
Objetivos:
Diante disso, a Poli Júnior se propõe a mapear os processos atuais (AS IS) das áreas priorizadas, identificando gargalos, oportunidades de melhoria e onde a IA pode gerar ganhos concretos, e a propor as soluções e ferramentas mais aderentes a cada caso. O objetivo é padronizar o método de execução dos processos entre as equipes, garantindo um mesmo padrão de trabalho em todo o escritório e preparando o terreno para a aplicação de IA e de novas tecnologias.

Entregas frequentes que geram valor rápido
Conexão com a USP e talentos da Escola Politécnica

Projetos que integram otimização e tecnologias inovadoras à sua empresa
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 5 -->

Cronograma do projeto

Identificação de gargalos e soluções de IA
Imersão no contexto
Mapeamento AS IS
Mapeamento TO BE
Documentação final

Entrega 4
Entrega 5
Entrega 3
Entrega 2
Entrega 1
Semana 8
Semana 7
Semanas 2-4
Semanas 5-6
Semana 1

Consolidado de documentação robusta com desenvolvimento do projeto e principais outputs.

Mapear os fluxos atuais dos processos das áreas priorizadas a partir das entrevistas com os núcleos.

Redesenho dos processos em sua forma otimizada, já incorporando as aplicações de IA nos pontos de automação identificados.

Entender a estrutura das áreas e núcleos, mapear stakeholders e sistemas, definir áreas piloto e agendar as reuniões.

Identificação e priorização de gargalos, com proposição de soluções e avaliação das oportunidades de automação com IA em cada etapa dos fluxos.

### Notes:

<!-- Slide number: 6 -->

Etapa 1 - Imersão no contexto
Objetivo Estratégico: alinhar os principais pontos do projeto e entender a estrutura do escritório, garantindo conformidade entre as equipes da Rayes & Fagundes e da Poli Júnior.
Principais Atividades:

Realização do kick-off com a equipe da Rayes & Fagundes: definição dos pontos focais, expectativas e alinhamentos iniciais;

Reunião inicial com o Vitor para obter uma visão macro de como os núcleos operam hoje;

Entendimento da estrutura das áreas e núcleos, identificando responsáveis, sistemas utilizados e documentações existentes;

Definição das áreas piloto e agendamento das reuniões de mapeamento e dos reports semanais.

Entregável de Valor:  elaboração do Canvas de Escopo e Cronograma do projeto.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 7 -->

Etapa 2 - Mapeamento AS-IS dos processos
Objetivo Estratégico: construir os fluxogramas dos processos das áreas priorizadas, que servirão de base para a padronização e a identificação das oportunidades de automação e IA.
Principais Atividades:

Realização de entrevistas com responsáveis e envolvidos nos processos:
Reuniões de mapeamento com cerca de 15 colaboradores-chave dos núcleos da empresa;
Aproximadamente 15 reuniões de mapeamento de 1 hora cada.

Entendimento do fluxograma (mapeamento e modelagem AS IS):
Atividades e atores que participam nos processos das áreas;
Identificação das etapas manuais e com retrabalho;
Comunicação entre áreas, fontes de dados e canais de informação

Entregável de Valor:  Fluxos construídos e validados pelos stakeholders.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 8 -->

Etapa 2 - Mapeamento AS-IS dos processos

VALIDAÇÃO
MAPEAMENTO
Validar o mapeamento de um processo com os gestores da área garante maior assertividade nas análises e documentação.
O mapeamento permite a consolidação de processos e análise mais assertiva da execução das atividades do dia a dia da empresa.

FERRAMENTA UTILIZADA

Já utilizamos plataformas como Bizagi Modeler, Figma e Lucid Chart para a construção dos fluxogramas, permitindo a edição e facilidade de acesso, o que, por sua vez, permite a manutenção dos fluxos.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 9 -->
Etapa 3 - Identificação de gargalos e soluções de IA

Objetivo Estratégico: orientar a proposição de soluções a partir da identificação de gaps, etapas manuais e dores nos processos mapeados, avaliando onde a IA pode gerar ganhos concretos.
Principais Atividades:

Após realização do mapeamento AS IS do processo:
Identificar os principais gargalos, atividades manuais, retrabalhos e inconsistências nos fluxos das áreas;
Uso de ferramentas como a Matriz GUT, esforço X impacto e análises de custo X benefício para a priorização dos gargalos.
Classificação das oportunidades de IA por tipo de aplicação, como geração de relatórios, organização e recuperação de informações e apoio à padronização e execução de tarefas;

Recomendação da ferramenta de IA mais adequada para cada caso, conforme aderência ao processo, aos sistemas do escritório e ao tipo de demanda, detalhada com o apoio da matriz 5W2H.

Entregável de Valor:  Consolidado com gargalos e gaps identificados e priorizados, além de planos de ação 5W2H para os pontos priorizados.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 10 -->

Etapa 3 - Identificação de gargalos e soluções de IA

PRIORIZAÇÃO DE GARGALOS
IDENTIFICAÇÃO DE GARGALOS
Priorizar os gargalos que possuem maior impacto  nos objetivos estratégicos da empresa possibilita maior direcionamento dos planos de ação e uso dos recursos.
Entrevistas com analistas e colaboradores envolvidos nos processos mapeados, visando o entendimento das dores do dia-a-dia e fluxos das informações entre as áreas.
FERRAMENTAS UTILIZADAS
Processos manuais e burocráticos;
Meios de comunicação ineficazes;
Má gestão de tempo;
Processos despadronizados;
Pouca documentação das atividades;
Falta de métricas e indicadores de performance.
Matriz GUT;
Diagramas de Ishikawa;
Matriz Esforço X Impacto;
Análises de Custo X Benefícios.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 11 -->

Etapa 3 - Identificação de gargalos e soluções de IA

Entrega: Gargalos e Soluções

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 12 -->

Etapa 3 - Identificação de gargalos e soluções de IA

Entrega: Diagrama de Solução

![](GoogleShape359p24.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 13 -->

Etapa 4 - Mapeamento TO BE
Objetivo Estratégico: garantir padronização e excelência operacional por meio do redesenho dos processos futuros (TO BE), já incorporando as aplicações de IA identificadas.
Principais Atividades:

Estruturação dos novos processos (modelagem TO-BE):
Construção dos processos ideais visando padronização e clareza, indicando em cada etapa onde a IA assume atividades hoje manuais;
Mapeamento dos processos revisados e otimizados, garantindo a adesão dos quick wins ao novo padrão de execução.

Garantir uma execução mais consistente, reduzindo a dependência do esforço manual e padronizando o método de trabalho utilizado pelas diferentes equipes.

Entregável de Valor: novos mapeamentos com a correção dos principais gaps e a indicação das aplicações de IA em cada fluxo.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 14 -->

Etapa 4 - Mapeamento TO BE

Entrega: Fluxos redesenhados

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 15 -->

Etapa 5 - Documentação Final
Objetivo Estratégico: consolidar todo o estudo e as entregas realizadas em um formato de fácil acesso e disseminação para a equipe da Rayes & Fagundes.
Principais Atividades:

Estruturação de uma documentação executiva contendo as principais entregas e análises do projeto de forma enxuta;

Criação de um site específico e personalizado para uso interno da Rayes & Fagundes contendo os documentos produzidos pela equipe da Poli Júnior e formatado de forma intuitiva para fácil usabilidade.

Entregável de Valor: documentação executiva e site personalizado para a Rayes & Fagundes
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 16 -->

Etapa 5 - Documentação Final

Entrega: Repositório Online

![](GoogleShape427p28.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 17 -->

![](GoogleShape450p29.jpg)

Equipe Dedicada ao Projeto e Parceria
2 Consultores por 8 semanas
Graduandos Engenheiros Politécnicos da USP da área de Gestão Empresarial e Consultoria da Poli Júnior
1 Coordenador
Membro sênior de projetos da área na empresa
Como será nossa parceria?
Serão realizados reports semanais entre os stakeholders e a equipe para alinhamentos sobre os pontos de atuação e revisão dos resultados;
Os stakeholders colaboram facilitando os insumos necessários (como acesso a documentos e contatos) e com a validação das entregas;
Serão realizadas constantes consultas de experiência e satisfação no decorrer da execução e após sua implementação.
A Poli Júnior se propõe a realizar termos aditivos para contratação de serviços adicionais.

### Notes:

<!-- Slide number: 18 -->

Cases de Sucesso

![](GoogleShape461p30.jpg)

### Notes:

<!-- Slide number: 19 -->
Banco Pine
PROBLEMA
SOLUÇÃO
Gestão de Processos

Mapeamento e identificação de gargalos, alcançando algumas quick wins, como a automatização de
tarefas em planilhas e ajustes na comunicação entre as áreas. Por fim, documentação do fluxograma
realizado com mais de 120 funcionários (As Is) e modelo que deverá ser implementado (To Be).

Dificuldade na área de fechamento contábil por falta de padronização dos processos internos,
atividades manuais e falha de comunicação entre as áreas, causando reprocessamentos contábeis em grande escala e atrasos.
IMPACTO

Implementação de metodologias ágeis para a realização dos processos, proporcionando redução de aproximadamente 50% no tempo de execução dos processos de Fechamento Contábil.

### Notes:

<!-- Slide number: 20 -->

![](GoogleShape540p32.jpg)

Proposta Comercial

![](GoogleShape541p32.jpg)

EQUIPE
DURAÇÃO
INVESTIMENTO

2 Consultores
1 Coordenador

8 semanas
R$32.100,00
Pagamento: Cartão, Boleto ou Transferência | Em até 4x com parcelas a serem pagas nos Dia 10, 20 ou 30 do mês

### Notes:

<!-- Slide number: 21 -->

![](GoogleShape581p33.jpg)

Proposta Comercial

![](GoogleShape582p33.jpg)
10% de desconto
Assinatura até 29/06/2026

EQUIPE
DURAÇÃO
INVESTIMENTO

2 Consultores
1 Coordenador

8 semanas
R$28.890,00
Pagamento: Cartão, Boleto ou Transferência | Em até 4x com parcelas a serem pagas nos Dia 10, 20 ou 30 do mês

### Notes:

<!-- Slide number: 22 -->

![](GoogleShape593p34.jpg)

Esclarecimentos Comerciais
Nossa minuta padrão contratual - que engloba questões jurídicas como garantias, deveres e responsabilidades, entre outras informações - está disponível neste link.

O CNAE (Classificação Nacional de Atividades Econômicas) da Poli Júnior, a empresa júnior da Escola Politécnica da USP, é 7112-0/00 - Serviços de Engenharia. Essa classificação engloba atividades como consultoria, projetos e outros serviços relacionados à engenharia.

Pareceres: Nossa proposta está em conformidade com a legislação aplicável e nos comprometemos com a qualidade do projeto - assim como para todos nossos clientes. Estamos disponíveis para tiragens de dúvidas durante todo o contato (dados ao final do documento).

Em caso de necessidade de números de contas bancárias, estatuto social, cartão CNPJ, Inscrição Municipal ou outras questões, entrar em contato.

Nosso valor engloba todos os custos estabelecidos pelo projeto, incluindo impostos.

### Notes:

<!-- Slide number: 23 -->

![](GoogleShape605p35.jpg)

Esclarecimentos Comerciais
Para esta proposta comercial, são válidas as seguintes condições:

No decorrer do projeto, serão realizadas reuniões entre a equipe da Poli Júnior e o cliente para coleta de dados, discussão do andamento do projeto e apresentação de resultados – o cliente se compromete em ter disponibilidade para tais encontros e troca de informações;
As atividades têm início e fim a partir das datas que serão estabelecidas no contrato, documento elaborado mediante a aprovação desta proposta por ambas as partes, Poli Júnior e cliente;
As informações contidas nesta proposta são confidenciais, não devendo ser utilizadas ou apresentadas por qualquer outra pessoa sem o consentimento de ambas as partes;
A equipe da Poli Júnior não trabalhará durante as semanas de prova da Escola Politécnica;
Essa proposta comercial possui validade de 1 mês a contar da data de sua apresentação 17/06/2026;
O projeto poderá ser iniciado 15 dias úteis após a assinatura do contrato;
A contratante deve agir com respeito a todos os envolvidos no serviço em questão, sob pena de rescisão do contrato;
Serão realizadas coletas de satisfação em relação ao projeto no decorrer da execução e ao final do projeto;
No caso de atraso no pagamento de até 10 dias úteis, o projeto será congelado, com retomada prevista em até 5 dias úteis após o devido pagamento ter sido realizado.

### Notes:

<!-- Slide number: 24 -->

![](GoogleShape640p36.jpg)

Nosso Contato e Próximos Passos

Gabriel Beyruti

Coordenador de Negócios

gabriel.beyruti@polijunior.com.br

11 97561-6380

Próximos Passos:
Aprovação Verbal
Validação jurídica da minuta contratual
Assinatura do contrato pelos representantes

### Notes:
