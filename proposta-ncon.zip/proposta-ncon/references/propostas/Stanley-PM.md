<!-- Slide number: 1 -->

Estudo de Mercado para Estruturação de Plano de Ação sobre Frete Grátis no E-commerce

Proposta de Parceria
09 de Julho, 2026

![](GoogleShape67p13.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 2 -->

Poli Júnior - Empresa Júnior da Escola Politécnica da USP

A Poli Júnior é uma instituição constituída por alunos de Graduação da Escola Politécnica de Engenharia da USP.

Localizados na melhor faculdade de engenharia da América Latina, seu projeto é impulsionado pelo mais alto rigor e talentos da Escola Politécnica, garantindo o que há de mais inovador em tecnologias, resultando em soluções ágeis e criativas. Além disso, criando uma forte conexão da empresa com a POLI-USP.

Nossa excelência e agilidade é refinada por treinamentos e parcerias com as maiores consultorias do mundo visando aplicar o mesmo padrão de excelência e pensamento estratégico em nossos projetos.

1º
+1100
90%
lugar
entre as Empresas Juniores do Brasil
Projetos concluídos
Índice de Satisfação
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 3 -->

Quem conta com as soluções da Poli Júnior

![](GoogleShape137p15.jpg)

### Notes:

<!-- Slide number: 4 -->

![](GoogleShape166p16.jpg)

Sumário - Nosso Entendimento do Seu Contexto e Objetivos

Recomendamos a condução de um diagnóstico integrado entre a voz do consumidor e o benchmark de mercado, capaz de direcionar a estruturação de um plano de ação para testagem de frete no E-commerce da Stanley
Contexto:
A Stanley enxerga no canal de E-commerce (DTC) uma importante frente de crescimento de receita, que depende tanto do aumento de tráfego no site quanto da efetiva conversão desses acessos em compras.
Atualmente, uma parcela relevante dos clientes que adicionam produtos ao carrinho não finaliza a compra, sinalizando uma possível barreira relacionada ao custo e à política de frete.
Nesse cenário, torna-se essencial compreender, de forma embasada, se a disponibilização de frete grátis é capaz de aumentar a conversão de forma significativa e qual formato de aplicação traria o maior impacto no canal.

Projetos que integram otimização e tecnologias inovadoras à sua empresa
Conexão com a USP e talentos da Escola Politécnica

Entregas frequentes que geram valor rápido
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 5 -->

![](GoogleShape192p17.jpg)

Principais objetivos da Stanley

Objetivos:

"Ao cruzar a voz do consumidor com as práticas de mercado, é possível construir uma resposta fundamentada sobre o impacto do frete na conversão, entregando à Stanley um plano de ação pronto para validação."
Entender o peso do frete na conversão do E-commerce, ouvindo utilizadores e potenciais compradores de garrafas térmicas para identificar se o frete grátis aumentaria as vendas e se esse impacto seria significativo.

Mapear práticas de frete de players do setor, local e globalmente, via benchmark de concorrentes e cliente oculto.

Estruturar um plano de ação validado para testagem da hipótese, com metodologia, cenários de teste e critérios de sucesso, entregue em uma apresentação executiva.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 6 -->

Cronograma do projeto

FASE 2: Iniciar Desenvolvimento Iterativo de Automações
Rodagem do Questionário e Benchmark de Mercado
Planos de Ação e Documentação Final
Estruturação de Instrumentos de Pesquisa
Imersão no contexto
Dashboard e Análise dos Dados

Entrega 4
Entrega 1
Entrega 2
Entrega 3
Semana 5
Semanas 2-3
Semana 4
Semana 1

Alinhar objetivos com os stakeholders e mapear os pontos-chave do benchmarking.

Desenvolver questionário e roteiro de entrevista das benches.

Analisar os dados do questionário e construir a dashboard de resultados.

Estruturar o plano de ação para testagem da hipótese de frete e consolidar as entregas.

Aplicar o questionário com potenciais utilizadores de garrafas térmicas e conduzir benches e cliente oculto.

### Notes:

<!-- Slide number: 7 -->

Etapa 1 - Imersão no contexto
Semana 1
Objetivo Estratégico: alinhar os principais pontos do projeto com os stakeholders da Stanley, garantindo a devida priorização estratégica para as próximas etapas.
Principais Atividades:

Realização do kick-off de equipe para os alinhamentos iniciais.

Entendimento dos principais pontos a serem observados na análise de concorrentes e no questionário.

Estudo mercadológico breve para mapear os 3 concorrentes a serem analisados e as empresas candidatas às reuniões de benchmark.

Co-criação da Matriz CSD, usada para direcionar os primeiros estudos e o roteiro das reuniões de benchmark.

Entregável de Valor:  Cronograma do projeto, Matriz CSD e lista de concorrentes/empresas mapeadas.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 8 -->

Etapa 1 - Imersão no contexto
Semana 1

Brainstorm: Pontos de atenção elencados

![](GoogleShape282p20.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 9 -->

Etapa 2 - Estruturação de Instrumentos de Pesquisa
Semana 1
Objetivo Estratégico: Desenvolver os instrumentos e metodologia que vão embasar o diagnóstico, garantindo que capturem os fatores de decisão de frete do consumidor e as práticas de mercado.
Principais Atividades:

Perfil da amostra:
400 respondentes, divididos em dois grupos:
200 utilizadores de garrafas térmicas (Stanley e concorrentes);
200 pessoas com intenção de compra nos próximos 12 meses.

As perguntas estratégicas permitirão:
Identificar o peso do frete frente a outros fatores de compra;
Mapear trade-offs entre frete, prazo e preço;
Entender barreiras de conversão no checkout;
Avaliar percepção frente aos concorrentes.

Elaboração do roteiro para as reuniões de benchmark e definição do escopo da análise de concorrentes (cliente oculto e desk research).

Entregável de Valor:  Fluxograma do questionário e roteiro de entrevista construídos e validados com os stakeholders
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 10 -->

Etapa 2 - Estruturação de Instrumentos de Pesquisa
Semana 1

Exemplo: Fluxograma do questionário

![](GoogleShape321p22.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 11 -->

Etapa 3 - Rodagem do Questionário e Benchmark de Mercado
Semanas 2-3
Objetivo Estratégico: realizar um estudo aprofundado dos concorrentes identificados, mapeando como atuam no mercado e suas práticas de frete, além de aplicar o questionário com o público-alvo.
Principais Atividades:

Realização de até 3 reuniões de benchmark com perfis estratégicos, mapeando:
Posicionamento estratégico e portfólio de ofertas;
Estrutura de custos e preços;
Dimensionamento do potencial de mercado.

Desk research e cliente oculto nos 3 concorrentes diretos mapeados:
Política de frete (frete grátis, threshold mínimo, prazo de entrega);
Formas de comunicação do frete ao consumidor (banner, barra de progresso, aviso no carrinho);
Experiência de checkout (número de etapas, formas de pagamento, exigência de cadastro);

Aplicação do questionário em paralelo, com os 400 respondentes (utilizadores e potenciais compradores de garrafas térmicas)

Entregável de Valor:  Relatório das reuniões de benchmark e base de respostas do questionário.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 12 -->

Etapa 4 - Dashboard e Análise dos Dados Coletados
Semana 4
Objetivo Estratégico: realizar as análises com maior detalhe crítico sobre os dados coletados durante o questionário, o cliente oculto e o benchmark.
Principais Atividades:

Desenvolvimento da dashboard com os dados do questionário, estruturando os principais indicadores de comportamento e sensibilidade ao frete dos dois grupos pesquisados.

Análise dos dados e padrões provenientes da dashboard, identificando o peso do frete frente a outros fatores de decisão e as diferenças entre utilizadores e potenciais compradores.

Análise das informações obtidas no cliente oculto e nas reuniões de benchmark, compreendendo as práticas de frete de cada player mapeado.

Entregável de Valor:  Dashboard interativa com os dados do questionário e relatório qualitativo com os insights do cliente oculto e do benchmark.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 13 -->

Etapa 4 - Base de respostas
Semana 4

![](GoogleShape380p25.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 14 -->

Etapa 4 - Dashboard
Semana 4

![](GoogleShape391p26.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 15 -->

Etapa 5 - Planos de Ação e Documentação Final
Semana 5
Objetivo Estratégico: consolidar todo o estudo em planos de ação e uma recomendação final que respondam ao objetivo central da Stanley: aumentar a receita do canal DTC através de maior conversão de compras efetivas.
Principais Atividades:

Cruzamento dos dados do questionário, do cliente oculto e do benchmark, para responder se o frete grátis aumentaria a conversão e se esse impacto seria significativo.

Estruturação dos planos de ação, contemplando os testes que a Stanley pode rodar em seu E-commerce para validar a hipótese, com embasamento técnico e metodológico, e as mudanças a serem realizadas na política de frete a partir dos resultados.

Priorização dos planos de ação, indicando esforço, impacto esperado e responsáveis pela execução.

Entregável de Valor: Planos de ação priorizados com os próximos passos para a decisão sobre frete no E-commerce.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 16 -->

Etapa 5 - Planos de Ação e Documentação Final
Semana 5
Objetivo Estratégico: consolidar todo o estudo e as entregas realizadas em um formato de fácil acesso e disseminação para a equipe da Stanley
Principais Atividades:

Estruturação de uma documentação executiva contendo as principais entregas e análises do projeto de forma enxuta;

Criação de um site específico e personalizado para uso interno da Stanley contendo os documentos produzidos pela equipe da Poli Júnior e formatado de forma intuitiva para fácil usabilidade.

Entregável de Valor: documentação executiva e site personalizado para a Stanley
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 17 -->

Etapa 5 - Planos de Ação e Documentação Final

Semana 5
Entrega: Repositório Online

![](GoogleShape451p29.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 18 -->

![](GoogleShape474p30.jpg)

Equipe Dedicada ao Projeto e Parceria
1 Consultor por 5 semanas
Graduandos Engenheiros Politécnicos da USP da área de Gestão Empresarial e Consultoria da Poli Júnior

1 Coordenador
Membro sênior de projetos da área na empresa
Como será nossa parceria?
Serão realizados reports semanais entre os stakeholders e a equipe para alinhamentos sobre os pontos de atuação e revisão dos resultados;
Os stakeholders colaboram facilitando os insumos necessários (como acesso a documentos e contatos) e com a validação das entregas;
Serão realizadas constantes consultas de experiência e satisfação no decorrer da execução e após sua implementação.
A Poli Júnior se propõe a realizar termos aditivos para contratação de serviços adicionais.

### Notes:

<!-- Slide number: 19 -->

Cases de Sucesso

![](GoogleShape485p31.jpg)

### Notes:

<!-- Slide number: 20 -->
PROBLEMA
SOLUÇÃO
Mitt Incorporadora

Pesquisa de Mercado
A equipe realizou um estudo mercadológico e territorial completo, englobando análises socioeconômicas, levantamento de concorrentes e pesquisa quantitativa com moradores da região. A partir dos dados coletados, foram desenvolvidos mapas de calor, análises comparativas e planos de ação estratégicos, indicando as áreas de maior potencial de valorização e os perfis prioritários de clientes.
A empresa buscava analisar o potencial do mercado imobiliário em uma cidade no interior de Minas Gerais, visando compreender o perfil do público e os fatores decisivos na compra de imóveis. Era necessário um mapeamento detalhado da demanda local, identificação de tendências, estudo de concorrência e avaliação das melhores oportunidades de posicionamento estratégico para um novo empreendimento.

![](GoogleShape527p32.jpg)

IMPACTO

O projeto forneceu à empresa uma base sólida para a tomada de decisão sobre o novo empreendimento, com insights sobre público, localização e demanda. As análises apontaram as regiões mais promissoras e o ticket médio ideal, permitindo definir o posicionamento de mercado e estratégias comerciais mais assertivas, reduzindo riscos e otimizando investimentos futuros.

### Notes:

<!-- Slide number: 21 -->

Proposta Comercial

![](GoogleShape565p33.jpg)

EQUIPE
DURAÇÃO
INVESTIMENTO

1 Consultor
1 Coordenador

5 semanas
R$ 18.100,00
Pagamento: Cartão, Boleto ou Transferência | Em até 4x com parcelas a serem pagas nos Dia 10, 20 ou 30 do mês

### Notes:

<!-- Slide number: 22 -->

![](GoogleShape576p34.jpg)

Esclarecimentos Comerciais
Nossa minuta padrão contratual - que engloba questões jurídicas como garantias, deveres e responsabilidades, entre outras informações - está disponível neste link.

O CNAE (Classificação Nacional de Atividades Econômicas) da Poli Júnior, a empresa júnior da Escola Politécnica da USP, é 7112-0/00 - Serviços de Engenharia. Essa classificação engloba atividades como consultoria, projetos e outros serviços relacionados à engenharia.

Pareceres: Nossa proposta está em conformidade com a legislação aplicável e nos comprometemos com a qualidade do projeto - assim como para todos nossos clientes. Estamos disponíveis para tiragens de dúvidas durante todo o contato (dados ao final do documento).

Em caso de necessidade de números de contas bancárias, estatuto social, cartão CNPJ, Inscrição Municipal ou outras questões, entrar em contato.

Nosso valor engloba todos os custos estabelecidos pelo projeto, incluindo impostos.

### Notes:

<!-- Slide number: 23 -->

![](GoogleShape588p35.jpg)

Esclarecimentos Comerciais
Para esta proposta comercial, são válidas as seguintes condições:

No decorrer do projeto, serão realizadas reuniões entre a equipe da Poli Júnior e o cliente para coleta de dados, discussão do andamento do projeto e apresentação de resultados – o cliente se compromete em ter disponibilidade para tais encontros e troca de informações;
As atividades têm início e fim a partir das datas que serão estabelecidas no contrato, documento elaborado mediante a aprovação desta proposta por ambas as partes, Poli Júnior e cliente;
As informações contidas nesta proposta são confidenciais, não devendo ser utilizadas ou apresentadas por qualquer outra pessoa sem o consentimento de ambas as partes;
A equipe da Poli Júnior não trabalhará durante as semanas de prova da Escola Politécnica;
Essa proposta comercial possui validade de 1 mês a contar da data de sua apresentação 09/07/2026;
O projeto poderá ser iniciado 15 dias úteis após a assinatura do contrato;
A contratante deve agir com respeito a todos os envolvidos no serviço em questão, sob pena de rescisão do contrato;
Serão realizadas coletas de satisfação em relação ao projeto no decorrer da execução e ao final do projeto;
No caso de atraso no pagamento de até 10 dias úteis, o projeto será congelado, com retomada prevista em até 5 dias úteis após o devido pagamento ter sido realizado.

### Notes:

<!-- Slide number: 24 -->

![](GoogleShape647p36.jpg)

Nosso Contato e Próximos Passos

Gabriel Cury Beyruti

Lucca Ryuiti

Consultor de Negócios

Coordenador de Negócios

gabriel.beyruti@polijunior.com.br

lucca.ryuiti@polijunior.com.br

11 97561-6380

11 98710-0468

Próximos Passos:
Aprovação Verbal até data estipulada
Validação jurídica da minuta contratual
Assinatura do contrato pelos representantes

### Notes:
