<!-- Slide number: 1 -->

Mapeamento e Otimização do Processo de Aquisições e Documentação Técnica da Ascenty

Proposta de Parceria
04 de Setembro, 2026

Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 2 -->

Poli Júnior - Empresa Júnior da Escola Politécnica da USP

A Poli Júnior é uma instituição constituída por alunos de Graduação da Escola Politécnica de Engenharia da USP.

Localizados na melhor faculdade de engenharia da América Latina, seu projeto é impulsionado pelo mais alto rigor e talentos da Escola Politécnica, garantindo o que há de mais inovador em tecnologias, resultando em soluções ágeis e criativas. Além disso, criando uma forte conexão da empresa com a POLI-USP.

Nossa excelência e agilidade é refinada por treinamentos e parcerias com as maiores consultorias do mundo visando aplicar o mesmo padrão de excelência e pensamento estratégico em nossos projetos.

1º
+1100
90%
lugar
entre as Empresas Juniores do Brasil
Projetos concluídos
Índice de Satisfação
Gestão Empresarial e Consultoria - Poli Júnior

SOMENTE ENVIADO EM PDF

<!-- Slide number: 3 -->

Quem conta com as soluções da Poli Júnior

<!-- Slide number: 4 -->

Sumário - Nosso Entendimento do Seu Contexto
Uma proposta para estruturar e fortalecer a eficiência operacional dos processos da Ascenty.

Recomendamos a realização dos mapeamentos AS IS e TO BE dos processos da empresa, bem como a elaboração de manuais e a proposição de soluções personalizadas, incluindo aplicações de IA, a fim de promover maior clareza, padronização e eficiência antes do início do novo projeto de data center.
Contexto:
A Ascenty, empresa de data centers e conectividade que atua em projetos de infraestrutura crítica, vive um momento de forte crescimento, impulsionado principalmente por IA, com plano de expandir de 250MW para 1GW até 2028 e de mais que dobrar seu quadro de colaboradores. Nesse ritmo, a operação avança mais rápido do que a estruturação dos processos que a sustentam, e os fluxos internos ainda carecem de clareza e padronização, com retrabalho, atividades manuais e comunicação deficiente entre áreas, além de conhecimento crítico concentrado em poucas pessoas.
Nesse sentido, o processo de aquisições e documentação técnica para RFPs é o de maior potencial de ganho: envolve equipamentos de alto valor, alinhamento entre engenharia, supply, comissionamento, campo e cliente, e hoje demanda de três a quatro rodadas de validação técnica e comercial até a equalização das propostas. Como consequência, a Engenharia, que serve de base para as demais áreas, opera sem as métricas que revelariam onde estão as perdas, cenário que tende a se agravar com a entrada do novo projeto de data center.

Entregas frequentes que geram valor rápido
Conexão com a USP e talentos da Escola Politécnica

Projetos que integram otimização e tecnologias inovadoras à sua empresa
Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 5 -->

Principais desafios da Ascenty

Objetivos:
Dar visibilidade ao processo de aquisições da Engenharia e às interfaces com supply, comissionamento e operação.

Identificar e priorizar os gargalos que geram retrabalho e rodadas extras de equalização, propondo soluções.

"Às vezes é um talento que eu poderia estar explorando tecnicamente muito mais, e a pessoa tá gastando metade do dia dela pra fazer organização de processo."

Mapear oportunidades de IA nas rotinas de aquisições e documentação técnica, especificando as soluções priorizadas.

Padronizar o processo em um fluxo redesenhado que reduza desvios de execução e acelere as aquisições de alto valor.

Documentar o conhecimento hoje concentrado em poucas pessoas, em manuais para consulta e treinamento.

Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 6 -->

Cronograma do projeto

Imersão no contexto
Mapeamento AS IS
Gargalos e Soluções
Mapeamento TO BE
Elaboração de Manuais
Documentação Final

Entrega 1
Entrega 2
Entrega 3
Entrega 4
Entrega 5
Semana 1
Semanas 2-3
Semanas 4-5
Semana 6
Semana 7

Alinhar escopo, pontos focais e agenda de reuniões com os stakeholders.

Mapear o fluxo atual de aquisições, da RFP ao aceite do equipamento.

Priorizar os gargalos com Matriz GUT e propor planos de ação 5W2H.

Redesenhar o processo com menos rodadas de equalização e papéis claros.

Elaborar os POPs das atividades mapeadas e validadas.

Consolidar as entregas em documentação executiva e repositório online.

<!-- Slide number: 7 -->

Etapa 1 - Imersão no contexto
Objetivo Estratégico: alinhar os principais pontos do projeto com os stakeholders da Ascenty, garantindo clareza sobre os processos de aquisição e engenharia a serem mapeados.
Principais Atividades:

Realização do kick-off: definição dos pontos focais, alinhamento de expectativas e validação dos processos prioritários de aquisição e Engenharia.

Entendimento macro da estrutura da área, considerando a atuação dos 9 colaboradores e iniciativas já desenvolvidas.

Agendamento das reuniões de mapeamento e dos reports semanais, garantindo uma cadência próxima de validação das entregas.

Entregável de Valor:  Canvas de Escopo e Cronograma do projeto.
Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 8 -->

Etapa 2 - Mapeamento AS-IS dos processos
Objetivo Estratégico: construir os fluxogramas detalhados dos processos atuais, evidenciando variações de execução e oportunidades de padronização.
Principais Atividades:

Realização de entrevistas com responsáveis envolvidos nos processos:
Até 16 reuniões de mapeamento de aproximadamente 1 hora cada.

Entendimento do fluxograma AS IS, considerando:
Atividades executadas e sistemas utilizados;
Responsáveis e comunicações entre áreas;
Principais pontos de repetição.

Entregável de Valor:  Fluxos construídos e validados pelos stakeholders.
Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 9 -->

Etapa 2 - Mapeamento AS-IS dos processos

DIAGRAMA DE ESCOPO
MAPEAMENTO
Consolidar o entendimento do processo sob aspectos macro, como entradas, saídas, duração, RACI, gargalos e etc.
O mapeamento permite a consolidação de processos e análise mais assertiva da execução das atividades do dia a dia da empresa.

Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 10 -->

Etapa 3 - Identificação de gargalos e proposição de soluções
Objetivo Estratégico: orientar a proposição de soluções a partir da identificação de gaps, overlaps, tarefas repetitivas e oportunidades de automação e de aplicação de IA nos processos mapeados.
Principais Atividades:

Identificação dos principais gargalos operacionais, considerando atividades manuais, recorrência de retrabalho, dependência de sistemas, falhas de padronização, uso de canais paralelos e pontos de baixa fluidez entre áreas.

Priorização dos gargalos com ferramentas estratégicas como Matriz GUT, Esforço x Impacto e análise de custo-benefício, permitindo direcionar as soluções;

Proposição de soluções organizacionais e tecnológicas, como padronização de fluxo, melhoria de controles e aplicações de IA em tarefas repetitivas, com potencial de reduzir esforço manual e aumentar previsibilidade.

Entregável de Valor:  Gargalos priorizados com GUT, 5W2H, Diagrama de Solução e Initiative Charter.
Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 11 -->

Etapa 3 - Identificação de gargalos e proposição de soluções

PRIORIZAÇÃO DE GARGALOS
IDENTIFICAÇÃO DE GARGALOS
Priorizar os gargalos que possuem maior impacto  nos objetivos estratégicos da empresa possibilita maior direcionamento dos planos de ação e uso dos recursos.
Entrevistas com analistas e colaboradores envolvidos nos processos mapeados, visando o entendimento das dores do dia-a-dia e fluxos das informações entre as áreas.
FERRAMENTAS UTILIZADAS
Processos manuais e burocráticos;
Meios de comunicação ineficazes;
Má gestão de tempo;
Processos despadronizados;
Pouca documentação das atividades;
Falta de métricas e indicadores de performance.
Matriz GUT;
Diagramas de Ishikawa;
Matriz Esforço X Impacto;
Análises de Custo X Benefícios.
Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 12 -->

Etapa 3 - Identificação de gargalos e proposição de soluções

Entrega: Gargalos e Soluções

Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 13 -->

Etapa 3 - Identificação de gargalos e proposição de soluções

Entrega: Matriz Esforço x Impacto

Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 14 -->

Etapa 3 - Identificação de gargalos e proposição de soluções

Entrega: Initiative Charter

Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 15 -->

Etapa 4 - Mapeamento TO-BE dos processos
Objetivo Estratégico: garantir maior eficiência, padronização e excelência operacional por meio do redesenho dos processos futuros das áreas analisadas.
Principais Atividades:

Construção dos fluxos TO BE, incorporando as soluções priorizadas e desenhando uma operação mais clara, fluida e aderente à rotina das equipes da Ascenty.

Redesenho dos processos com foco em redução de atividades manuais, maior clareza de responsabilidades, diminuição de retrabalho e melhor integração entre sistemas, canais e áreas envolvidas.

Validação dos fluxos otimizados com os stakeholders, garantindo que as recomendações sejam aplicáveis à realidade da Ascenty e possam sustentar futuras automações com maior segurança.

Entregável de Valor: novos mapeamentos com a correção dos principais gaps e overlaps.
Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 16 -->

Etapa 4 - Mapeamento TO BE dos processos

Entrega: Fluxos redesenhados

Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 17 -->

Etapa 5 - Elaboração de Manuais
Objetivo Estratégico: transformar conhecimento tácito em conhecimento institucional, assegurando eficiência, qualidade e continuidade dos resultados.
Principais Atividades:

Desenvolvimento de Manuais das atividades:
Passo a passo detalhado do processo;
Fluxograma das etapas;
Ferramentas utilizadas;
Glossário com siglas, caso necessário.

Conferência de uma estrutura que garanta a qualidade da operação - mesmo com a possível troca de funcionários - a regulamentação dos processos, aprofundamento de atividades e facilidade do acesso pelos colaboradores no dia a dia e em treinamentos;

Entregável de Valor: Manuais padronizados e validados, prontos para uso e disseminação interna.
Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 18 -->

Etapa 5 - Elaboração de Manuais

Entrega: POPS

Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 19 -->

Etapa 6 - Documentação Final
Objetivo Estratégico: consolidar todo o estudo e as entregas realizadas em um formato de fácil acesso e disseminação para a equipe da Ascenty.
Principais Atividades:

Estruturação de uma documentação executiva contendo as principais entregas e análises do projeto de forma enxuta;

Criação de um site específico e personalizado para uso interno da Ascenty contendo os documentos produzidos pela equipe da Poli Júnior e formatado de forma intuitiva para fácil usabilidade.

Entregável de Valor: documentação executiva e site personalizado para a Ascenty.
Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 20 -->

Etapa 6 - Documentação Final

Entrega: Repositório Online

Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 21 -->

Entregáveis do projeto

Etapa 1 - Imersão (Semana 1): Canvas de Escopo e Cronograma do projeto.

Etapa 2 - Mapeamento AS IS (Semanas 2-3): mapeamentos/fluxos construídos e validados pelos stakeholders.

Etapa 3 - Gargalos e soluções (Semanas 4-5): gargalos priorizados com Matriz GUT, soluções propostas com 5W2H, Diagrama de Solução, Initiative Charter e oportunidades de IA.

Etapa 4 - Mapeamento TO BE (Semana 6): mapeamentos TO BE redesenhados com correção de gaps e overlaps.

Etapa 5 - Manuais (Semana 7): POPs padronizados e validados, prontos para uso interno.

Etapa 6 - Documentação Final (Semana 7): documentação executiva e site personalizado.
Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 22 -->

Benefícios
Impacto

Dimensão
Cenário Atual
Cenário Futuro
Processos mapeados, documentados e padronizados, com maior clareza operacional, redução de dependência individual e ganho de escalabilidade na área.

Processos com diferentes formas de execução, presença de atividades repetitivas e pouca documentação formal para orientar a operação.

No case do Grupo EPR, a padronização da Governança de Inovação entre as áreas permitiu a escalabilidade e a potencialização estratégica do tópico.
Estruturação e Padronização de Processos

Conhecimento concentrado em colaboradores-chave, dificultando treinamentos, onboarding e manutenção do padrão de execução.

Manuais estruturados, facilitando consulta, treinamento e disseminação do conhecimento operacional.
Gestão do Conhecimento e Continuidade

No case da Eletromídia, a gestão de ativos foi analisada sobre perspectivas de padronização e redução de falhas recorrentes, o que gerou economia estimada anual de R$1,6M.
Gestão Empresarial e Consultoria - Poli Júnior

<!-- Slide number: 23 -->

Equipe Dedicada ao Projeto e Parceria
2 Consultores por 7 semanas
Graduandos Engenheiros Politécnicos da USP da área de Gestão Empresarial e Consultoria da Poli Júnior

1 Validador
Membro sênior de projetos da área na empresa
Como será nossa parceria?
Serão realizados reports semanais entre os stakeholders e a equipe para alinhamentos sobre os pontos de atuação e revisão dos resultados;
Os stakeholders colaboram facilitando os insumos necessários (como acesso a documentos e contatos) e com a validação das entregas;
Serão realizadas constantes consultas de experiência e satisfação no decorrer da execução e após sua implementação.
A Poli Júnior se propõe a realizar termos aditivos para contratação de serviços adicionais.

<!-- Slide number: 24 -->

Cases de Sucesso

<!-- Slide number: 25 -->
PROBLEMA
SOLUÇÃO
Datora Telecom

Gestão de Processos
O caminho que um pedido de venda da Datora percorria, poderia variar devido aos diferentes processos de captação do lead, sendo despadronizado. Além disso, o CRM próprio da empresa possuía etapas mal definidas e que levavam mais tempo do que deveriam, atrasando o processo de uma venda e gerando perdas monetárias.

Desenvolvimento de 23 Mapeamentos AS IS para entender de ponta a ponta todo o processo de vendas, desde a captação do lead até a ativação do serviço da Datora. Para solucionar os gargalos encontrados, foram elaborados Mapeamentos TO BE e soluções com impactos mensuráveis, capazes de reduzir o tempo e economizar dinheiro da empresa. Por último, foi desenvolvido um manual de uso do CRM, com a função de ensinar os funcionários da empresa como utilizá-lo.

IMPACTO

Além de promover uma padronização do processo e difundir o conhecimento entre as áreas, as melhorias propostas mostraram resultado ainda no decorrer do projeto. Uma mudança proposta a respeito de uma etapa do CRM, gerou em dois meses de projeto uma redução de 50% no tempo que essa tarefa era executada.

<!-- Slide number: 26 -->
PROBLEMA
SOLUÇÃO
Banco Pine

Gestão de Processos
Mapeamento e identificação de gargalos, alcançando algumas quick wins, como a automatização de
tarefas em planilhas e ajustes na comunicação entre as áreas. Por fim, documentação do fluxograma
realizado com mais de 120 funcionários (As Is) e modelo que deverá ser implementado (To Be).

Dificuldade na área de fechamento contábil por falta de padronização dos processos internos,
atividades manuais e falha de comunicação entre as áreas, causando reprocessamentos contábeis em grande escala e atrasos.

IMPACTO

Implementação de metodologias ágeis para a realização dos processos, proporcionando redução de aproximadamente 50% no tempo de execução dos processos de Fechamento Contábil.

<!-- Slide number: 27 -->

Proposta Comercial

EQUIPE
INVESTIMENTO
DURAÇÃO

2 Consultores
1 Validador

7 semanas
R$32.100,00
Cartão, boleto ou transferência. Parcelamento em até 3x.
Pagamento:

<!-- Slide number: 28 -->

Proposta Comercial

8% de desconto em caso de fechamento até 30/09

EQUIPE
INVESTIMENTO
DURAÇÃO

2 Consultores
1 Validador

7 semanas
R$29.532,00
Cartão, boleto ou transferência. Parcelamento em até 3x.
Pagamento:

<!-- Slide number: 29 -->

Esclarecimentos Comerciais
Nossa minuta padrão contratual - que engloba questões jurídicas como garantias, deveres e responsabilidades, entre outras informações - está disponível neste link.

O CNAE (Classificação Nacional de Atividades Econômicas) da Poli Júnior, a empresa júnior da Escola Politécnica da USP, é 7112-0/00 - Serviços de Engenharia. Essa classificação engloba atividades como consultoria, projetos e outros serviços relacionados à engenharia.

Pareceres: Nossa proposta está em conformidade com a legislação aplicável e nos comprometemos com a qualidade do projeto - assim como para todos nossos clientes. Estamos disponíveis para tiragens de dúvidas durante todo o contato (dados ao final do documento).

Em caso de necessidade de números de contas bancárias, estatuto social, cartão CNPJ, Inscrição Municipal ou outras questões, entrar em contato.

Nosso valor engloba todos os custos estabelecidos pelo projeto, incluindo impostos.

<!-- Slide number: 30 -->

Esclarecimentos Comerciais
Para esta proposta comercial, são válidas as seguintes condições:

No decorrer do projeto, serão realizadas reuniões entre a equipe da Poli Júnior e o cliente para coleta de dados, discussão do andamento do projeto e apresentação de resultados – o cliente se compromete em ter disponibilidade para tais encontros e troca de informações;
As atividades têm início e fim a partir das datas que serão estabelecidas no contrato, documento elaborado mediante a aprovação desta proposta por ambas as partes, Poli Júnior e cliente;
As informações contidas nesta proposta são confidenciais, não devendo ser utilizadas ou apresentadas por qualquer outra pessoa sem o consentimento de ambas as partes;
A equipe da Poli Júnior não trabalhará durante as semanas de prova da Escola Politécnica;
Essa proposta comercial possui validade de 1 mês a contar da data de sua apresentação 04/09/2026;
O projeto poderá ser iniciado 15 dias úteis após a assinatura do contrato;
A contratante deve agir com respeito a todos os envolvidos no serviço em questão, sob pena de rescisão do contrato;
Serão realizadas coletas de satisfação em relação ao projeto no decorrer da execução e ao final do projeto;
No caso de atraso no pagamento de até 10 dias úteis, o projeto será congelado, com retomada prevista em até 5 dias úteis após o devido pagamento ter sido realizado.

<!-- Slide number: 31 -->

Nosso Contato e Próximos Passos

Gabriel Beyruti

Arthur Henri Nascimento Albino

Consultor de Negócios

Coordenador de Negócios

gabriel.beyruti@polijunior.com.br

arthur.albino@polijunior.com.br

11 97561-6380

71 98335-6880

Próximos Passos:
Aprovação Verbal até data estipulada
Validação jurídica da minuta contratual
Assinatura do contrato pelos representantes

