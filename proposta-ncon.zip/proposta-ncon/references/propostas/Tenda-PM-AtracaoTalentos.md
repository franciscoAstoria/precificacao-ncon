<!-- Slide number: 1 -->

Posicionamento do meio universitário e atração de talentos com Pesquisa de Mercado

Proposta de Parceria
27 de Julho, 2026

![](GoogleShape101p13.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 2 -->

Poli Júnior - Empresa Júnior da Escola Politécnica da USP

A Poli Júnior é uma instituição constituída por alunos de Graduação da Escola Politécnica de Engenharia da USP.

Localizados na melhor faculdade de engenharia da América Latina, seu projeto é impulsionado pelo mais alto rigor e talentos da Escola Politécnica, garantindo o que há de mais inovador em tecnologias, resultando em soluções ágeis e criativas. Além disso, criando uma forte conexão da empresa com a POLI-USP.

Nossa excelência e agilidade é refinada por treinamentos e parcerias com as maiores consultorias do mundo visando aplicar o mesmo padrão de excelência e pensamento estratégico em nossos projetos.

1º
+1100
90%
lugar
entre as Empresas Juniores do Brasil
Projetos concluídos
Índice de Satisfação
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 3 -->

Quem conta com as soluções da Poli Júnior

![](GoogleShape171p15.jpg)

### Notes:

<!-- Slide number: 4 -->

![](GoogleShape201p16.jpg)

Sumário - Nosso Entendimento do Seu Contexto e Objetivos
Uma proposta para a rodagem de pesquisa de atratividade

Recomendamos a rodagem do questionário com os estudantes das faculdades-alvo e a análise da percepção da marca empregadora, visando direcionar planos de ação de atração alinhados aos direcionamentos trazidos pelas percepções dos alunos.

Contexto:
A Construtora Tenda possui um modelo de contratação que valoriza a formação de jovens talentos: o programa de estágio é a principal porta de entrada da companhia, com mais de 80% da liderança de obras formada internamente e um ciclo de desenvolvimento de profissionais que leva estagiários à gestão de obras em poucos anos. Por conta do modelo construtivo próprio da Tenda, a formação interna é determinante: quando a atração de estagiários não acontece, a alternativa de buscar profissionais prontos no mercado não atende às particularidades da operação.
Apesar disso, a companhia enfrenta um desafio crescente de atração junto aos estudantes universitários, intensificado pela redução no volume de alunos de engenharia no país e pela necessidade de fortalecer sua presença nas universidades estratégicas de São Paulo, como a Escola Politécnica, a FAU e a FEA-USP, onde a concorrência por talentos com empresas de outros setores é intensa. Esse cenário acaba por reduzir a visibilidade da Tenda e o interesse dos alunos em considerá-la como uma opção de carreira, tornando essencial compreender de forma estruturada a percepção dos estudantes sobre a marca, seus fatores de atração e os canais mais relevantes de aproximação com esse público.

Entregas frequentes que geram valor rápido
Conexão com a USP e talentos da Escola Politécnica

Projetos que integram dados e estratégia à sua empresa
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 5 -->

![](GoogleShape227p17.jpg)

Principais desafios da Construtora Tenda

Objetivos:
Compreender a percepção de estudantes universitários sobre a Tenda como empregadora, identificando o nível de conhecimento da marca e como a empresa é vista por alunos da Escola Politécnica, da FAU e da FEA-USP, além de expandir esse conhecimento.

"Tem sido desafiador atrair estudantes de engenharia, o volume de alunos nos cursos vem caindo"
Entender os fatores que mais atraem e mais afastam jovens na busca por estágios e primeiras experiências profissionais, como expectativas de carreira, ambiente de trabalho e oportunidades de desenvolvimento.

Aplicar questionários e analisar os dados obtidos, identificando padrões de interesse e oportunidades para aumentar a visibilidade da Tenda e fortalecer sua atratividade entre estudantes.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 6 -->

Cronograma do projeto

FASE 2: Iniciar Desenvolvimento Iterativo de Automações
Imersão no contexto
Elaboração do questionário
Rodagem do questionário
Análise das respostas
Planos de
Ação
Documentação final

Entrega 3
Entrega 1
Entrega 4
Entrega 2
Semana 1
Semanas 2-4
Semanas 5
Semana 6

Coleta das respostas a partir dos filtros especificados para a pesquisa.

Examinar as respostas e montar uma Dashboard para compreensão dos dados.

Estruturar planos de ação para decisões estratégicas alinhadas ao contexto.

Consolidação de todas as análises e entregas.

Traçar os primeiros passos do projeto e realizar os alinhamentos iniciais.

Definição das perguntas e validação com os stakeholders.

### Notes:

<!-- Slide number: 7 -->

Etapa 1 - Imersão no contexto
Objetivo Estratégico: alinhar os principais pontos do projeto, garantindo conformidade entre as equipes da Construtora Tenda e da Poli Júnior.
Principais Atividades:

Realização do kick-off: definição dos pontos focais do projeto e dos alinhamentos iniciais com a equipe da Construtora Tenda;

Brainstorm sobre os pontos essenciais a serem investigados na pesquisa, possibilitando a construção de uma Matriz CSD acerca do público a ser analisado:
Levantamento das certezas, suposições e dúvidas da equipe da Tenda sobre como os estudantes enxergam a marca hoje;
Validação posterior dessas hipóteses com as respostas do questionário.

Entregável de Valor:  Matriz CSD, Canvas de Escopo e Cronograma do projeto.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 8 -->

Etapa 1 - Imersão no contexto

Brainstorm: Pontos de atenção elencados

![](GoogleShape317p20.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 9 -->

Etapa 2 - Elaboração do Questionário
Objetivo Estratégico: construção do questionário com as perguntas essenciais para o mapeamento da percepção e critérios de decisão dos alunos
Principais Atividades:

Construção das perguntas estratégicas alinhadas aos objetivos e aos critérios;

Perfil de 160 respondentes para o questionário:
40 alunos de Engenharia da Escola Politécnica da USP
40 alunos de Economia e 40 de Administração da Faculdade de Economia e Administração da USP
40 alunos de Arquitetura da Faculdade de Arquitetura e Urbanismo da USP
Elaboração de um questionário com perguntas estratégicas a ser rodado com os alunos a fim de entender os critérios de decisão na escolha de uma vaga de trabalho, suas preferências e barreiras, traçando o ICP e levantando a melhor forma de atrair mais talentos

Entregável de Valor:  Questionário construído e validado pelos stakeholders.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 10 -->

Etapa 2 - Elaboração do Questionário

Exemplo: Fluxograma do questionário

![](GoogleShape352p22.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 11 -->

Etapa 3 - Rodagem do questionário
Objetivo Estratégico: rodagem do questionário elaborado na etapa anterior para entender as barreiras de entrada, os pontos de atração e canais de entrada para as vagas de emprego.
Principais Atividades:

Pontos a serem mapeados durante a rodagem:
Critérios de decisão;
Modalidades e benefícios;
Caracteristicas do público-alvo;
Preferências do modelo de vaga oferecida;
Como gerar interesse neles e divulgações efetivas de outras empresas.

Posicionar a Construtora Tenda como uma referência atrativa entre jovens formandos, ampliando seu reconhecimento e fortalecendo sua percepção como empregadora de destaque.

Entregável de Valor:  Base de respostas dos 160 alunos.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 12 -->

Etapa 4 - Análise das Respostas
Objetivo Estratégico: transformar os dados coletados em insights estratégicos e indicadores estruturados em painéis interativos.
Principais Atividades:

Elaboração de uma Dashboard para reunir as informações relevantes sobre o questionário e seus outputs, sendo possível:
Tratamento estatístico das respostas obtidas;
Cruzamentos entre a satisfação e as percepções sobre a Construtora Tenda e sobre vagas de emprego.
Entendimento das oportunidades para inovação nas vagas oferecidas;
Desenvolvimento de dashboard interativa para visualização dos dados.

Consolidação e análise das respostas obtidas no questionário, entendendo as preferências e expectativas dos alunos em uma vaga de emprego, e das entrevistas, mapeando oportunidades de parceria para disseminar a marca.

Entregável de Valor: painel analítico interativo e base estruturada para análise das respostas.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 13 -->

Etapa 4 - Análise das Respostas

Exemplo: Dashboard Ilustrativa

![](GoogleShape404p25.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 14 -->

Etapa 5 - Planos de Ação
Objetivo Estratégico: converter os insights obtidos na pesquisa quantitativa em ações estratégicas qualitativas para o devido direcionamento da Construtora Tenda.
Principais Atividades:

Definição de direcionamentos estratégicos com base nos principais insights obtidos durante a análise das respostas, buscando planos de ações para melhor posicionamento de Construtora Tenda e atração dos alunos;

Elaboração de uma Matriz SWOT e SWOT Cruzada, identificando pontos fortes, fraquezas, oportunidades e ameaças para a Construtora Tenda:
SWOT: ferramenta para mapear fatores internos e externos e apoiar a tomada de decisão;
SWOT Cruzada: utilizada para delimitar a correlação entre aspectos internos e externos, potencializando forças, aproveitando oportunidades, neutralizando ameaças e corrigindo fraquezas;

Entregável de Valor: Direcionamentos estratégicos consolidados em matrizes objetivas.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 15 -->

Etapa 5 - Planos de Ação

Exemplo: SWOT Cruzada

![](GoogleShape437p27.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 16 -->

Etapa 6 - Documentação Final
Objetivo Estratégico: consolidar todo o estudo e as entregas realizadas em um formato de fácil acesso e disseminação para a equipe da Construtora Tenda.
Principais Atividades:

Criação de um site específico e personalizado para uso interno da Construtora Tenda contendo os documentos produzidos pela equipe da Poli Júnior e formatado de forma intuitiva para fácil usabilidade.

Elaboração de um relatório com todos os dados coletados ao longo da rodagem e as análises feitas em relação aos diferenciais e às percepções, trazendo os principais insights e direcionamentos.

Entregável de Valor: site personalizado para a Construtora Tenda e relatório completo com as análises consolidadas.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 17 -->

Etapa 6 - Documentação Final

Entrega: Repositório Online

![](GoogleShape471p29.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 18 -->

Entregas Principais

![](GoogleShape488p30.jpg)

![](GoogleShape489p30.jpg)
Documentação final do projeto, consolidando os principais insights, cruzamentos relevantes e direcionamentos estratégicos.
Análise estruturada das tendências do mercado, identificando oportunidades para melhor posicionamento da empresa entre os jovens;
Geração de insights estratégicos a partir das perguntas elaboradas, permitindo compreender os critérios de decisão dos alunos por meio de gráficos e Dashboard.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 19 -->

![](GoogleShape511p31.jpg)

Equipe Dedicada ao Projeto e Parceria
2 Consultores por 6 semanas
Graduandos Engenheiros Politécnicos da USP da área de Gestão Empresarial e Consultoria da Poli Júnior

1 Coordenador
Membro sênior de projetos da área na empresa
Como será nossa parceria?
Serão realizados reports semanais entre os stakeholders e a equipe para alinhamentos sobre os pontos de atuação e revisão dos resultados;
Os stakeholders colaboram facilitando os insumos necessários (como acesso a documentos e contatos) e com a validação das entregas;
Serão realizadas constantes consultas de experiência e satisfação no decorrer da execução e após sua implementação.
A Poli Júnior se propõe a realizar termos aditivos para contratação de serviços adicionais.

### Notes:

<!-- Slide number: 20 -->

Cases de Sucesso

![](GoogleShape522p32.jpg)

### Notes:

<!-- Slide number: 21 -->
Mitt Incorporadora
PROBLEMA
SOLUÇÃO
Pesquisa de Mercado

A equipe realizou um estudo mercadológico e territorial completo, englobando análises socioeconômicas, levantamento de concorrentes e pesquisa quantitativa com moradores da região. A partir dos dados coletados, foram desenvolvidos mapas de calor, análises comparativas e planos de ação estratégicos, indicando as áreas de maior potencial de valorização e os perfis prioritários de clientes.
A empresa buscava analisar o potencial do mercado imobiliário em uma cidade no interior de Minas Gerais, visando compreender o perfil do público e os fatores decisivos na compra de imóveis. Era necessário um mapeamento detalhado da demanda local, identificação de tendências, estudo de concorrência e avaliação das melhores oportunidades de posicionamento estratégico para um novo empreendimento.

![](GoogleShape564p33.jpg)

IMPACTO

O projeto forneceu à empresa uma base sólida para a tomada de decisão sobre o novo empreendimento, com insights sobre público, localização e demanda. As análises apontaram as regiões mais promissoras e o ticket médio ideal, permitindo definir o posicionamento de mercado e estratégias comerciais mais assertivas, reduzindo riscos e otimizando investimentos futuros.

### Notes:

<!-- Slide number: 22 -->

Proposta Comercial

![](GoogleShape601p34.jpg)

EQUIPE
DURAÇÃO
INVESTIMENTO

2 Consultores
1 Coordenador

6 semanas
R$24.100,00

### Notes:

<!-- Slide number: 23 -->

![](GoogleShape612p35.jpg)

Esclarecimentos Comerciais
Nossa minuta padrão contratual - que engloba questões jurídicas como garantias, deveres e responsabilidades, entre outras informações - está disponível neste link.

O CNAE (Classificação Nacional de Atividades Econômicas) da Poli Júnior, a empresa júnior da Escola Politécnica da USP, é 7112-0/00 - Serviços de Engenharia. Essa classificação engloba atividades como consultoria, projetos e outros serviços relacionados à engenharia.

Pareceres: Nossa proposta está em conformidade com a legislação aplicável e nos comprometemos com a qualidade do projeto - assim como para todos nossos clientes. Estamos disponíveis para tiragens de dúvidas durante todo o contato (dados ao final do documento).

Em caso de necessidade de números de contas bancárias, estatuto social, cartão CNPJ, Inscrição Municipal ou outras questões, entrar em contato.

Nosso valor engloba todos os custos estabelecidos pelo projeto, incluindo impostos.

### Notes:

<!-- Slide number: 24 -->

![](GoogleShape624p36.jpg)

Esclarecimentos Comerciais
Para esta proposta comercial, são válidas as seguintes condições:

No decorrer do projeto, serão realizadas reuniões entre a equipe da Poli Júnior e o cliente para coleta de dados, discussão do andamento do projeto e apresentação de resultados – o cliente se compromete em ter disponibilidade para tais encontros e troca de informações;
As atividades têm início e fim a partir das datas que serão estabelecidas no contrato, documento elaborado mediante a aprovação desta proposta por ambas as partes, Poli Júnior e cliente;
As informações contidas nesta proposta são confidenciais, não devendo ser utilizadas ou apresentadas por qualquer outra pessoa sem o consentimento de ambas as partes;
A equipe da Poli Júnior não trabalhará durante as semanas de prova da Escola Politécnica;
Essa proposta comercial possui validade de 1 mês a contar da data de sua apresentação 27/07/2026;
O projeto poderá ser iniciado 15 dias úteis após a assinatura do contrato;
A contratante deve agir com respeito a todos os envolvidos no serviço em questão, sob pena de rescisão do contrato;
Serão realizadas coletas de satisfação em relação ao projeto no decorrer da execução e ao final do projeto;
No caso de atraso no pagamento de até 10 dias úteis, o projeto será congelado, com retomada prevista em até 5 dias úteis após o devido pagamento ter sido realizado.

### Notes:

<!-- Slide number: 25 -->

![](GoogleShape682p37.jpg)

Nosso Contato e Próximos Passos

Gabriel Beyruti

João Lucas Castanheira

Coordenador de Negócios
Consultor de negócios

gabriel.beyruti@polijunior.com.br

Joao.castanheira@polijunior.com.br

11 97561-6380

62 99802-2007

Próximos Passos:
Aprovação Verbal até data estipulada
Validação jurídica da minuta contratual
Assinatura do contrato pelos representantes

### Notes:
