<!-- Slide number: 1 -->

Centralização e redesenho dos processos de Consórcio para a migração ao Salesforce

Proposta de Parceria
15 de Julho, 2026

![](GoogleShape67p13.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 2 -->

Poli Júnior - Empresa Júnior da Escola Politécnica da USP

A Poli Júnior é uma instituição constituída por alunos de Graduação da Escola Politécnica de Engenharia da USP.

Localizados na melhor faculdade de engenharia da América Latina, seu projeto é impulsionado pelo mais alto rigor e talentos da Escola Politécnica, garantindo o que há de mais inovador em tecnologias, resultando em soluções ágeis e criativas. Além disso, criando uma forte conexão da empresa com a POLI-USP.

Nossa excelência e agilidade é refinada por treinamentos e parcerias com as maiores consultorias do mundo visando aplicar o mesmo padrão de excelência e pensamento estratégico em nossos projetos.

1º
+1100
90%
lugar
entre as Empresas Juniores do Brasil
Projetos concluídos
Índice de Satisfação
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 3 -->

Quem conta com as soluções da Poli Júnior

![](GoogleShape137p15.jpg)

### Notes:

<!-- Slide number: 4 -->

![](GoogleShape166p16.jpg)

Sumário - Nosso Entendimento do Seu Contexto e Objetivos

Recomendamos a padronização e o redesenho dos processos da operação de Consórcio, partindo da imersão e do Mapeamento AS IS para a construção do TO BE orientado à migração ao Salesforce, consolidando os fluxos em Full Vision com detalhamento de campos e documentação final.
Contexto:
A área de Consórcio é uma das mais novas operações do QuintoAndar. Criada em agosto de 2025 com alta autonomia, montou seu CRM no HubSpot, com diversas construções customizadas, e usa o Blip na comunicação com clientes, fora dos sistemas principais da companhia. A operação conta hoje com cerca de 25 membros entre analistas de vendas, supervisores e representantes de qualidade, conduzindo a jornada do cliente até a venda do consórcio.
Com o crescimento da operação, percebe-se a oportunidade de, por meio da devida utilização do Salesforce, construir um modelo de gestão mais efetivo, com foco em padronização, visibilidade e controle dos processos desenvolvidos desde a criação. Assim, a estruturação na nova ferramenta busca reduzir as personalizações e especificidades individuais, além de viabilizar um processo estruturado o suficiente para permitir escala e sustentabilidade na operação da área.

Entregas frequentes que geram valor rápido
Conexão com a USP e talentos da Escola Politécnica

Projetos que integram otimização e tecnologias inovadoras à sua empresa
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 5 -->

![](GoogleShape192p17.jpg)

Principais objetivos do QuintoAndar

Objetivos:

"Estamos em um momento em que faz sentido construir para durar"
Mapear os processos atuais (AS IS) da operação de Consórcio no HubSpot e no Blip, incluindo os fluxos de vendas, carteirização e qualidade;

Redesenhar os fluxos de forma padronizada e otimizada (TO BE), já orientados à estrutura e às funcionalidades do Salesforce;
Desenvolver os Full Visions de cada processo, com detalhamento de campos e atividades, consolidando a documentação que servirá de base para a migração.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 6 -->

Cronograma do projeto
Mapeamento
TO BE
Mapeamento
AS IS
Imersão no contexto
Full Vision e Documentação Final

Entrega 4
Entrega 3
Entrega 2
Entrega 1
Semana 6
Semanas 4-5
Semanas 2-3
Semana 1

Entender a estrutura da operação de Consórcio, mapear stakeholders e sistemas (HubSpot e Blip), definir os processos prioritários e agendar as reuniões.

Mapear os fluxos atuais dos processos priorizados a partir das entrevistas com os times indicados pela liderança de Inside Sales.

Construção dos Full Visions com detalhamento de campos de cada processo e consolidação da documentação final do projeto.

Redesenho dos processos em sua forma padronizada e otimizada, já orientados à estrutura do Salesforce.

### Notes:

<!-- Slide number: 7 -->

Etapa 1 - Imersão no contexto
Objetivo Estratégico: alinhar os principais pontos do projeto e entender a estrutura da operação de Consórcio, garantindo conformidade entre as equipes do QuintoAndar e da Poli Júnior.
Principais Atividades:

Realização do kick-off com a equipe do QuintoAndar: definição dos pontos focais, expectativas e alinhamentos iniciais;

Entendimento da estrutura da área, identificando responsáveis, sistemas utilizados (HubSpot e Blip) e documentações existentes, como o material de macroprocessos já elaborado pela equipe;

Definição, junto à liderança de Inside Sales, dos colaboradores-chave para as entrevistas e agendamento das reuniões de mapeamento e dos reports semanais.

Entregável de Valor:  elaboração do Canvas de Escopo e Cronograma do projeto.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 8 -->

Etapa 2 - Mapeamento AS-IS dos processos
Objetivo Estratégico: construir os fluxogramas dos processos atuais da operação de Consórcio, que servirão de base para a padronização e o redesenho orientado ao Salesforce.
Principais Atividades:

Realização de entrevistas com responsáveis e envolvidos nos processos:
Reuniões de mapeamento com os colaboradores-chave dos processos priorizados, incluindo vendas, carteirização e qualidade;
Limitado a 20 reuniões de mapeamento de 1 hora cada.

Entendimento do fluxograma (mapeamento e modelagem AS IS):
Atividades e atores que participam dos processos da área;
Identificação das construções customizadas no HubSpot e das etapas manuais;
Comunicação entre áreas, fontes de dados e canais de informação;

Entregável de Valor:  Fluxos construídos e validados pelos stakeholders.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 9 -->

Etapa 2 - Mapeamento AS-IS dos processos

VALIDAÇÃO
MAPEAMENTO
Validar o mapeamento de um processo com os gestores da área garante maior assertividade nas análises e documentação.
O mapeamento permite a consolidação de processos e análise mais assertiva da execução das atividades do dia a dia da empresa.

FERRAMENTA UTILIZADA

Já utilizamos plataformas como Bizagi Modeler, Figma e Lucid Chart para a construção dos fluxogramas, permitindo a edição e facilidade de acesso, o que, por sua vez, permite a manutenção dos fluxos.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 10 -->

Etapa 3 - Mapeamento TO BE
Objetivo Estratégico: garantir padronização e maturidade operacional por meio do redesenho dos processos futuros (TO BE), já estruturados para a migração da operação ao Salesforce.
Principais Atividades:

Estruturação dos novos processos (modelagem TO-BE):
Construção dos processos ideais visando padronização e clareza, substituindo as construções customizadas do HubSpot por fluxos estruturados no padrão Salesforce;
Redesenho dos fluxos de carteirização e qualidade, tornando-os mais inteligentes e transparentes;
Definição das informações e análises que a operação passará a consumir a partir do Salesforce.

Garantir uma execução mais consistente, reduzindo a dependência do conhecimento individual e padronizando o método de trabalho entre os analistas.

Entregável de Valor: novos mapeamentos com a correção dos principais gaps, prontos para orientar a migração ao Salesforce.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 11 -->

Etapa 3 - Mapeamento TO BE

Entrega: Fluxos redesenhados

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 12 -->

Etapa 4 - Full Vision e Documentação Final
Objetivo Estratégico: consolidar os processos redesenhados em documentação completa e detalhada, no mesmo modelo já utilizado na parceria anterior com o QuintoAndar.

Principais Atividades:

Construção do Full Vision de cada processo:
Visão geral da operação: escopo da área, volume de demandas, quantidade de analistas e supervisores;
Visão geral do fluxo: mapeamento macro do processo, evidenciando como o fluxo deve ser conduzido dentro e fora do sistema e seus prazos;
Passo a passo das ações do analista, do recebimento da demanda ao encerramento do caso, com o detalhamento dos campos e sistemas de cada etapa;
Comunicações: canais utilizados, remetentes, destinatários e o que é automatizado.

Conferência de uma estrutura personalizada pelo QuintoAndar que esteja padronizada com a do seu sistema interno;

Entregável de Valor: Full Visions completos com detalhamento de campos

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 13 -->

Etapa 4 - Full Vision e Documentação Final

Entrega: Full Vision

![](GoogleShape368p25.jpg)

![](GoogleShape366p25.jpg)

![](GoogleShape367p25.jpg)

![](GoogleShape369p25.jpg)

![](GoogleShape370p25.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 14 -->

Etapa 4 - Full Vision e Documentação Final

Objetivo Estratégico: Consolidar todo o estudo e as entregas realizadas em um formato de fácil acesso e disseminação para a equipe do QuintoAndar.
Principais Atividades:

Estruturação de uma documentação executiva contendo as principais entregas e análises do projeto de forma enxuta;

Criação de um site específico e personalizado para uso interno do QuintoAndar contendo os documentos produzidos pela equipe da Poli Júnior e formatado de forma intuitiva para fácil usabilidade.

Entregável de Valor: documentação executiva e site personalizado para o QuintoAndar
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 15 -->

Etapa 4 - Full Vision e Documentação Final

Entrega: Repositório Online

![](GoogleShape403p27.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 16 -->

![](GoogleShape426p28.jpg)

Equipe Dedicada ao Projeto e Parceria
3 Consultores por 6 semanas
Graduandos Engenheiros Politécnicos da USP da área de Gestão Empresarial e Consultoria da Poli Júnior
1 Coordenador
Membro sênior de projetos da área na empresa
Como será nossa parceria?
Serão realizados reports semanais entre os stakeholders e a equipe para alinhamentos sobre os pontos de atuação e revisão dos resultados;
Os stakeholders colaboram facilitando os insumos necessários (como acesso a documentos e contatos) e com a validação das entregas;
Serão realizadas constantes consultas de experiência e satisfação no decorrer da execução e após sua implementação.
A Poli Júnior se propõe a realizar termos aditivos para contratação de serviços adicionais.

### Notes:

<!-- Slide number: 17 -->

Cases de Sucesso

![](GoogleShape437p29.jpg)

### Notes:

<!-- Slide number: 18 -->
Banco Pine
PROBLEMA
SOLUÇÃO
Gestão de Processos

Mapeamento e identificação de gargalos, alcançando algumas quick wins, como a automatização de
tarefas em planilhas e ajustes na comunicação entre as áreas. Por fim, documentação do fluxograma
realizado com mais de 120 funcionários (As Is) e modelo que deverá ser implementado (To Be).

Dificuldade na área de fechamento contábil por falta de padronização dos processos internos,
atividades manuais e falha de comunicação entre as áreas, causando reprocessamentos contábeis em grande escala e atrasos.
IMPACTO

Implementação de metodologias ágeis para a realização dos processos, proporcionando redução de aproximadamente 50% no tempo de execução dos processos de Fechamento Contábil.

### Notes:

<!-- Slide number: 19 -->

![](GoogleShape517p31.jpg)

Proposta Comercial

![](GoogleShape516p31.jpg)

EQUIPE
DURAÇÃO
INVESTIMENTO

3 Consultores
1 Coordenador

6 semanas
R$34.155,00
Pagamento: Cartão, Boleto ou Transferência | Em até 3x com parcelas a serem pagas nos Dia 10, 20 ou 30 do mês

### Notes:

<!-- Slide number: 20 -->

![](GoogleShape528p32.jpg)

Esclarecimentos Comerciais
Nossa minuta padrão contratual - que engloba questões jurídicas como garantias, deveres e responsabilidades, entre outras informações - está disponível neste link.

O CNAE (Classificação Nacional de Atividades Econômicas) da Poli Júnior, a empresa júnior da Escola Politécnica da USP, é 7112-0/00 - Serviços de Engenharia. Essa classificação engloba atividades como consultoria, projetos e outros serviços relacionados à engenharia.

Pareceres: Nossa proposta está em conformidade com a legislação aplicável e nos comprometemos com a qualidade do projeto - assim como para todos nossos clientes. Estamos disponíveis para tiragens de dúvidas durante todo o contato (dados ao final do documento).

Em caso de necessidade de números de contas bancárias, estatuto social, cartão CNPJ, Inscrição Municipal ou outras questões, entrar em contato.

Nosso valor engloba todos os custos estabelecidos pelo projeto, incluindo impostos.

### Notes:

<!-- Slide number: 21 -->

![](GoogleShape540p33.jpg)

Esclarecimentos Comerciais
Para esta proposta comercial, são válidas as seguintes condições:

No decorrer do projeto, serão realizadas reuniões entre a equipe da Poli Júnior e o cliente para coleta de dados, discussão do andamento do projeto e apresentação de resultados – o cliente se compromete em ter disponibilidade para tais encontros e troca de informações;
As atividades têm início e fim a partir das datas que serão estabelecidas no contrato, documento elaborado mediante a aprovação desta proposta por ambas as partes, Poli Júnior e cliente;
As informações contidas nesta proposta são confidenciais, não devendo ser utilizadas ou apresentadas por qualquer outra pessoa sem o consentimento de ambas as partes;
A equipe da Poli Júnior não trabalhará durante as semanas de prova da Escola Politécnica;
Essa proposta comercial possui validade de 1 mês a contar da data de sua apresentação 15/07/2026;
O projeto poderá ser iniciado 15 dias úteis após a assinatura do contrato;
A contratante deve agir com respeito a todos os envolvidos no serviço em questão, sob pena de rescisão do contrato;
Serão realizadas coletas de satisfação em relação ao projeto no decorrer da execução e ao final do projeto;
No caso de atraso no pagamento de até 10 dias úteis, o projeto será congelado, com retomada prevista em até 5 dias úteis após o devido pagamento ter sido realizado.

### Notes:

<!-- Slide number: 22 -->

![](GoogleShape598p34.jpg)

Nosso Contato e Próximos Passos

Gabriel Beyruti

Rafael Brandão

Coordenador de Negócios
Gerente Comercial

gabriel.beyruti@polijunior.com.br

rafael.brandao@polijunior.com.br

11 97561-6380

82 9115-6730

Próximos Passos:
Aprovação Verbal
Validação jurídica da minuta contratual
Assinatura do contrato pelos representantes

### Notes:
