<!-- Slide number: 1 -->

Estruturação do plano de expansão para a área de Energia da FS

Proposta de Parceria
16 de Julho, 2026

![](GoogleShape176p25.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 2 -->

Poli Júnior - Empresa Júnior da Escola Politécnica da USP

A Poli Júnior é uma instituição constituída por alunos de Graduação da Escola Politécnica de Engenharia da USP.

Localizados na melhor faculdade de engenharia da América Latina, seu projeto é impulsionado pelo mais alto rigor e talentos da Escola Politécnica, garantindo o que há de mais inovador em tecnologias, resultando em soluções ágeis e criativas. Além disso, criando uma forte conexão da empresa com a POLI-USP.

Nossa excelência e agilidade é refinada por treinamentos e parcerias com as maiores consultorias do mundo visando aplicar o mesmo padrão de excelência e pensamento estratégico em nossos projetos.

1º
+1100
90%
lugar
entre as Empresas Juniores do Brasil
Projetos concluídos
Índice de Satisfação
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 3 -->

Quem conta com as soluções da Poli Júnior

![](GoogleShape246p27.jpg)

### Notes:

<!-- Slide number: 4 -->

![](GoogleShape276p28.jpg)

Sumário - Nosso Entendimento do Seu Contexto e Objetivos
Uma Proposta para estruturar a área de Energia da FS e embasar sua expansão.

Recomendamos o mapeamento da estrutura atual e o desenho de uma estrutura-alvo com plano de expansão, visando dar à área de Energia a organização e a visibilidade à altura da sua importância para a empresa.
Contexto:
A área de Energia da FS vive um momento de crescimento e de afirmação do seu papel estratégico dentro da empresa. Responsável por toda a estratégia de comercialização do excedente das plantas no mercado livre, do "quando vender" à execução e ao controle de risco, fluxo de caixa e booking, a área foi estruturada de forma sólida ao longo do último ano e meio, com processos bem alinhados e forte uso de tecnologia. Com a empresa em expansão e novas unidades entrando em operação, a área tende a crescer em escala e complexidade, o que torna cada vez mais valioso contar com uma organização à altura da sua importância: responsabilidades bem distribuídas, uma função de inteligência regulatória estruturada e visibilidade sobre tudo o que a área sustenta. É nesse contexto que a Poli Júnior atua como um braço de estruturação da FS, organizando os meios para que a área de Energia cresça de forma sustentável e tenha seu valor reconhecido por toda a empresa.

Entregas frequentes que geram valor rápido
Conexão com a USP e talentos da Escola Politécnica

Projetos que integram otimização e tecnologias inovadoras à sua empresa
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 5 -->

![](GoogleShape304p29.jpg)

Principais objetivos da FS

Objetivos:
Dar visibilidade à estrutura e às responsabilidades da área de Energia, mapeando tudo o que ela executa, decide e sustenta hoje, dentro e fora da equipe.

"As decisões da área movem muito dinheiro - ela precisa crescer junto com a empresa."
Trazer referências externas de mercado sobre como áreas de energia de players do setor se estruturam, embasando as decisões de estrutura com práticas e papéis consolidados.

Embasar a expansão da área com uma estrutura-alvo clara, definindo os papéis e a divisão de responsabilidades necessários para que a operação acompanhe o crescimento da empresa e a entrada de novas unidades.

Estruturar a função de inteligência regulatória, dando a ela responsável, cadência e fluxo de decisão definidos, de forma que esse acompanhamento ganhe escala junto com a área.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 6 -->

Cronograma do projeto - Consultoria

Imersão no contexto e Diagnóstico de Maturidade
Papéis e Responsabilidades
Benchmark de Práticas e Estrutura
Documentação Final
Plano de Expansão
Reuniões e Ritos

Entrega 1
Entrega 2
Entrega 3
Entrega 4
Entrega 6
Entrega 5
Semanas 2-3
Semana 4
Semana 1
Semana 6
Semana 5
Semana 7

Desenhar a estrutura-alvo, com papéis e responsabilidades claros para o crescimento.

Levantar como áreas de energia de referência se estruturam em papéis e práticas.

Entender a estrutura, as atividades e o contexto regulatório da área e consolidar o retrato atual do seu funcionamento

Consolidar o plano e o business case que embasam a expansão da área.

Consolidar todas as análises e entregas do projeto em formato de fácil acesso.

Estruturar os ritos de decisão e o fluxo da função regulatória da área-alvo.

### Notes:

<!-- Slide number: 7 -->

Etapa 1.1 - Imersão e Diagnóstico
Objetivo Estratégico: compreender como o valor é gerado ao longo da operação da área de Energia e mapear o contexto regulatório que sustenta suas decisões.
Principais Atividades: Cadeia de Valor

Entrevistas com o gestor e o time para levantar as atividades da área e como cada uma gera valor (do "quando vender" à execução, controle de risco, fluxo de caixa e booking);

Organização das atividades nas etapas correspondentes da cadeia de valor;

Levantamento do panorama regulatório que impacta a área: fontes acompanhadas (ANEEL, MME, CCEE), tipos de ato e como influenciam as decisões da mesa;

Entregável de Valor: cadeia de valor preenchida e panorama regulatório mapeado, ilustrando como o valor é gerado e o que sustenta as decisões da área.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 8 -->

Etapa 1.2 - Imersão e Diagnóstico

Objetivo Estratégico: mapear a estrutura atual da área, evidenciando papéis, hierarquias e o que é executado internamente ou por terceiros.
Principais Atividades: Organograma AS IS

Reuniões para levantamento da estrutura organizacional atual;

Elaboração do organograma AS IS no Lucidspark, destacando cargos, hierarquias e as funções prestadas por serviços externos;

Entregável de Valor: organograma AS IS estruturado, refletindo a estrutura real da área, incluindo o que é interno e o que é terceirizado.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 9 -->

Etapa 1.3 - Imersão e Diagnóstico
Objetivo Estratégico: retratar o cenário atual da área, mapeando como estrutura, responsabilidades, ritos e operação funcionam hoje, para servir de base ao desenho da estrutura-alvo.
Principais Atividades: Matriz Diagnóstico AS IS

Condução de reuniões com o gestor para mapear o cenário AS IS dos principais aspectos da área (estrutura, responsabilidades, ritos e operação);

Consolidação das informações na Matriz Diagnóstico AS IS, estruturada por dimensão;

Identificação dos principais pontos de atenção que emergem do crescimento orgânico da área;

Entregável de Valor: Matriz Diagnóstico AS IS, consolidando o retrato real de funcionamento da área.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 10 -->

Apêndice 1.3 - Diagnóstico de Maturidade de Governança

Entregável de Valor: Matriz Diagnóstico AS IS

![](GoogleShape437p34.jpg)

![](GoogleShape438p34.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 11 -->

Etapa 2 - Benchmark de Estrutura e Práticas
Objetivo Estratégico: analisar a estrutura e as práticas de áreas de energia de players de referência, entendendo como papéis, responsabilidades e governança se organizam e evoluem conforme a área cresce, para embasar o desenho da estrutura-alvo da FS.
Principais Atividades: Benchmark de Estrutura e Práticas de Áreas de Energia

Realização de até 5 reuniões de Benchmark e Desk Research de forma a obter insumos para construção do PLano de Expansão para a área de Energia da FS;

Construção de um modelo de referência de estrutura de áreas de energia (front, middle e back office) a partir de fontes setoriais e de descrições de cargo de players do mercado;

Mapeamento das características e destaques das áreas das empresas entrevistadas, com foco em:
Metodologias utilizadas;
Forma de treinamento da equipe;
Organograma da área;
Governança e Gestão do Conhecimento;
Indicadores chave utilizados.

Entregável de Valor: Relatório com os dados obtidos e consolidado de critérios para os próximos passos
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 12 -->

Etapa 3.1 - Papéis e Responsabilidades
Objetivo Estratégico: identificar e priorizar os gargalos de atribuição de funções, verificando se há clareza sobre quem executa, decide, valida e acompanha cada atividade.
Principais Atividades: Identificação de Gargalos e Organograma TO BE

Reuniões com o gestor para analisar os ritos e processos da área;

Identificação dos gargalos de clareza no escopo e nas responsabilidades de cada função, incluindo o acompanhamento regulatório através da nova tecnologia;

Elaboração do organograma TO BE no Lucidspark com base nos gargalos identificados

Definição de cargos, hierarquias, conexões interáreas e critérios de acompanhamento

Entregável de Valor: gargalos de atribuição de funções identificados e organograma TO BE estruturado no Lucidspark
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 13 -->

Etapa 3.2 - Papéis e Responsabilidades
Objetivo Estratégico: consolidar as melhorias de responsabilidades em um documento executivo, garantindo maior clareza na governança e na coordenação entre áreas.
Principais Atividades: Playbook de Papéis e Funções

Definição das melhorias na estrutura de responsabilidades com base nos gargalos priorizados

Preenchimento do Playbook de Papéis e Funções consolidando as propostas de solução

Entregável de Valor: Playbook de Papéis e Funções com as responsabilidades formalizadas e as melhorias propostas documentadas.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 14 -->

Etapa 4.1 - Reuniões e Ritos
Objetivo Estratégico: identificar os gargalos na estrutura e funcionamento dos ritos e reestruturá-los para garantir maior padronização, previsibilidade e eficiência na tomada de decisão da área.
Principais Atividades: Identificação de Gargalos e Reestruturação de Ritos

Reuniões com o gestor para analisar os ritos existentes;

Verificação de gargalos como ausência de objetivo claro, falta de registro de decisões, frequência inadequada e ausência de acompanhamento pós-reunião;

Definição das melhorias com base nos gargalos identificados, podendo envolver criação de novos ritos, ajuste de periodicidade, redefinição de agendas, padronização das dinâmicas e estruturação do rito de acompanhamento regulatório;

Entregável de Valor: gargalos de ritos identificados e estrutura de ritos reestruturada com as melhorias propostas.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 15 -->

Etapa 4.2 - Reuniões e Ritos
Objetivo Estratégico: consolidar as melhorias na estrutura de ritos em um documento executivo, garantindo maior padronização, previsibilidade e eficiência na tomada de decisão da área.
Principais Atividades: Playbook de Ritos

Preenchimento do Playbook de Ritos consolidando as propostas de solução definidas

Formalização da estrutura de reuniões, com objetivos, periodicidade, agendas e dinâmicas padronizadas

Entregável de Valor: Playbook de Ritos com a estrutura de reuniões formalizada e as melhorias propostas documentadas.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 16 -->

Etapa 4.2 - Reuniões e Ritos

Entregável de Valor:  Página online de armazenamento de ritos.

![](GoogleShape565p40.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 17 -->

Etapa 5.1 - Plano de Expansão
Objetivo Estratégico: consolidar o estudo em um documento executivo que embasa a expansão da área e dá visibilidade do seu valor estratégico para a empresa.
Principais Atividades: Business Case de Expansão

Consolidação do diagnóstico AS IS, da estrutura-alvo e das referências de mercado em uma narrativa única;

Estruturação dos argumentos que sustentam a expansão (importância da área, crescimento da empresa, entrada de novas unidades);

Estruturação de indicadores de sucesso de forma a acompanhar o crescimento e expansão da área de Energia;

Entregável de Valor: Business Case de Expansão, documento executivo que embasa o crescimento da área para a liderança.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 18 -->

Etapa 5.2 - Plano de Expansão
Objetivo Estratégico: estruturar um plano claro e priorizado para implementação das soluções propostas, garantindo alinhamento entre as equipes e orientação para a execução das iniciativas.
Principais Atividades: Roadmap

Consolidação das iniciativas e soluções definidas ao longo do projeto;

Organização das ações em uma sequência lógica de implementação;

Definição de prioridades, dependências e marcos relevantes para execução;

Entregável de Valor: Roadmap estruturado com as iniciativas priorizadas, facilitando o acompanhamento das entregas e a implementação das melhorias.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 19 -->

Etapa 6 - Documentação Final
Objetivo Estratégico: consolidar todo o estudo e as entregas realizadas em um formato de fácil acesso e disseminação para a equipe da FS.
Principais Atividades:

Estruturação de uma documentação executiva contendo as principais entregas e análises do projeto de forma enxuta;

Criação de um site específico e personalizado para uso interno da empresa contendo os documentos produzidos pela equipe da Poli Júnior e formatado de forma intuitiva para fácil usabilidade.

Entregável de Valor: documentação executiva e site personalizado para a FS.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 20 -->

Etapa 6 - Documentação Final

Entrega: Repositório Online

![](GoogleShape646p44.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 21 -->

![](GoogleShape668p45.jpg)

Equipe Dedicada ao Projeto e Parceria
2 Consultores por 7 semanas
Graduandos Engenheiros Politécnicos da USP da área de Gestão Empresarial e Consultoria da Poli Júnior

1 Coordenador
Membro sênior de projetos da área na empresa
Como será nossa parceria?
Serão realizados reports semanais entre os stakeholders e a equipe para alinhamentos sobre os pontos de atuação e revisão dos resultados;
Os stakeholders colaboram facilitando os insumos necessários (como acesso a documentos e contatos) e com a validação das entregas;
Serão realizadas constantes consultas de experiência e satisfação no decorrer da execução e após sua implementação.
A Poli Júnior se propõe a realizar termos aditivos para contratação de serviços adicionais.

### Notes:

<!-- Slide number: 22 -->

Cronograma do projeto - Analytics & IA

Camada de inteligência
Pipeline de Coleta e Armazenamento
Imersão no contexto e Diagnóstico
Documentação Final
Interface de consumo
Deploy

Entrega 1
Entrega 2
Entrega 3
Entrega 4
Entrega 6
Entrega 5
Semanas 2-5
Semanas 6-9
Semana 1
Semanas 12-13
Semana 10-11
Semanas 14-15

Classificar relevância, gerar resumos e digest diário, sinalizar críticos e habilitar busca histórica.

Construir coletores por fonte com orquestração, deduplicação e armazenamento estruturado com metadados.

Consolidar o corpus regulatório, travar a lista de fontes, taxonomia e critérios de aceite.

Migrar para produção com observabilidade, versionamento de prompts, painel de custo e documentação.

Rodar piloto em paralelo, ajustar prompt e taxonomia e formalizar o aceite assinado.

Dashboard ao vivo com resumo diário, alertas de críticos e busca em linguagem natural.

### Notes:

<!-- Slide number: 23 -->

Etapa 1 - Imersão e Diagnóstico - Analytics
Objetivo Estratégico: consolidar o corpus regulatório da FS Fueling e travar as fontes, a taxonomia e os critérios de aceite antes de qualquer desenvolvimento.
Principais Atividades:

Sessões com o time da FS Fueling para levantar o que é acompanhado, com que frequência e o que é considerado crítico;

Travamento da lista final de fontes e análise de acessibilidade técnica de cada uma (API, RSS, scraping, credencial);
Definição da taxonomia temática (mercado livre, PLD, tarifa, ambiental, tributário setorial) validada com a FS Fueling;

Entregável de Valor: Documento de Refinamento com mapa de fontes, taxonomia, conjunto de calibração e critérios de aceite validados.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 24 -->

Etapa 2 - Pipeline de Coleta e Armazenamento  - Analytics
Objetivo Estratégico: construir a base técnica que coleta, organiza e armazena de forma confiável todo o conteúdo regulatório das fontes travadas na Etapa 1.
Principais Atividades:

Coletores por fonte e separação por natureza da fonte: oficiais públicas (ONS, ANEEL, CCEE, DOU) e imprensa (Valor, UOL) com cuidado nos termos de uso

Orquestração com agendamento, retry e logging, deduplicação entre fontes e armazenamento estruturado com metadados; ;
Testes de robustez contra falhas comuns como fonte fora do ar, mudança de layout e encoding;

Entregável de Valor: pipeline rodando em desenvolvimento, com histórico populado de no mínimo 30 dias e relatório de cobertura de fontes.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 25 -->

Etapa 3 - Camada de Inteligência com LLM - Analytics
Objetivo Estratégico: transformar o conteúdo coletado em inteligência acionável, classificando relevância, resumindo publicações e habilitando consulta histórica.
Principais Atividades:

Prompt engineering para classificação de relevância contra a taxonomia definida e resumo executivo por publicação e digest diário agregado;

Sinalização de itens críticos com critérios versionados, alimentando o fluxo de escalação da FS Fueling
 Busca histórica (RAG): indexação da base e recuperação em linguagem natural;

Entregável de Valor: camada de inteligência processando o histórico, com métricas de precisão e cobertura dentro dos critérios da Etapa 1.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 26 -->

Etapa 4 - Interface de Consumo - Analytics
Objetivo Estratégico: entregar à FS Fueling uma tela dedicada ao monitoramento contínuo, desenhada para o uso real da rotina regulatória.
Principais Atividades:

Dashboard ao vivo para monitoramento contínuo, com resumo diário consolidado no topo;

Sistema de alertas para itens críticos, visíveis conforme surgem e campo de busca em linguagem natural sobre a base histórica;
Sessões de refinamento com a FS Fueling para hierarquia visual e priorização;

Entregável de Valor: interface em homologação, com o time da FS Fueling navegando pelo histórico populado e configurando alertas. .
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 27 -->

Etapa 5 - Deploy - Analytics
Objetivo Estratégico: Colocar a plataforma em produção com estabilidade, monitoramento e documentação que garantam operação autônoma.
Principais Atividades:

Migração para o ambiente de produção definido nas premissas de início

Observabilidade: monitoramento de disponibilidade das fontes, alertas de falha de coleta e painel de custo mensal de API;
Versionamento de prompts para rastreabilidade de mudanças de comportamento;

Entregável de Valor: plataforma em produção com painel de observabilidade ativo
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 28 -->

Etapa 6-  Validação e Documentação - Analytics
Objetivo Estratégico: Validar a plataforma no uso real da FS Fueling e realizar a transferência de conhecimento para  a equipe da FS Fueling
Principais Atividades:

Colocar a plataforma em produção com estabilidade, monitoramento e documentação que garantam operação autônoma.

Acompanhamento diário para captar edge cases e ajustes finos de prompt e taxonomia com base no uso real;
Construção da documentação final, englobando arquitetura e agentes envolvidos

Entregável de Valor: plataforma validada em operação e documentação final técnica consolidada
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 29 -->

![](GoogleShape879p53.jpg)

Equipe Dedicada ao Projeto e Parceria
2 Consultores por 15 semanas
Responsáveis pelo entendimento das bases da FS Fueling e pela construção dos agentes de IA e automações
1 Coordenador
Membro sênior de projetos da área na empresa, responsável direto pela garantia de qualidade das entregas e execução.
1 Representante Comercial
Responsável por representar a visão do cliente, validando eventuais necessidades ao decorrer do projeto.
Como será nossa parceria?
Serão realizados reports semanais entre os stakeholders e a equipe para alinhamentos sobre os pontos de atuação e revisão dos resultados;
Os stakeholders colaboram facilitando os insumos necessários (como acesso a documentos e contatos) e com a validação das entregas;
Serão realizadas constantes consultas de experiência e satisfação no decorrer da execução e após sua implementação.
A Poli Júnior se propõe a realizar termos aditivos para contratação de serviços adicionais.

### Notes:

<!-- Slide number: 30 -->

Cases de Sucesso

![](GoogleShape890p54.jpg)

### Notes:

<!-- Slide number: 31 -->
PROBLEMA
SOLUÇÃO
Grupo EPR

Performance & Governança
O Grupo EPR possui verba anual destinada à inovação, porém sua gestão ocorria de forma descentralizada e pouco estruturada. Cada unidade conduzia iniciativas de maneira independente, sem processos, ritos ou diretrizes comuns, gerando retrabalho, repetição de erros e baixa eficiência no uso dos recursos. Além disso, a ausência de uma área responsável pela coordenação reduzia a visibilidade sobre os projetos e dificultava o acompanhamento estratégico, e a empresa ainda enfrentava o risco de penalidades tarifárias.
A equipe estruturou do zero a área de Inovação do Grupo  EPR, definindo escopo, governança e ritos de funcionamento da área. Foram mapeados e organizados os macro e microprocessos de inovação, estabelecendo fluxos claros para desenvolvimento e acompanhamento das iniciativas, em conjunto com a sponsor do projeto. Além disso, foram realizados estudos de potenciais parceiros e investidores, ampliando as possibilidades de conexão da EPR com o ecossistema de inovação.

.

![](GoogleShape932p55.jpg)
IMPACTO

A estruturação da área permitiu maior alinhamento e comunicação entre as unidades, reduzindo inconsistências e retrabalhos nas iniciativas de inovação. Como resultado, a empresa fortaleceu seu posicionamento como organização inovadora, além de promover maior organização interna e eficiência na gestão das iniciativas, contribuindo para o desenvolvimento estratégico da companhia.

### Notes:

<!-- Slide number: 32 -->
PROBLEMA
SOLUÇÃO
Pernambucanas

Gestão de Processos
A equipe estudou os papéis e responsabilidades, os ritos existentes, indicadores acompanhados e pontos recorrentes de travamento. Em seguida, estruturou uma Arquitetura de Decisões, Métricas e Ritos, definindo quais decisões a área precisa tomar, quais métricas sustentam essas decisões e como cada rito deve funcionar. Por fim, foram propostos ajustes de estrutura e interfaces entre times para reduzir dependência de validações centralizadas e aumentar clareza de responsabilidades.

A Pernambucanas apresentava dificuldades na governança da operação fiscal e financeira, com controle distribuído entre diferentes sistemas e planilhas, o que reduzia a visibilidade e a confiabilidade das informações. Na prática, a área operava com ritos de acompanhamento pouco padronizados e com critérios de decisão inconsistentes, gerando retrabalho, atrasos em validações/aprovações e baixa previsibilidade sobre prazos e pendências.

IMPACTO

As propostas permitiram tornar o acompanhamento fiscal-financeiro mais previsível e rastreável, com cadência de gestão mais resolutiva, redução de retrabalho por falta de alinhamento e maior consistência na tomada de decisão. Com isso, a área ganhou agilidade, segurança e controle, sustentando uma operação mais confiável mesmo em um contexto de alta complexidade tributária.

### Notes:

<!-- Slide number: 33 -->

![](GoogleShape987p57.jpg)

### Notes:

<!-- Slide number: 34 -->

![](GoogleShape1026p58.jpg)

Proposta Comercial
Proposta Comercial - Consultoria

![](GoogleShape1027p58.jpg)

EQUIPE
DURAÇÃO
INVESTIMENTO

2 Consultores
1 Coordenador

R$ 28.200,00
07 semanas
Cartão, boleto ou transferência. Parcelamento em até 4x.
Pagamento:

### Notes:

<!-- Slide number: 35 -->

![](GoogleShape1066p59.jpg)

Proposta Comercial
Proposta Comercial - Analytics

![](GoogleShape1067p59.jpg)

EQUIPE
DURAÇÃO
INVESTIMENTO

2 Consultores
1 Coordenador

R$ 69.600,00
15 semanas
Cartão, boleto ou transferência. Parcelamento em até 6x.
Pagamento:

### Notes:

<!-- Slide number: 36 -->

![](GoogleShape1106p60.jpg)

Proposta Comercial
Proposta Comercial - Pacote

![](GoogleShape1107p60.jpg)
~10%
de desconto

EQUIPE
DURAÇÃO
INVESTIMENTO

7 + 15 semanas
4 Consultores
2 Coordenador

R$ 88.000,00
Cartão, boleto ou transferência. Parcelamento em até 6x.
Pagamento:

### Notes:

<!-- Slide number: 37 -->

![](GoogleShape1121p61.jpg)

Esclarecimentos Comerciais
Nossa minuta padrão contratual - que engloba questões jurídicas como garantias, deveres e responsabilidades, entre outras informações - está disponível neste link.

O CNAE (Classificação Nacional de Atividades Econômicas) da Poli Júnior, a empresa júnior da Escola Politécnica da USP, é 7112-0/00 - Serviços de Engenharia. Essa classificação engloba atividades como consultoria, projetos e outros serviços relacionados à engenharia.

Pareceres: Nossa proposta está em conformidade com a legislação aplicável e nos comprometemos com a qualidade do projeto - assim como para todos nossos clientes. Estamos disponíveis para tiragens de dúvidas durante todo o contato (dados ao final do documento).

Em caso de necessidade de números de contas bancárias, estatuto social, cartão CNPJ, Inscrição Municipal ou outras questões, entrar em contato.

Nosso valor engloba todos os custos estabelecidos pelo projeto, incluindo impostos.

### Notes:

<!-- Slide number: 38 -->

![](GoogleShape1133p62.jpg)

Esclarecimentos Comerciais
Para esta proposta comercial, são válidas as seguintes condições:

No decorrer do projeto, serão realizadas reuniões entre a equipe da Poli Júnior e o cliente para coleta de dados, discussão do andamento do projeto e apresentação de resultados – o cliente se compromete em ter disponibilidade para tais encontros e troca de informações;
As atividades têm início e fim a partir das datas que serão estabelecidas no contrato, documento elaborado mediante a aprovação desta proposta por ambas as partes, Poli Júnior e cliente;
As informações contidas nesta proposta são confidenciais, não devendo ser utilizadas ou apresentadas por qualquer outra pessoa sem o consentimento de ambas as partes;
A equipe da Poli Júnior não trabalhará durante as semanas de prova da Escola Politécnica;
Essa proposta comercial possui validade de 1 mês a contar da data de sua apresentação 30/06/2026;
O projeto poderá ser iniciado 60 dias após a assinatura do contrato;
A contratante deve agir com respeito a todos os envolvidos no serviço em questão, sob pena de rescisão do contrato;
Serão realizadas coletas de satisfação em relação ao projeto no decorrer da execução e ao final do projeto;
No caso de atraso no pagamento de até 10 dias úteis, o projeto será congelado, com retomada prevista em até 5 dias úteis após o devido pagamento ter sido realizado.

### Notes:

<!-- Slide number: 39 -->

![](GoogleShape1168p63.jpg)

Nosso Contato e Próximos Passos

Gabriel Cury Beyruti

Nicholas Mac-Knight Gimenes

Coordenador de Negócios

Coordenador de Negócios

gabriel.beyruti@polijunior.com.br

nicholas.gimenes@polijunior.com.br

11 97561-6380

11 96322-8250

Próximos Passos:
Aprovação Verbal até data estipulada
Validação jurídica da minuta contratual
Assinatura do contrato pelos representantes

### Notes:
