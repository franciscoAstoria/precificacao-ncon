<!-- Slide number: 1 -->

Estudo de Mercado e Análise Competitiva para Direcionamento de Portfólio em Educação Continuada

Proposta de Parceria
31  de Julho, 2026

![](GoogleShape67p13.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 2 -->

Poli Júnior - Empresa Júnior da Escola Politécnica da USP

A Poli Júnior é uma instituição constituída por alunos de Graduação da Escola Politécnica de Engenharia da USP.

Localizados na melhor faculdade de engenharia da América Latina, seu projeto é impulsionado pelo mais alto rigor e talentos da Escola Politécnica, garantindo o que há de mais inovador em tecnologias, resultando em soluções ágeis e criativas. Além disso, criando uma forte conexão da empresa com a POLI-USP.

Nossa excelência e agilidade é refinada por treinamentos e parcerias com as maiores consultorias do mundo visando aplicar o mesmo padrão de excelência e pensamento estratégico em nossos projetos.

1º
+1100
90%
lugar
entre as Empresas Juniores do Brasil
Projetos concluídos
Índice de Satisfação
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 3 -->

Quem conta com as soluções da Poli Júnior

![](GoogleShape137p15.jpg)

### Notes:

<!-- Slide number: 4 -->

Sumário - Nosso Entendimento do Seu Contexto e Objetivos

![](GoogleShape166p16.jpg)

Recomendamos a condução de um diagnóstico de Employer Branding de dentro para fora: primeiro a leitura do alcance e da percepção da marca Bracell junto ao público de interesse, e então a leitura competitiva dos players que disputam os mesmos talentos, sustentando planos de ação de divulgação e atração.
Contexto:
A Bracell enxerga na frente de atração e seleção de talentos uma importante vertical para o crescimento, que depende de um portfólio alinhado às expectativas dos potenciais ingressos e às estratégias de divulgação da empresa.
Esse comportamento não é algo tão visível: a maneira como profissionais escolhem o seu local de trabalho varia conforme a faixa etária, a área de atuação e o momento da economia, refletindo diretamente na escolha da empresa e do plano de carreira a ser escolhida. Ao mesmo tempo, os concorrentes fortalecem portfólio, posicionamento e campanhas de captação de colaboradores, o que faz necessário um estudo de como a angariação de profissionais é feita pelos outros players do mercado de celulose.
Nesse cenário, torna-se essencial compreender, de forma embasada, como cada perfil escolhe a companhia em que irá trabalhar, e como se diferenciar frente aos concorrentes diretos por atributos de valor, sustentando um plano de carreira que chame a atenção de engenheiros e outros talentos, situando a Bracell em uma situação privilegiada no mercado.

Projetos que integram otimização e tecnologias inovadoras à sua empresa
Conexão com a USP e talentos da Escola Politécnica

Entregas frequentes que geram valor rápido
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 5 -->

Principais objetivos da Bracell

![](GoogleShape192p17.jpg)

Objetivos:

"Não só o como estamos sendo vistos, mas o que pode ser feito para isso melhorar, que eu acho que é o ganho. O que pode entrar em plano de ação para falar: vamos fortalecer, entendemos a fraqueza, é aqui que a gente está falhando e onde a gente pode melhorar."
Entender o comportamento do mercado de trabalho e estudantes, ouvindo o público de interesse para mapear preferências de modelo de atuação, motivações e critérios de escolha por faixa etária e área de graduação.

Mapear o posicionamento e os atributos de valor dos concorrentes diretos, via desk research e cliente oculto, consolidados em matriz de concorrentes e mapas perceptuais.

Transformar os dados das duas frentes em direcionamentos acionáveis, cruzando voz do mercado e leitura competitiva para estruturar planos de ação priorizados de portfólio e posicionamento, entregues em uma apresentação executiva.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 6 -->

Cronograma do projeto
Rodagem do Questionário e Análise Competitiva

Planos de Ação e Documentação Final
Estruturação de Instrumentos de Pesquisa
Imersão no contexto
Dashboard e Análise dos Dados

Entrega 4
Entrega 1
Entrega 2
Entrega 3
Semana 5
Semanas 2-3
Semana 4
Semana 1

Alinhar objetivos com os stakeholders, mapear as localidades da Bracell e co-criar a Matriz CSD.

Desenvolver questionário com bifurcação e roteiro do cliente oculto.

Analisar os dados, construir dashboard e mapas perceptuais.

Estruturar planos de ação de divulgação e fortalecimento da marca empregadora.

Rodar o questionário e conduzir desk research e cliente oculto, consolidando a matriz de concorrentes.

### Notes:

<!-- Slide number: 7 -->

Etapa 1 - Imersão no contexto
Semana 1
Objetivo Estratégico: alinhar os principais pontos do projeto com os stakeholders da Bracell, garantindo a devida priorização estratégica para as próximas etapas.
Principais Atividades:

Realização do kick-off de equipe para os alinhamentos iniciais.

Estudo das localidades e operações da Bracell, direcionando a segmentação da pesquisa, e levantamento das pesquisas e relatórios já utilizados internamente, evitando sobreposição.

Definição, junto à equipe interna da Bracell, da lista dos até 8 concorrentes a serem analisados no desk research e no cliente oculto, bem como das informações a serem mapeadas em cada um.

Co-criação da Matriz CSD, usada para direcionar o questionário e o roteiro do cliente oculto.

Entregável de Valor:  Cronograma do projeto, Matriz CSD e lista de concorrentes/empresas mapeadas.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 8 -->

Etapa 1 - Imersão no contexto
Semana 1

Exemplo: Matriz CSD

![](GoogleShape280p20.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 9 -->

Etapa 2 - Estruturação de Instrumentos de Pesquisa
Semana 1
Objetivo Estratégico: desenvolver os instrumentos e a metodologia que vão embasar o diagnóstico, capturando a percepção da marca empregadora Bracell e as práticas dos concorrentes.
Principais Atividades:

Perfil da amostra:
400 respondentes em todo o Brasil, de 18 a 50 anos, cursando ou com ensino superior concluído;
Foco em engenharia (aproximadamente 75% da amostra, entre estudantes e formados), complementado por respondentes de outras áreas de formação diversas.

As perguntas estratégicas permitirão:
Medir o conhecimento espontâneo e estimulado da Bracell e dos players do setor;
Identificar os atributos mais valorizados na escolha de onde trabalhar, por perfil de formação, faixa etária e região;
Via bifurcação, aprofundar a percepção de quem conhece a marca e as barreiras de quem não considera a Bracell (demanda latente);
Mapear os canais em que o público busca informações sobre carreira e vagas.

Entregável de Valor:  Fluxograma do questionário e roteiro de cliente oculto construídos e validados com os stakeholders.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 10 -->

Etapa 2 - Estruturação de Instrumentos de Pesquisa
Semana 1

Exemplo: Fluxograma do questionário

![](GoogleShape316p22.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 11 -->

Etapa 3 - Rodagem do Questionário e Análise Competitiva
Semanas 2-3
Objetivo Estratégico: aplicar o questionário com o público-alvo e estudar os concorrentes mapeados, entendendo como atuam na atração de talentos e o que comunicam como valor.
Principais Atividades:

Desk research em até 8 concorrentes definidos na imersão junto à equipe da Bracell:
Proposta de valor ao empregado (EVP) comunicada e páginas de carreira;
Programas de estágio e trainee: formato, requisitos e benefícios;
Presença em universidades, campanhas e canais de divulgação.

Cliente oculto nas marcas selecionadas: jornada completa como candidato interessado (comunicação das vagas, experiência de inscrição, atendimento e follow-up de cada player), com escopo e empresas definidos na Etapa 1, em conjunto com os stakeholders.

Consolidação da Matriz de Concorrentes: comparativo dos players em EVP, programas, canais e experiência do candidato, com análise VRIO dos diferenciais identificados.

Aplicação do questionário com os 400 respondentes.

Entregável de Valor:  Base de respostas do questionário, relatório de cliente oculto e Matriz de Concorrentes
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 12 -->

Etapa 3 - Rodagem do Questionário e Análise Competitiva

Semanas 2-3

Exemplo: Análise VRIO

![](GoogleShape355p24.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 13 -->

Etapa 3 - Rodagem do Questionário e Análise Competitiva

Semanas 2-3

Exemplo: Matriz de Concorrentes

![](GoogleShape374p25.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 14 -->

Etapa 3 - Rodagem do Questionário e Análise Competitiva

Semanas 2-3

Exemplo: Base de Respostas

![](GoogleShape385p26.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 15 -->

Etapa 4 - Dashboard e Análise dos Dados Coletados
Semana 4
Objetivo Estratégico: realizar as análises com maior detalhe crítico sobre os dados coletados no questionário, no cliente oculto e no desk research, transformando-os em inteligência acionável.
Principais Atividades:

Desenvolvimento da dashboard com os dados do questionário e os principais indicadores de alcance, percepção e atratividade da marca.

Segmentação da base por tipos de perfil (engenharia e demais áreas de formação, faixa etária, região e interesse no setor), identificando os atributos valorizados e as barreiras de cada segmento.

Consolidação da análise em Matriz SWOT: forças e fraquezas da marca empregadora Bracell frente aos concorrentes, e oportunidades e ameaças identificadas na leitura de mercado.

Construção de Mapas Perceptuais a partir do questionário e da matriz de concorrentes: posicionamento visual dos players em eixos estratégicos, revelando espaços competitivos em aberto.

Entregável de Valor:  Dashboard interativa, Mapas Perceptuais e Matriz SWOT integrando a voz do público e a leitura competitiva.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 16 -->

Etapa 4 - Dashboard e Análise dos Dados Coletados

Semana 4

Exemplo: Dashboard

![](GoogleShape427p28.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 17 -->

Etapa 4 - Dashboard e Análise dos Dados Coletados

Semana 4

Exemplo: Mapa Perceptual

![](GoogleShape446p29.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 18 -->

Etapa 4 - Dashboard e Análise dos Dados Coletados

Semana 4

Exemplo: Matriz SWOT

![](GoogleShape461p30.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 19 -->

Etapa 5 - Planos de Ação e Documentação Final
Semana 5
Objetivo Estratégico: consolidar todo o estudo em direcionamentos que respondam ao objetivo central da Bracell: entender como a marca empregadora está sendo vista e o que pode ser feito para fortalecê-la, sustentado por dados primários e inteligência competitiva.
Principais Atividades:

Cruzamento dos dados do questionário, do cliente oculto e da matriz de concorrentes, revelando o que cada perfil busca e o que a concorrência oferece ou deixa de oferecer.

Estruturação dos planos de ação de portfólio e posicionamento, respondendo qual modalidade e formato ofertar para cada perfil e como se diferenciar por atributos de valor.

Estruturação de uma documentação executiva enxuta e criação de um site personalizado para uso interno da Bracell, com todas as entregas organizadas de forma intuitiva.

Entregável de Valor: Planos de ação e direcionamentos priorizados, documentação executiva e repositório online personalizado.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 20 -->

Etapa 5 - Planos de Ação e Documentação Final

Semana 5
Entrega: Repositório Online

![](GoogleShape499p32.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 21 -->

Equipe Dedicada ao Projeto e Parceria

![](GoogleShape522p33.jpg)
2 Consultores por 5 semanas
Graduandos Engenheiros Politécnicos da USP da área de Gestão Empresarial e Consultoria da Poli Júnior

1 Coordenador
Membro sênior de projetos da área na empresa
Como será nossa parceria?
Serão realizados reports semanais entre os stakeholders e a equipe para alinhamentos sobre os pontos de atuação e revisão dos resultados;
Os stakeholders colaboram facilitando os insumos necessários (como acesso a documentos e contatos) e com a validação das entregas;
Serão realizadas constantes consultas de experiência e satisfação no decorrer da execução e após sua implementação.
A Poli Júnior se propõe a realizar termos aditivos para contratação de serviços adicionais.

### Notes:

<!-- Slide number: 22 -->

Cases de Sucesso

![](GoogleShape533p34.jpg)

### Notes:

<!-- Slide number: 23 -->
PROBLEMA
SOLUÇÃO
WildLife

Pesquisa de Mercado
A equipe conduziu uma rodagem de questionário com estudantes da Poli-USP, ITA, IME, Insper e FEA, segmentando os perfis e mapeando a percepção sobre processos seletivos, as exigências e atributos valorizados nas empresas de interesse, os canais mais efetivos de comunicação e a percepção da marca como empregadora.
A Wildlife, uma das maiores desenvolvedoras de games do país, buscava fortalecer sua estratégia de atração de talentos, entendendo a visibilidade da marca junto ao público jovem, o perfil dos estudantes com aderência à empresa e o que os motivava na escolha de onde trabalhar, para direcionar suas ações de marca empregadora.

![](GoogleShape576p35.jpg)
IMPACTO

O projeto entregou direcionamentos estratégicos de atração e seleção baseados em dados primários, com a definição do perfil de candidato ideal, os atributos e canais que mais engajam o público-alvo e planos de ação priorizados para fortalecer a marca empregadora junto aos estudantes das principais escolas de engenharia e negócios do país.

### Notes:

<!-- Slide number: 24 -->

Proposta Comercial

![](GoogleShape612p36.jpg)

EQUIPE
DURAÇÃO
INVESTIMENTO

2 Consultores
1 Coordenador

5 semanas
R$ 24.100,00
Pagamento: Cartão, Boleto ou Transferência | Em até 3x com parcelas a serem pagas nos Dia 10, 20 ou 30 do mês

### Notes:

<!-- Slide number: 25 -->

Esclarecimentos Comerciais

![](GoogleShape623p37.jpg)
Nossa minuta padrão contratual - que engloba questões jurídicas como garantias, deveres e responsabilidades, entre outras informações - está disponível neste link.

O CNAE (Classificação Nacional de Atividades Econômicas) da Poli Júnior, a empresa júnior da Escola Politécnica da USP, é 7112-0/00 - Serviços de Engenharia. Essa classificação engloba atividades como consultoria, projetos e outros serviços relacionados à engenharia.

Pareceres: Nossa proposta está em conformidade com a legislação aplicável e nos comprometemos com a qualidade do projeto - assim como para todos nossos clientes. Estamos disponíveis para tiragens de dúvidas durante todo o contato (dados ao final do documento).

Em caso de necessidade de números de contas bancárias, estatuto social, cartão CNPJ, Inscrição Municipal ou outras questões, entrar em contato.

Nosso valor engloba todos os custos estabelecidos pelo projeto, incluindo impostos.

### Notes:

<!-- Slide number: 26 -->

Esclarecimentos Comerciais

![](GoogleShape635p38.jpg)
Para esta proposta comercial, são válidas as seguintes condições:

No decorrer do projeto, serão realizadas reuniões entre a equipe da Poli Júnior e o cliente para coleta de dados, discussão do andamento do projeto e apresentação de resultados – o cliente se compromete em ter disponibilidade para tais encontros e troca de informações;
As atividades têm início e fim a partir das datas que serão estabelecidas no contrato, documento elaborado mediante a aprovação desta proposta por ambas as partes, Poli Júnior e cliente;
As informações contidas nesta proposta são confidenciais, não devendo ser utilizadas ou apresentadas por qualquer outra pessoa sem o consentimento de ambas as partes;
A equipe da Poli Júnior não trabalhará durante as semanas de prova da Escola Politécnica;
Essa proposta comercial possui validade de 1 mês a contar da data de sua apresentação 31/07/2026;
O projeto poderá ser iniciado 15 dias úteis após a assinatura do contrato;
A contratante deve agir com respeito a todos os envolvidos no serviço em questão, sob pena de rescisão do contrato;
Serão realizadas coletas de satisfação em relação ao projeto no decorrer da execução e ao final do projeto;
No caso de atraso no pagamento de até 10 dias úteis, o projeto será congelado, com retomada prevista em até 5 dias úteis após o devido pagamento ter sido realizado.

### Notes:

<!-- Slide number: 27 -->

Nosso Contato e Próximos Passos

![](GoogleShape694p39.jpg)

Gabriel Cury Beyruti

Carlos Negreiros

Consultor de Negócios

Coordenador de Negócios

gabriel.beyruti@polijunior.com.br

carlos.negreiros@polijunior.com.br

11 97561-6380

11 94593-1592

Próximos Passos:
Aprovação Verbal até data estipulada
Validação jurídica da minuta contratual
Assinatura do contrato pelos representantes

### Notes:
