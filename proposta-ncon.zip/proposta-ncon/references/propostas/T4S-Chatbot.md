<!-- Slide number: 1 -->

Desenvolvimento de um Agente de IA para Consulta de POPs

Proposta de Parceria
19 de Junho, 2026

![](GoogleShape101p13.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 2 -->

Poli Júnior - Empresa Júnior da Escola Politécnica da USP

A Poli Júnior é uma instituição constituída por alunos de Graduação da Escola Politécnica de Engenharia da USP.

Localizados na melhor faculdade de engenharia da América Latina, seu projeto é impulsionado pelo mais alto rigor e talentos da Escola Politécnica, garantindo o que há de mais inovador em tecnologias, resultando em soluções ágeis e criativas. Além disso, criando uma forte conexão da empresa com a POLI-USP.

Nossa excelência e agilidade é refinada por treinamentos e parcerias com as maiores consultorias do mundo visando aplicar o mesmo padrão de excelência e pensamento estratégico em nossos projetos.

1º
+1100
90%
lugar
entre as Empresas Juniores do Brasil
Projetos concluídos
Índice de Satisfação
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 3 -->

Quem conta com as soluções da Poli Júnior

![](GoogleShape171p15.jpg)

### Notes:

<!-- Slide number: 4 -->

![](GoogleShape201p16.jpg)

Sumário - Nosso Entendimento do Seu Contexto e Objetivos
Uma Proposta para facilitar o acesso às informações contidas nas documentações da T4S

Recomendamos a atualização dos POPs e integração dos mesmos no ChatBot personalizado para a T4S
Contexto:
A T4S possui uma base robusta de aproximadamente 300 processos documentados em fluxogramas e Procedimentos Operacionais Padrão (POPs), utilizada como referência para o treinamento de equipes e a consulta no dia a dia. Com a evolução natural das operações, parte dos fluxogramas foi atualizada para refletir os novos processos, enquanto os POPs correspondentes ainda seguem o formato anterior.
Objetivos:

Atualmente, a consulta a essa base depende da navegação manual entre diferentes documentos, o que torna o acesso à informação menos ágil do que o potencial da base permite. O objetivo é alinhar os POPs aos fluxogramas vigentes e disponibilizar um agente de IA que centralize a consulta, tornando o acesso ao conhecimento mais rápido, intuitivo e confiável.

Entregas frequentes que geram valor rápido
Conexão com a USP e talentos da Escola Politécnica

Projetos que integram otimização e tecnologias inovadoras à sua empresa
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 5 -->

Cronograma do projeto

Imersão e Atualização de POPs
Desenvolvimento do Chatbot e Testes

Semanas 1-4
Alinhamento inicial com a T4S, mapeamento da base e atualização dos POPs em relação aos fluxogramas vigentes.
Elaboração e treinamento do agente de IA sobre a base atualizada, com deploy, uso assistido e gestão do conhecimento.

### Notes:

<!-- Slide number: 6 -->

Etapa 1 - Imersão e Atualização de POPs
Objetivo Estratégico: alinhar as equipes, mapear a base de processos e atualizar os POPs em relação aos fluxogramas vigentes.
Principais Atividades:

Realização do kick-off: alinhamentos iniciais com a equipe da T4S e definição de prioridades;

Revisão e atualização dos POPs identificados, conforme os fluxogramas vigentes;

Padronização da estrutura dos POPs e validação das atualizações junto à equipe da T4S.

Entregável de Valor:  base de POPs revisada e alinhada aos fluxogramas vigentes, pronta para consulta e para alimentar o agente de IA.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 7 -->

Etapa 2 - Desenvolvimento do Chatbot e Testes

Objetivo Estratégico: transformar a base de POPs em consulta inteligente, garantir seu pleno funcionamento e deixar a equipe da T4S autônoma na manutenção.
Principais Atividades:

Estruturação e treinamento do agente de IA sobre a base de POPs atualizada, com modelo de fácil usabilidade adaptado ao contexto da T4S;

Testes de qualidade das respostas e dos fluxos de consulta;

Deploy e uso assistido: monitoramento do desempenho, suporte à operação e coleta de feedbacks para ajustes;

Gestão do conhecimento: desenvolvimento de manuais para a manutenção autônoma dos POPs e da base do agente.

Entregável de Valor: Assistente virtual de IA operacional, configurado e treinado, integrado aos documentos de processos da empresa, com foco em dúvidas frequentes, direcionamento de tarefas e apoio à tomada de decisão.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 8 -->

ChatBot Conversacional

Entrega: ChatBot

![](GoogleShape284p20.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 9 -->

![](GoogleShape310p21.jpg)

Equipe Dedicada ao Projeto e Parceria
2 Consultores por 4 semanas
Graduando Engenheiro Politécnico da USP da área de Gestão Empresarial e Consultoria da Poli Júnior

1 Coordenador
Membro sênior de projetos da área na empresa
Como será nossa parceria?
Serão realizados reports semanais entre os stakeholders e a equipe para alinhamentos sobre os pontos de atuação e revisão dos resultados;
Os stakeholders colaboram facilitando os insumos necessários (como acesso a documentos e contatos) e com a validação das entregas;
Serão realizadas constantes consultas de experiência e satisfação no decorrer da execução e após sua implementação.
A Poli Júnior se propõe a realizar termos aditivos para contratação de serviços adicionais.

### Notes:

<!-- Slide number: 10 -->

![](GoogleShape350p22.jpg)

Proposta Comercial
Proposta Comercial

![](GoogleShape349p22.jpg)

EQUIPE
DURAÇÃO
INVESTIMENTO

2 Consultores
1 Coordenador

R$ 20.300,00
4 semanas
Cartão, boleto ou transferência. Parcelamento em até 4x.
Pagamento:

### Notes:

<!-- Slide number: 11 -->

![](GoogleShape361p23.jpg)

Esclarecimentos Comerciais
Nossa minuta padrão contratual - que engloba questões jurídicas como garantias, deveres e responsabilidades, entre outras informações - está disponível neste link.

O CNAE (Classificação Nacional de Atividades Econômicas) da Poli Júnior, a empresa júnior da Escola Politécnica da USP, é 7112-0/00 - Serviços de Engenharia. Essa classificação engloba atividades como consultoria, projetos e outros serviços relacionados à engenharia.

Pareceres: Nossa proposta está em conformidade com a legislação aplicável e nos comprometemos com a qualidade do projeto - assim como para todos nossos Clientes. Estamos disponíveis para tiragens de dúvidas durante todo o contato (dados ao final do documento).

Em caso de necessidade de números de contas bancárias, estatuto social, cartão CNPJ, Inscrição Municipal ou outras questões, entrar em contato.

Nosso valor engloba todos os custos estabelecidos pelo projeto, incluindo impostos.

### Notes:

<!-- Slide number: 12 -->

![](GoogleShape373p24.jpg)

Esclarecimentos Comerciais
Para esta proposta comercial, são válidas as seguintes condições:

No decorrer do projeto, serão realizadas reuniões entre a equipe da Poli Júnior e o Cliente para coleta de dados, discussão do andamento do projeto e apresentação de resultados – o Cliente se compromete em ter disponibilidade para tais encontros e troca de informações;
As atividades têm início e fim a partir das datas que serão estabelecidas no contrato, documento elaborado mediante a aprovação desta proposta por ambas as partes, Poli Júnior e Cliente;
As informações contidas nesta proposta são confidenciais, não devendo ser utilizadas ou apresentadas por qualquer outra pessoa sem o consentimento de ambas as partes;
A equipe da Poli Júnior não trabalhará durante as semanas de prova da Escola Politécnica;
Essa proposta comercial possui validade de 1 mês a contar da data de sua apresentação 19/06/2026;
O projeto poderá ser iniciado 15 dias úteis após a assinatura do contrato;
A contratante deve agir com respeito a todos os envolvidos no serviço em questão, sob pena de rescisão do contrato;
Serão realizadas coletas de satisfação em relação ao projeto no decorrer da execução e ao final do projeto;
No caso de atraso no pagamento de até 10 dias úteis, o projeto será congelado, com retomada prevista em até 5 dias úteis após o devido pagamento ter sido realizado.

### Notes:

<!-- Slide number: 13 -->

![](GoogleShape454p25.jpg)

Nosso Contato e Próximos Passos

Gabriel Beyruti

Enzo Rêgo

Ulisses Fontoura

Coordenador de Negócios

Diretor Comercial
Coordenador de Tecnologia

gabriel.beyruti@polijunior.com.br

enzo.rego@polijunior.com.br

ulisses.fontoura@polijunior.com.br

11 97561-6380

21  99925-6405

62  98181-0051

Próximos Passos:
Aprovação Verbal
Validação jurídica da minuta contratual
Assinatura do contrato pelos representantes

### Notes:
