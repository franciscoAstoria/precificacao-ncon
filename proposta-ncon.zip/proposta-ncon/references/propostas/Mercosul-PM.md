<!-- Slide number: 1 -->

Entendimento Competitivo e Mercadológico para o Fortalecimento da Mercosul Line

Proposta de Parceria
22 de Junho, 2026

![](GoogleShape58p13.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 2 -->

Poli Júnior - Empresa Júnior da Escola Politécnica da USP

A Poli Júnior é uma instituição constituída por alunos de Graduação da Escola Politécnica de Engenharia da USP.

Localizados na melhor faculdade de engenharia da América Latina, seu projeto é impulsionado pelo mais alto rigor e talentos da Escola Politécnica, garantindo o que há de mais inovador em tecnologias, resultando em soluções ágeis e criativas. Além disso, criando uma forte conexão da empresa com a POLI-USP.

Nossa excelência e agilidade é refinada por treinamentos e parcerias com as maiores consultorias do mundo visando aplicar o mesmo padrão de excelência e pensamento estratégico em nossos projetos.

1º
+1100
90%
lugar
entre as Empresas Juniores do Brasil
Projetos concluídos
Índice de Satisfação
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 3 -->

Quem conta com as soluções da Poli Júnior

![](GoogleShape137p15.jpg)

### Notes:

<!-- Slide number: 4 -->

![](GoogleShape167p16.jpg)

Sumário - Nosso Entendimento do Seu Contexto e Objetivos
Uma proposta para análise de concorrência e de mercado com foco em transporte marítimo e rodoviário

Recomendamos a análise dos concorrentes e do mercado a fim de trazer insights valiosos sobre posicionamento comercial e captação de clientes.
Contexto:
A Mercosul Line atua no transporte marítimo de cabotagem e no transporte rodoviário, oferecendo soluções logísticas que vão desde a coleta na fábrica do cliente até a entrega no CD ou no cliente final. A empresa transporta commodities como soja, café e amendoim, além de outros produtos com demanda variável ao longo do ano. A Mercosul Line busca compreender como concorrentes como Log-In, Norcoast e Aliança se posicionam comercialmente e como atraem clientes que demandam transporte rodoviário integrado.

Projetos que integram otimização e tecnologias inovadoras à sua empresa
Conexão com a USP e talentos da Escola Politécnica

Entregas frequentes que geram valor rápido
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 5 -->

![](GoogleShape194p17.jpg)

Principais desafios da Mercosul Line

Objetivos:
Mapear as estratégias comerciais dos concorrentes diretos (Log-In, Norcoast e Aliança no modal marítimo), construindo uma visão estruturada e comparativa de como cada player atua na captação de clientes

“Sabemos que perdemos cargas para os players rodoviários, mas não entendemos exatamente como trazê-los de volta.“
Identificar como os concorrentes conseguem atrair clientes que demandam transporte integrado, entendendo seus diferenciais frente à oferta atual da Mercosul Line

Analisar a sazonalidade e volumetria dos produtos transportados (soja, café, amendoim e outros), mapeando os períodos de maior demanda e como o mercado se comporta ao longo do ano

Gerar insights e recomendações estratégicas para que a Mercosul Line fortaleça seu posicionamento competitivo no modal rodoviário com base em dados de mercado

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 6 -->

Cronograma do projeto
Imersão no contexto
Documentação final
Análise dos concorrentes
FASE 1: Traçar um Plano de Solução Adequado
Análise Mercadológica
Planos de ação

Semana 1
Semanas 2-3
Semanas 4-5
Semanas 6
Semana 7

Traçar os primeiros passos do projeto e os principais pontos a serem observados nos concorrentes

Entendimento do posicionamento dos outros players, mapeando preços praticados, formas de abordagem e produtos oferecidos.

Compreender os dados coletados, entendendo quais são seus diferenciais e a relação com os preços de cada a fim de trazer direcionamentos estratégicos.

Consolidar todas os dados e análises em um único documento e elaborar um site com todas as entregas

Mapear sazonalidades e padrões de demanda dos produtos transportados pela Mercosul Line.

### Notes:

<!-- Slide number: 7 -->

Etapa 1 - Imersão no contexto
Objetivo Estratégico: alinhar os principais pontos do projeto com os stakeholders da Mercosul Line, garantindo a devida priorização estratégica para as próximas etapas.
Principais Atividades:

Realização do kick-off de equipe para os alinhamentos iniciais.

Entendimento dos principais pontos a serem mapeados durante as análises dos concorrentes e dos produtos que serão analisados, fazendo uma imersão detalhada sobre eles;

Co-criação da Matriz CSD para direcionar melhor as próximas análises.

Entregável de Valor:  Canvas de escopo, Cronograma do projeto e Matriz CSD.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 8 -->

Etapa 2 - Análise Mercadológica
Objetivo Estratégico: Consolidar uma visão ampla e estruturada do mercado em que a Mercosul Line está inserida, compreendendo a sazonalidade dos produtos transportados e os padrões de demanda ao longo do ano, de forma a embasar estratégias mais assertivas de entrada e posicionamento no modal rodoviário.
Principais Atividades:

Mapear e consolidar as principais fontes de informação sobre o mercado de commodities transportadas pela Mercosul Line (soja, café, amendoim e outros), utilizando dados de safra, associações setoriais, bases públicas e publicações especializadas em agronegócio e logística

Realizar análise de sazonalidade e volumetria, identificando os períodos de maior e menor demanda por transporte de cada produto ao longo do ano, e como isso impacta o fluxo de cargas no modal marítimo e rodoviário.

Entregável de Valor:  Relatório de análise mercadológica com mapeamento de sazonalidade e volumetria por produto
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 9 -->

Etapa 3 - Análise dos Concorrentes
Objetivo Estratégico: realizar um estudo aprofundado dos concorrentes, entendendo as estratégias de captação, posicionamento comercial.
Principais Atividades:

Mapeamento das características da Log-In, Norcoast e Aliança para o segmento de cabotagem:
Serviços oferecidos e diferenciais (ex: coleta porta a porta, entrega no CD ou cliente final);
Estratégias de captação e abordagem comercial, como foco em atração para o transporte rodoviário;
Estrutura de atendimento ao cliente e backoffice/faturamento.

Ferramentas a serem utilizadas:
Cliente Oculto com Concorrentes
i. Levantamento e comparação das práticas comerciais, operacionais e de atendimento dos principais concorrentes diretos (cabotagem e rodoviário), identificando lacunas e oportunidades de diferenciação para a Mercosul Line
Ferramenta VRIO
Ferramenta de análise que ajuda empresas a identificar e avaliar seus recursos, de forma a determinar se possuem vantagem competitiva

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 10 -->

Etapa 3 - Análise dos Concorrentes

![](GoogleShape303p22.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 11 -->

Etapa 4 - Planos de Ação
Objetivo Estratégico: realizar as análises com maior detalhe crítico sobre os dados e percepções coletadas.
Principais Atividades:

Elaboração de uma Matriz SWOT e SWOT cruzada compreendendo os principais pontos a serem sanados
SWOT: ferramenta de gestão que serve para identificar as forças, fraquezas, oportunidades e ameaças de uma empresa, e propor ações estratégicas
SWOT Cruzada: combina os pontos positivos e negativos da empresa para
Potencializar as forças,
Aproveitar as oportunidades;
Neutralizar as ameaças;
Corrigir as fraquezas.

Entendimento de como os diferenciais competitivos dos concorrentes estão relacionados às estratégias de captação e como eles se relacionam aos serviços da Mercosul Line, a fim de gerar insights e oportunidades de diferenciação estratégica .

Entregável de Valor:  relatório qualitativo quanto às análises realizadas com planos de ação.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 12 -->

Etapa 5 - Documentação Final
Objetivo Estratégico: consolidar todo o estudo e as entregas realizadas em um formato de fácil acesso e disseminação para a equipe da Mercosul Line.
Principais Atividades:

Criação de um site específico e personalizado para uso interno da Mercosul Line contendo os documentos produzidos pela equipe da Poli Júnior e formatado de forma intuitiva para fácil usabilidade.

Elaboração de um relatório com todos os dados coletados ao longo das análises feitas em relação aos diferenciais e às precificações praticadas, trazendo os principais insights para a Mercosul Line.

Entregável de Valor: site personalizado para a Mercosul Line e relatório com as análises consolidadas.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 13 -->

Etapa 5 - Documentação Final

Entrega: Repositório Online

![](GoogleShape357p25.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 14 -->

![](GoogleShape379p26.jpg)

Equipe Dedicada ao Projeto e Parceria
1 Consultor por 7 semanas
Graduandos Engenheiros Politécnicos da USP da área de Gestão Empresarial e Consultoria da Poli Júnior

1 Coordenador
Membro sênior de projetos da área na empresa
Como será nossa parceria?
Serão realizados reports semanais entre os stakeholders e a equipe para alinhamentos sobre os pontos de atuação e revisão dos resultados;
Os stakeholders colaboram facilitando os insumos necessários (como acesso a documentos e contatos) e com a validação das entregas;
Serão realizadas constantes consultas de experiência e satisfação no decorrer da execução e após sua implementação.
A Poli Júnior se propõe a realizar termos aditivos para contratação de serviços adicionais.

### Notes:

<!-- Slide number: 15 -->

Cases de Sucesso

![](GoogleShape390p27.jpg)

### Notes:

<!-- Slide number: 16 -->
Mitt Incorporadora
Pesquisa de Mercado
PROBLEMA
SOLUÇÃO

![](GoogleShape432p28.jpg)

A equipe realizou um estudo mercadológico e territorial completo, englobando análises socioeconômicas, levantamento de concorrentes e pesquisa quantitativa com moradores da região. A partir dos dados coletados, foram desenvolvidos mapas de calor, análises comparativas e planos de ação estratégicos, indicando as áreas de maior potencial de valorização e os perfis prioritários de clientes.
A empresa buscava analisar o potencial do mercado imobiliário em uma cidade no interior de Minas Gerais, visando compreender o perfil do público e os fatores decisivos na compra de imóveis. Era necessário um mapeamento detalhado da demanda local, identificação de tendências, estudo de concorrência e avaliação das melhores oportunidades de posicionamento estratégico para um novo empreendimento.

IMPACTO

O projeto forneceu à empresa uma base sólida para a tomada de decisão sobre o novo empreendimento, com insights sobre público, localização e demanda. As análises apontaram as regiões mais promissoras e o ticket médio ideal, permitindo definir o posicionamento de mercado e estratégias comerciais mais assertivas, reduzindo riscos e otimizando investimentos futuros.

### Notes:

<!-- Slide number: 17 -->

![](GoogleShape471p29.jpg)

Proposta Comercial

![](GoogleShape472p29.jpg)

EQUIPE
DURAÇÃO
INVESTIMENTO

1 Consultor
1 Coordenador

7 semanas
R$ 15.300,00
Pagamento: Cartão, Boleto ou Transferência | Em até 4x com parcelas a serem pagas nos Dia 10, 20 ou 30 do mês

### Notes:

<!-- Slide number: 18 -->

![](GoogleShape509p30.jpg)

Proposta Comercial

![](GoogleShape510p30.jpg)
20% de desconto
Assinatura até 30/06/2026

EQUIPE
DURAÇÃO
INVESTIMENTO

1 Consultor
1 Coordenador

7 semanas
R$ 12.960,00
Pagamento: Cartão, Boleto ou Transferência | Em até 4x com parcelas a serem pagas nos Dia 10, 20 ou 30 do mês

### Notes:

<!-- Slide number: 19 -->

![](GoogleShape524p31.jpg)

Esclarecimentos Comerciais
Nossa minuta padrão contratual - que engloba questões jurídicas como garantias, deveres e responsabilidades, entre outras informações - está disponível neste link.

O CNAE (Classificação Nacional de Atividades Econômicas) da Poli Júnior, a empresa júnior da Escola Politécnica da USP, é 7112-0/00 - Serviços de Engenharia. Essa classificação engloba atividades como consultoria, projetos e outros serviços relacionados à engenharia.

Pareceres: Nossa proposta está em conformidade com a legislação aplicável e nos comprometemos com a qualidade do projeto - assim como para todos nossos clientes. Estamos disponíveis para tiragens de dúvidas durante todo o contato (dados ao final do documento).

Em caso de necessidade de números de contas bancárias, estatuto social, cartão CNPJ, Inscrição Municipal ou outras questões, entrar em contato.

Nosso valor engloba todos os custos estabelecidos pelo projeto, incluindo impostos.

### Notes:

<!-- Slide number: 20 -->

![](GoogleShape536p32.jpg)

Esclarecimentos Comerciais
Para esta proposta comercial, são válidas as seguintes condições:

No decorrer do projeto, serão realizadas reuniões entre a equipe da Poli Júnior e o cliente para coleta de dados, discussão do andamento do projeto e apresentação de resultados – o cliente se compromete em ter disponibilidade para tais encontros e troca de informações;
As atividades têm início e fim a partir das datas que serão estabelecidas no contrato, documento elaborado mediante a aprovação desta proposta por ambas as partes, Poli Júnior e cliente;
As informações contidas nesta proposta são confidenciais, não devendo ser utilizadas ou apresentadas por qualquer outra pessoa sem o consentimento de ambas as partes;
A equipe da Poli Júnior não trabalhará durante as semanas de prova da Escola Politécnica;
Essa proposta comercial possui validade de 1 mês a contar da data de sua apresentação 22/06/2026;
O projeto poderá ser iniciado 15 dias úteis após a assinatura do contrato;
A contratante deve agir com respeito a todos os envolvidos no serviço em questão, sob pena de rescisão do contrato;
Serão realizadas coletas de satisfação em relação ao projeto no decorrer da execução e ao final do projeto;
No caso de atraso no pagamento de até 10 dias úteis, o projeto será congelado, com retomada prevista em até 5 dias úteis após o devido pagamento ter sido realizado.

### Notes:

<!-- Slide number: 21 -->

![](GoogleShape594p33.jpg)

Nosso Contato e Próximos Passos

João Castanheira

Gabriel Beyruti

Consultor de negócios
Coordenador de Negócios

joao.castanheira@polijunior.com.br

gabriel.beyruti@polijunior.com.br

62 99802-2007

11 97561-6380

Próximos Passos:
Aprovação Verbal
Validação jurídica da minuta contratual
Assinatura do contrato pelos representantes

### Notes:
