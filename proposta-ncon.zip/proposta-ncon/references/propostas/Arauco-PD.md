<!-- Slide number: 1 -->

Rastreabilidade e tomada de decisão orientada a dados por meio do mapeamento de processos

Proposta de Parceria
15 de Julho, 2026

![](GoogleShape102p14.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 2 -->

Poli Júnior - Empresa Júnior da Escola Politécnica da USP

A Poli Júnior é uma instituição constituída por alunos de Graduação da Escola Politécnica de Engenharia da USP.

Localizados na melhor faculdade de engenharia da América Latina, seu projeto é impulsionado pelo mais alto rigor e talentos da Escola Politécnica, garantindo o que há de mais inovador em tecnologias, resultando em soluções ágeis e criativas. Além disso, criando uma forte conexão da empresa com a POLI-USP.

Nossa excelência e agilidade é refinada por treinamentos e parcerias com as maiores consultorias do mundo visando aplicar o mesmo padrão de excelência e pensamento estratégico em nossos projetos.

1º
+1100
90%
lugar
entre as Empresa Juniores do Brasil
Projetos concluídos
Índice de Satisfação
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 3 -->

Quem conta com as soluções da Poli Júnior

![](GoogleShape172p16.jpg)

### Notes:

<!-- Slide number: 4 -->

Sumário - Nosso Entendimento do Seu Contexto e Objetivos

![](GoogleShape201p17.jpg)

Recomendamos a execução de um discovery técnico, visando mapear os fluxos de eventos, perfis de usuário e integrações necessárias para o sistema centralizado de gestão de alertas da Arauco.
Contexto:
A Arauco está construindo o Projeto Sucuriú, em Inocência (MS), o maior projeto greenfield de celulose do mundo, com 3,5 milhões de toneladas de capacidade e cerca de 250.000 locais de instalação mapeados. A obra já está com 62%+ de avanço físico, com startup previsto para 1º de setembro de 2027 e a meta de ter 90% das ferramentas de manutenção operacionais já em janeiro. A área de Confiabilidade hoje conta com uma equipe de 6 engenheiros. A Arauco já implantou uma estrutura de manutenção extremamente madura, baseada na pirâmide S.A.M.I adaptada, com SAP como CMMS central para taxonomia, controle inicial de ativos, planos de manutenção e spare parts, e um portfólio robusto de ferramentas especialistas: Machine Works + AMS Optics para vibração, 3i para termografia, SDT para ultrassom, Valmet Maintenance Pad para rotas de inspeção visual, Valmet Condition Monitoring, Plant Triage e Aveva Predict, além do Aveva PI System como historiador de processo conectado ao SDCD que controla a planta em tempo real.

Entregas frequentes que geram valor rápido
Conexão com a USP e talentos da Escola Politécnica

Projetos que integram otimização e tecnologias inovadoras à sua empresa
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 5 -->

Principais dores da Arauco

![](GoogleShape218p18.jpg)

Situação:
O problema é que cada uma dessas ferramentas especialistas opera de forma isolada, gerando alertas e alarmes em plataformas distintas, sem nenhuma governança centralizada, e com apenas 6 engenheiros cobrindo horário administrativo (enquanto a planta opera 24/7), seria necessário ter algo como 40 engenheiros para monitorar cada ferramenta individualmente. Além disso, RCM, FMEA, RCA e os planos de manutenção do SAP vivem em bases desconectadas: qualquer atualização de tática de manutenção não se propaga automaticamente entre esses sistemas, gerando inconsistência e retrabalho.

Nesse sentido, cabe o mapeamento inicial dos processos hoje existentes e os dados relacionados através de uma visão sistêmica para a elaboração de um sistema central, que agregue os alertas de todas as fontes preditivas num único painel, com workflows segmentados por perfil de usuário que sustentem a operação 24/7, incluindo triagem de risco, tratamento de emergências, abertura de notas no SAP e um módulo de governança de RCM que substitua o FMEA legado.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 6 -->

Principais objetivos da Arauco

![](GoogleShape245p19.jpg)

Objetivos:
Mapear, via discovery técnico, todos os fluxos de eventos, perfis de usuário e caminhos de integração das plataformas especialistas de manutenção da Arauco, consolidando um documento de requisitos funcionais e não funcionais.

"Eu preciso centralizar isso. Eu preciso ter esse domínio do que está acontecendo na minha planta."
Desenhar a arquitetura funcional de um sistema único de gestão de eventos que centralize alertas/alarmes de todas as ferramentas preditivas, com workflow de tratativa por perfil e integração nativa com o SAP.

Estruturar a governança e rastreabilidade entre RCM, planos de manutenção e execução no SAP, substituindo a ferramenta de FMEA legada e viabilizando a mensuração do retorno das ferramentas preditivas via capturômetro.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 7 -->

Principais objetivos da Arauco

![](GoogleShape294p20.jpg)

Alertas Fragmentados
Sem rastreabilidade
Equipe insuficiente
Sem governança central
RCM, SAP e RCA isolados
6 eng. p/ operação 24/7

Criação de visibilidade e Dicovery Técnico
Mapeamento de ponta a ponta dos processos participantes do fluxo do sistema a ser desenvolvido.

01
Entrevistas
02
Desenho BPMN
03
Auditoria do sistema
7 pontos focais identificados
Fluxos dos processos
Documento técnico

ENTREGÁVEIS  Mapa de processos  ·  Pontos de causa raiz  ·  Escopo técnico do sistema

Construção do sistema

Interface e fluxos
Integração de dados
Analítica e insights
Telas por perfil de uso
SAP + preditivas
Capturômetro de ganho

### Notes:

<!-- Slide number: 8 -->

Cronograma do projeto

Diagnóstico e correlação  dos dados
Mapeamento dos processos
Prototipação e Documentação final
Especificação do discovery técnico
Imersão no contexto

Entrega 3
Entrega 2
Entrega 1
Entrega 4
Semana 8
Semana 7
Semanas 2-3
Semana 4-6
Semana 1

Mapear os atuais fluxos dos processos do da Arauco, visando criar visibilidade sobre as atividades que participarão do fluxo do sistema.

Consolidado de documentação robusta com desenvolvimento do projeto e principais outputs.

Levantamento dos dados já existentes, avaliando origem, qualidade, granularidade e como estão sendo utilizados atualmente, além de relacionar cada etapa dos processos mapeados aos dados, evidenciando lacunas de rastreabilidade, pontos cegos e oportunidades de estruturação da informação.

Consolidação dos requisitos de rastreabilidade e dos dados que precisam ser capturados, estruturados e disponibilizados, servindo como base para o time de tecnologia desenvolver, posteriormente, a ferramenta de controle e rastreabilidade.

Traçar os primeiros passos do projeto e agendar reuniões.

### Notes:

<!-- Slide number: 9 -->

Etapa 1 - Imersão no contexto
Objetivo Estratégico: alinhar os principais pontos do projeto com os stakeholders de Arauco, garantindo clareza sobre o ecossistema de ferramentas que hoje geram alertas/dados na planta e como cada uma se conecta (ou não) com o SAP.
Principais Atividades:

Realização do kick-off: definição dos pontos focais e alinhamento de expectativas sobre padronização, documentação e desenvolvimento do projeto.

Levantamento do inventário de sistemas: SAP (CMMS), Machine Works + AMS Optics (vibração), 3i (termografia), SDT (ultrassom), Valmet Maintenance Pad (rotas de inspeção), Valmet Condition Monitoring, Plant Triage, Aveva PI System/Predict, Industrial (RCA/diário de bordo), ReliaSoft (FMEA a ser substituído).

Entendimento macro dos protocolos de integração já conhecidos (OPC DA/PI, SQL Server, APIs web) vs. os que ainda são incerteza (ex: Aveva Predict, Condition Monitoring).

Entregável de Valor:  Canvas de Escopo, Cronograma do projeto e inventário de sistemas/integrações validado.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 10 -->

Etapa 2 - Mapeamento dos processos
Objetivo Estratégico: desenhar o fluxograma completo do gerenciamento de eventos, do alerta até a confirmação de processo, cobrindo os diferentes perfis.
Principais Atividades:

Realização de entrevistas com as 7 pessoas da equipe envolvidos nos processos:
Desenho dos fluxos de Avaliação de risco e triagem de notificações, Atendimento emergencial, Atendimento planejado, Estratégia de tática de manutenção, Confirmação de processo e histórico de equipamento, Captura de dados das ferramentas preditivas, Integração com SAP, Reuniões de apoio para identificação de informações técnicas.

Entendimento do fluxograma (mapeamento e modelagem):
Atores, responsabilidades e indicadores atuais;
Atividades repetitivas e redundantes;
Fluxo de informação e relação sistêmica das ferramentas com a execução;
Comunicação entre áreas e canais de informação.

Entregável de Valor:  Fluxos construídos e validados pelos stakeholders.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 11 -->

Etapa 2 - Mapeamento dos processos

VALIDAÇÃO
MAPEAMENTO
O mapeamento permite a consolidação de processos e análise mais assertiva da execução das atividades do dia a dia da empresa.
Validar o mapeamento de um processo com os gestores da área garante maior assertividade nas análises e documentação.
FERRAMENTA UTILIZADA

Já utilizamos plataformas como Bizagi Modeler, Figma e Lucid Chart para a construção dos fluxogramas, permitindo a edição e facilidade de acesso, o que, por sua vez, permite a manutenção dos fluxos.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 12 -->

Etapa 3.1 - Diagnóstico e correlação dos dados
Objetivo Estratégico: compreender o cenário atual de dados da operação, avaliando o que cada ferramenta especialista gera, como é armazenado e como hoje se conecta (ou não) ao SAP.
Principais Atividades:

Mapeamento de inputs e outputs de cada ferramenta especialista identificando protocolo de integração e nível de dificuldade.
Levantamento do formato dos alertas e alarmes (definição dos níveis) gerados por cada plataforma e a granularidade de dado disponível.

Identificação de como a equipe de confiabilidade consome hoje esses dados no dia a dia e quais dores enfrenta pela falta de visão unificada.

Entregável de Valor:  Consolidado estruturado das ferramentas existentes, classificado por protocolo de integração, granularidade e uso atual, com diagnóstico de viabilidade de integração.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 13 -->

Etapa 3.2 - Diagnóstico e correlação dos dados
Objetivo Estratégico: conectar o fluxo de tratativa de eventos mapeado às ferramentas e dados existentes, evidenciando onde há rastreabilidade hoje e onde estão os "elos perdidos" entre RCM, FMEA, RCA e SAP.
Principais Atividades:

Relacionamento de cada etapa do fluxo (avaliação de risco → tratativa → confirmação de processo) às ferramentas que hoje sustentam essa decisão, identificando o que é registrado em sistema e o que se perde no caminho.

Priorização dos gaps de rastreabilidade, como o FMEA no ReliaSoft não se comunicar com o SAP, definindo impacto, complexidade e forma de monitoramento para cada lacuna.

Construção de uma visão consolidada do nível de rastreabilidade atual, orientando o escopo mínimo viável do sistema centralizado.

Entregável de Valor: consolidado de correlação entre fluxo e dados, com mapeamento das lacunas de rastreabilidade e priorização dos pontos críticos que demandam estruturação
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 14 -->

Etapa 4.1 - Requisitos de Negócio
Objetivo Estratégico: traduzir as dores operacionais e objetivos estratégicos da Arauco em requisitos formais de negócio, garantindo que a ferramenta a ser desenvolvida resolva os problemas reais identificados no mapeamento
Principais Atividades:

Mapeamento dos processos críticos de manutenção (mecânica, elétrica, instrumentação) que devem ser cobertos pela ferramenta, com priorização por criticidade de equipamento e risco de parada de planta

Levantamento das regras de negócio que a ferramenta precisa respeitar: critérios de classificação de evento (falso positivo, alerta, defeito, anomalia, falha funcional), políticas de turno (horário administrativo x operação 24x7) e níveis de severidade por tipo de sensor

Entregável de Valor: documento de Requisitos de Negócio listando processos priorizados, regras de classificação de evento, KPIs esperados e restrições operacionais que a ferramenta deve atender.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 15 -->

Etapa 4.2 - Requisitos de Usuário
Objetivo Estratégico: garantir que a ferramenta seja projetada a partir da perspectiva de quem a usará, com fluxos intuitivos, informações relevantes por perfil e baixa carga cognitiva no registro de dados em campo.

Principais Atividades:

Especificação das histórias de usuário (user stories) para cada perfil: o que cada ator precisa visualizar, registrar e receber como alerta no sistema de rastreabilidade.
Definição de critérios de aceite por história de usuário e validação das prioridades com os pontos focais, garantindo que o escopo reflete as necessidades reais de quem usa o sistema no dia a dia.

Definição conjunta dos perfis de acesso e do nível de permissão de cada um (visualização, input de dados, aprovação/edição), validando com a equipe se a segregação proposta cobre a realidade operacional

Entregável de Valor: documento de Requisitos de Usuário com personas, jornadas de uso por turno e a matriz de perfis de acesso validada com o cliente.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 16 -->

Etapa 4.3 - Requisitos Técnicos
Objetivo Estratégico: entender a fundo o ecossistema de ferramentas especialistas da Arauco (Machine Works, AMS Optics, SDT, Industrial, AVEVA PI System, SAP, entre outras) para desenhar uma arquitetura de dados compatível com o que existe hoje e com o que ainda está em implantação.

Principais Atividades:

Levantamento técnico de cada fonte de dados citada por Leandro, mapeando protocolo de conexão e nível de maturidade de cada integração
Definição da estrutura de dados necessária para suportar múltiplos níveis de severidade e categorias de anomalia por especialidade (mecânica, elétrica, instrumentação)

Avaliação conjunta com a equipe técnica da Arauco de qual rastreabilidade é viável estabelecer entre o sistema, o SAP e o RCM/FMEA

Entregável de Valor: documento de Requisitos Técnicos com o mapa de integrações possíveis, protocolo por fonte, e a arquitetura de dados proposta para o núcleo do sistema.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 17 -->

Etapa 4 - Especificação do discovery técnico

Entrega: Arquitetura do Sistema

![](GoogleShape526p30.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 18 -->

Etapa 5.1 - PRD + Prototipação
Objetivo Estratégico: consolidar tudo que foi descoberto nas etapas de negócio, usuário e técnica em uma visão única de produto, definindo com clareza o que entra e o que fica fora do escopo de desenvolvimento.

Principais Atividades:

Prototipação das principais telas da ferramenta por perfil de uso, incluindo fluxos de registro de peças, dados de rastreabilidade e painel de alertas.

Elaboração do PRD (Product Requirement Document) consolidando todos os requisitos de negócio, usuário e técnicos levantados nas semanas anteriores em um único documento estruturado e rastreável.

Entregável de Valor: documento de Requisitos Técnicos com especificações de integração ERP, arquitetura de dados, regras de segurança: insumo direto para o time de software iniciar o desenvolvimento posteriormente.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 19 -->

Etapa 5.1 - Prototipação

Entrega: Prototipação

![](GoogleShape560p32.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 20 -->

Etapa 5.2 - Documentação Final
Objetivo Estratégico: consolidar todo o estudo e as entregas realizadas em um formato de fácil acesso e disseminação para a equipe da Arauco.
Principais Atividades:

Estruturação de uma documentação executiva contendo as principais entregas e análises do projeto de forma enxuta;

Criação de um site específico e personalizado para uso interno da Arauco contendo os documentos produzidos pela equipe da Poli Júnior e formatado de forma intuitiva para fácil usabilidade.

Entregável de Valor: documentação executiva e site informativo personalizado para a Arauco.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 21 -->

Etapa 5.2 - Documentação Final

Entrega: Repositório Online

![](GoogleShape594p34.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 22 -->

Etapa 6 - Escopo Aberto de Desenvolvimento
Direcionamento Geral: Construir um sistema que centralize alertas, alarmes e anomalias de manutenção hoje dispersos em múltiplas ferramentas especialistas, com workflow de tratativa e aprovação por perfil — com a abordagem técnica definida a partir do Discovery.

Áreas da solução:

Painel centralizado de alertas, alarmes e anomalias, com filtros multinível por área/planta.

Workflow de eventos: abertura, classificação, tratativa e aprovação, com histórico e status.

Controle de acesso por perfil (gestor, engenheiro, analista técnico).

O escopo é melhor definido com base no Discovery. As frentes representam as áreas de foco do desenvolvimento.

Tempo sugerido: 4 meses
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 23 -->

Equipe Dedicada ao Projeto e Parceria - Discovery

![](GoogleShape639p36.jpg)
2 Consultores por 9 semanas
Graduandos Engenheiros Politécnicos da USP da área de Gestão Empresarial e Consultoria da Poli Júnior
1 Coordenador
Membro sênior de projetos da área de Consultoria na empresa
1 Product Manager
Membro sênior de projetos da área de Tecnologia na empresa

Como será nossa parceria?
Serão realizados reports semanais entre os stakeholders e a equipe para alinhamentos sobre os pontos de atuação e revisão dos resultados;
Os stakeholders colaboram facilitando os insumos necessários (como acesso a documentos e contatos) e com a validação das entregas;
Serão realizadas constantes consultas de experiência e satisfação no decorrer da execução e após sua implementação.
A Poli Júnior se propõe a realizar termos aditivos para contratação de serviços adicionais.

### Notes:

<!-- Slide number: 24 -->

Equipe Dedicada ao Projeto e Parceria - Desenvolvimento

![](GoogleShape662p37.jpg)
2 Consultores por 4 meses
Graduandos Engenheiros Politécnicos da USP da área de Tecnologia e Inovação
1 Product Manager
Membro sênior de projetos da área de Tecnologia na empresa

Como será nossa parceria?
Serão realizados reports semanais entre os stakeholders e a equipe para alinhamentos sobre os pontos de atuação e revisão dos resultados;
Os stakeholders colaboram facilitando os insumos necessários (como acesso a documentos e contatos) e com a validação das entregas;
Serão realizadas constantes consultas de experiência e satisfação no decorrer da execução e após sua implementação.
A Poli Júnior se propõe a realizar termos aditivos para contratação de serviços adicionais.

### Notes:

<!-- Slide number: 25 -->

Cases de Sucesso

![](GoogleShape673p38.jpg)

### Notes:

<!-- Slide number: 26 -->
Eletromidia
PROBLEMA
SOLUÇÃO
Gestão de Processos

A empresa enfrentava dificuldades na padronização e eficiência dos processos operacionais, especialmente na gestão e manutenção de ativos distribuídos em diferentes regiões.
 A falta de integração entre sistemas e de visibilidade sobre o funcionamento dos equipamentos gerava falhas operacionais, atrasos em campanhas e perdas financeiras recorrentes, comprometendo o nível de serviço prestado.

A equipe realizou o mapeamento completo dos processos, identificando gargalos críticos e propondo soluções de integração e automação.
 Foram estruturados fluxogramas “AS-IS” e “TO-BE”, análises financeiras e planos de ação priorizados via matrizes de esforço e impacto, visando melhorar a comunicação entre áreas, otimizar o atendimento técnico e reduzir falhas nos ativos.

IMPACTO

As soluções implementadas trouxeram maior eficiência operacional, redução de custos e padronização dos processos internos. Com a integração e automatização das atividades, foi estimada uma economia anual de R$ 1,58 milhão, considerando a quase eliminação dos casos de overbooking e a redução de 50% nas perdas financeiras por falhas operacionais e erros de agência.

### Notes:

<!-- Slide number: 27 -->
Banco Pine
PROBLEMA
SOLUÇÃO
Gestão de Processos

Mapeamento e identificação de gargalos, alcançando algumas quick wins, como a automatização de
tarefas em planilhas e ajustes na comunicação entre as áreas. Por fim, documentação do fluxograma
realizado com mais de 120 funcionários ( ) e modelo que deverá ser implementado (To Be).
Dificuldade na área de fechamento contábil por falta de padronização dos processos internos,
atividades manuais e falha de comunicação entre as áreas, causando reprocessamentos contábeis em grande escala e atrasos.

IMPACTO

Implementação de metodologias ágeis para a realização dos processos, proporcionando redução de aproximadamente 50% no tempo de execução dos processos de Fechamento Contábil.

### Notes:

<!-- Slide number: 28 -->
Manu Help
PROBLEMA
SOLUÇÃO
Site e Aplicativo

Foi desenvolvido uma plataforma digital com entregas parciais, permitindo que os usuários utilizassem o aplicativo ao longo do processo de desenvolvimento. Essa abordagem garantiu a criação de uma plataforma de gestão escalável, flexível e totalmente alinhada às necessidades e às condições de negócio da Manu.
A Manu é uma gestora de manutenções prediais que atua com foco em comunicação interna e gestão eficiente. No entanto, diante do crescimento das operações, a empresa identificou a necessidade de centralizar informações e organizar seus dados, garantindo mais controle, agilidade e qualidade nos processos.

![](GoogleShape801p41.jpg)
IMPACTO

A primeira versão da plataforma foi concluída com sucesso pela Poli Júnior, destacando-se pela flexibilidade e criatividade. Ainda, foi possível gerar resultados muito favoráveis, com um aumento de 5x no número de clientes e um aumento de mais de 600% em condomínios cadastrados.

### Notes:

<!-- Slide number: 29 -->
Empresa Multinacional de Bebidas
PROBLEMA
SOLUÇÃO

Site Interno

Consolidamos a camada visual da plataforma, transformando processos complexos em uma jornada intuitiva e simplificada para o público final. Entregamos uma identidade padronizada que permitiu a implementação ágil e sem atritos em diferentes departamentos da multinacional, garantindo consistência visual em todas as unidades ao redor do mundo.
A companhia buscava uma solução interna escalável que mantivesse a fluidez na jornada do colaborador em nível global. O desafio central era unificar as preferências de diversos perfis internacionais em uma interface única, eliminando barreiras de engajamento durante a transição para o novo ecossistema digital da empresa.

![](GoogleShape843p42.jpg)

IMPACTO

O projeto gerou alta aderência e eficiência, com forte percepção de usabilidade pelo público interno. A nova estrutura estabeleceu um padrão de excelência para a escala global da companhia, assegurando clareza na comunicação e agilidade na adoção da ferramenta em seus diversos núcleos operacionais.

### Notes:

<!-- Slide number: 30 -->

Proposta Comercial - Discovery

![](GoogleShape879p43.jpg)

EQUIPE
DURAÇÃO
INVESTIMENTO

2 Consultores
1 Coordenador
1 PM

R$ 44.000,00
8 semanas
Pagamento: Cartão, Boleto ou Transferência | Em até 4x com parcelas a serem pagas nos Dia 10, 20 ou 30 do mês

### Notes:

<!-- Slide number: 31 -->

Proposta Comercial - Desenvolvimento em Escopo Aberto

![](GoogleShape915p44.jpg)

EQUIPE
DURAÇÃO
INVESTIMENTO

2 Consultores
1 PM
R$ 68.200,00
16 semanas
Pagamento: Cartão, Boleto ou Transferência | Em até 6x com parcelas a serem pagas nos Dia 10, 20 ou 30 do mês

### Notes:

<!-- Slide number: 32 -->

Proposta Comercial - Discovery + Desenvolvimento

![](GoogleShape950p45.jpg)

EQUIPE
DURAÇÃO
INVESTIMENTO

2 Consultores
1 PM
R$ 112.200,00
24 semanas

### Notes:

<!-- Slide number: 33 -->

Esclarecimentos Comerciais

![](GoogleShape961p46.jpg)
Nossa minuta padrão contratual - que engloba questões jurídicas como garantias, deveres e responsabilidades, entre outras informações - está disponível neste link.

O CNAE (Classificação Nacional de Atividades Econômicas) da Poli Júnior, a empresa júnior da Escola Politécnica da USP, é 7112-0/00 - Serviços de Engenharia. Essa classificação engloba atividades como consultoria, projetos e outros serviços relacionados à engenharia.

Pareceres: Nossa proposta está em conformidade com a legislação aplicável e nos comprometemos com a qualidade do projeto - assim como para todos nossos clientes. Estamos disponíveis para tiragens de dúvidas durante todo o contato (dados ao final do documento).

Em caso de necessidade de números de contas bancárias, estatuto social, cartão CNPJ, Inscrição Municipal ou outras questões, entrar em contato.

Nosso valor engloba todos os custos estabelecidos pelo projeto, incluindo impostos.

### Notes:

<!-- Slide number: 34 -->

Esclarecimentos Comerciais

![](GoogleShape973p47.jpg)
Para esta proposta comercial, são válidas as seguintes condições:

No decorrer do projeto, serão realizadas reuniões entre a equipe da Poli Júnior e o cliente para coleta de dados, discussão do andamento do projeto e apresentação de resultados – o cliente se compromete em ter disponibilidade para tais encontros e troca de informações;
As atividades têm início e fim a partir das datas que serão estabelecidas no contrato, documento elaborado mediante a aprovação desta proposta por ambas as partes, Poli Júnior e cliente;
As informações contidas nesta proposta são confidenciais, não devendo ser utilizadas ou apresentadas por qualquer outra pessoa sem o consentimento de ambas as partes;
A equipe da Poli Júnior não trabalhará durante as semanas de prova da Escola Politécnica;
Essa proposta comercial possui validade de 1 mês a contar da data de sua apresentação 15/07/2026;
O projeto poderá ser iniciado 15 dias úteis após a assinatura do contrato;
A contratante deve agir com respeito a todos os envolvidos no serviço em questão, sob pena de rescisão do contrato;
Serão realizadas coletas de satisfação em relação ao projeto no decorrer da execução e ao final do projeto;
No caso de atraso no pagamento de até 10 dias úteis, o projeto será congelado, com retomada prevista em até 5 dias úteis após o devido pagamento ter sido realizado.

### Notes:

<!-- Slide number: 35 -->

Nosso Contato e Próximos Passos

![](GoogleShape1032p48.jpg)

Amanda Kwak

Beatriz Torres

Coordenadora de Negócios

Coordenadora de Negócios

amanda.kwak@polijunior.com.br

beatriz.torres@polijunior.com.br

11 95071-2402

11 99857-2929

Próximos Passos:
Aprovação Verbal até data estipulada
Validação jurídica da minuta contratual
Assinatura do contrato pelos representantes

### Notes:
