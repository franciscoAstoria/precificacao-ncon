<!-- Slide number: 1 -->

Padronização e ganho de eficiência no processo de Assessment Técnico

Proposta de Parceria
09 de Junho, 2026

![](GoogleShape67p13.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 2 -->

Poli Júnior - Empresa Júnior da Escola Politécnica da USP

A Poli Júnior é uma instituição constituída por alunos de Graduação da Escola Politécnica de Engenharia da USP.

Localizados na melhor faculdade de engenharia da América Latina, seu projeto é impulsionado pelo mais alto rigor e talentos da Escola Politécnica, garantindo o que há de mais inovador em tecnologias, resultando em soluções ágeis e criativas. Além disso, criando uma forte conexão da empresa com a POLI-USP.

Nossa excelência e agilidade é refinada por treinamentos e parcerias com as maiores consultorias do mundo visando aplicar o mesmo padrão de excelência e pensamento estratégico em nossos projetos.

1º
+1100
90%
lugar
entre as Empresa Juniores do Brasil
Projetos concluídos
Índice de Satisfação
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 3 -->

Quem conta com as soluções da Poli Júnior

![](GoogleShape137p15.jpg)

### Notes:

<!-- Slide number: 4 -->

![](GoogleShape168p16.jpg)

Sumário - Nosso Entendimento do Seu Contexto e Objetivos

Recomendamos o mapeamento AS IS e TO BE do processo, a elaboração de POPs e de um Manual Conversacional (chatbot), a fim de gerar clareza e padronização sobre a execução do Assessment Técnico.
Contexto:
Atualmente, a Sotreq executa o processo de Assessment Técnico por meio de 5 a 6 profissionais. No entanto, cada profissional conduz essa avaliação à sua própria maneira, sem um padrão único consolidado. Essa variabilidade gera resultados heterogêneos, dificulta a transferência de conhecimento e limita os ganhos de qualidade, eficiência e escala do processo.
Objetivos:
Diante disso, a Poli Júnior se propõe a mapear, padronizar e documentar o processo de Assessment Técnico, convergindo as diferentes formas de execução em um padrão único, consolidando o conhecimento em POPs e disponibilizando-o por meio de um assistente conversacional de apoio à operação.

Entregas frequentes que geram valor rápido
Conexão com a USP e talentos da Escola Politécnica

Projetos que integram otimização e tecnologias inovadoras à sua empresa
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 5 -->

Cronograma do projeto

Identificação de dores e soluções
FASE 1: Traçar um Plano de Solução Adequado
Manual Conversacional
Elaboração de manuais
Imersão no contexto
Mapeamento TO BE
Mapeamento AS IS
Documentação final

Entrega 3
Entrega 4
Entrega 6
Entrega 2
Entrega 1
Entrega 5
Semana 6
Semana 5
Semana 7
Semana 4
Semana 2
Semana 3
Semana 1

Elaboração de documentos detalhados com passo a passo das atividades analisadas.

Elaboração de manuais com procedimentos padrões das atividades analisadas.

Mapear como o Assessment Técnico é executado hoje por cada profissional, capturando as diferentes formas de execução.

Identificação e priorização dos principais gaps. Desenvolvimento de soluções e quick wins, amparadas na percepção das equipes, overlaps de atuação e erros.

Desenho dos fluxogramas ideais para a área com redução de erros e perdas, otimização e ganho de eficiência.

Consolidado de documentação robusta com desenvolvimento do projeto e principais outputs.

Traçar os primeiros passos do projeto e agendar reuniões.

### Notes:

<!-- Slide number: 6 -->

Etapa 1 - Imersão no contexto
Objetivo Estratégico: alinhar os principais pontos do projeto, garantindo conformidade entre as equipes da Sotreq e da Poli Júnior.
Principais Atividades:

Realização do kick-off: Definição dos pontos focais do projeto e dos alinhamentos iniciais com a equipe da Sotreq;

Entender e alinhar com a Equipe da Sotreq o que será mapeado

Agendamento das reuniões de mapeamento e dos reports semanais;

Entregável de Valor:  elaboração do Canvas de Escopo e Cronograma do projeto.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 7 -->

Etapa 2 - Mapeamento AS-IS dos processos
Objetivo Estratégico: construir os fluxogramas do processo de Assessment Técnico, que servirão de base para a identificação de gargalos.
Principais Atividades:

Realização de entrevistas com os responsáveis e envolvidos na execução do Assessment Técnico:
Reuniões de mapeamento com os 5 a 6 profissionais responsáveis pela execução do processo;
Limitado a 6 reuniões de mapeamento de aproximadamente 1 hora cada.

Entendimento do fluxograma (mapeamento e modelagem AS IS):
Atividades e atores que participam nos processos da área;;
Qual a duração estimada e ordem dos processos;
Comunicação entre as equipes e canais de informação.

Entregável de Valor:  Fluxos construídos e validados pelos stakeholders.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 8 -->

Etapa 2 - Mapeamento AS-IS dos processos

VALIDAÇÃO
MAPEAMENTO
Validar o mapeamento de um processo com os gestores da área garante maior assertividade nas análises e documentação.
O mapeamento permite a consolidação de processos e análise mais assertiva da execução das atividades do dia a dia da empresa.

FERRAMENTA UTILIZADA

Já utilizamos plataformas como Bizagi Modeler, Figma e Lucid Chart para a construção dos fluxogramas, permitindo a edição e facilidade de acesso, o que, por sua vez, permite a manutenção dos fluxos.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 9 -->
Etapa 3 - Identificação de gargalos e proposição de soluções

Objetivo Estratégico: orientar a proposição de soluções a partir da identificação de gaps, overlaps e dores nos processos mapeados.
Principais Atividades:

Após realização do mapeamento AS IS do processo:
Identificar os principais gaps, gargalos, oportunidades de automatização;
Uso de ferramentas como a Matriz de decisão, GUT, esforço X impacto , e a comparação entre processos através do custo da mão-de-obra para a priorização dos gargalos.
Desenvolvimento de soluções de curto, médio e longo prazo voltadas à padronização, otimização e ganho de eficiência na atuação da área. As soluções poderão contemplar desde recomendações de sistemas, iniciativas de automatização, aplicações de Inteligência Artificial, até ajustes estruturais, como a melhoria de fluxos de comunicação e de governança, sem necessariamente envolver a adoção de ferramentas externas. Todas as recomendações serão devidamente detalhadas e reportadas com o apoio da matriz 5W2H, visando facilitar a priorização e a implementação.

Entregável de Valor:  Consolidado com gargalos e gaps identificados e priorizados, além de planos de ação 5W2H para os pontos priorizados.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 10 -->

Etapa 3 - Identificação de gargalos e proposição de soluções

PRIORIZAÇÃO DE GARGALOS
IDENTIFICAÇÃO DE GARGALOS
Priorizar os gargalos que possuem maior impacto  nos objetivos estratégicos da empresa possibilita maior direcionamento dos planos de ação e uso dos recursos.
Entrevistas com analistas e colaboradores envolvidos nos processos mapeados, visando o entendimento das dores do dia-a-dia e fluxos das informações entre as áreas.
FERRAMENTAS UTILIZADAS
Processos manuais e burocráticos;
Meios de comunicação ineficazes;
Má gestão de tempo;
Processos despadronizados;
Pouca documentação das atividades;
Falta de métricas e indicadores de performance.
Matriz GUT;
Diagramas de Ishikawa;
Matriz Esforço X Impacto;
Análises de Custo X Benefícios.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 11 -->

Etapa 3 - Identificação de gargalos e proposição de soluções

Entrega: Gargalos e Soluções

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 12 -->

Etapa 3 - Identificação de gargalos e proposição de soluções

Entrega: Diagrama de Solução

![](GoogleShape368p24.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 13 -->

Etapa 3 - Identificação de gargalos e proposição de soluções

Entrega: Initiative Charter

![](GoogleShape382p25.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 14 -->

Etapa 4 - Mapeamento TO-BE dos processos
Objetivo Estratégico: Garantir eficiência, padronização e excelência operacional por meio do redesenho dos processos futuros (TO BE).
Principais Atividades:

Estruturação dos novos processos (modelagem TO-BE):
Construção dos processos ideais visando sua otimização, padronização e clareza, facilitando a visualização e o conhecimento dos gestores;
Elaborar um mapeamento com os processos revisados, otimizados e sustentáveis, garantindo adesão dos quick wins identificados no novo procedimento padrão.

Garantir uma melhor execução do processo, aproveitando oportunidades, mitigando erros e perdas de material, tornando os processos mais fluidos e leves.

Entregável de Valor: novos mapeamentos com a correção dos principais gaps, overlaps e problemas percebidos.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 15 -->

Etapa 4 - Mapeamento TO BE dos processos

Entrega 4: Fluxos redesenhados

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 16 -->

Etapa 5 - Elaboração de manuais
Objetivo Estratégico: transformar conhecimento tácito em conhecimento institucional, assegurando eficiência, qualidade e continuidade dos resultados.
Principais Atividades:

Desenvolvimento de manuais e/ou documentos POPs das atividades do seu formato mais otimizado (TO BE):
Passo a passo detalhado do processo;
Fluxograma das etapas;
Ferramentas utilizadas;
Glossário com siglas, caso necessário.

Conferência de uma estrutura que garanta a qualidade das entregas - mesmo com a possível troca de funcionários - a regulamentação dos processos, aprofundamento de atividades e facilidade do acesso pelos colaboradores;

Entregável de Valor: manuais padronizados e validados, com material de boas práticas, prontos para uso e disseminação interna.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 17 -->

Etapa 5 - Elaboração de manuais

Entrega: POPS

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 18 -->

Etapa 6 - Manual Conversacional
Objetivo Estratégico: transformar a documentação e o mapeamento de processos em suporte inteligente à operação diária.
Principais Atividades:

Estruturação de um assistente chatbot de IA para direcionar as principais dúvidas e respostas frequentes no processo, a partir dos dados e inputs obtidos nas etapas de mapeamento, além do direcionamento das equipes envolvidas;

Alimentar e treinar o chatbot com o uso das informações coletadas ao longo do projeto, direcionando os outputs assertivos para cada situação específica da operação;

Treinamento de um modelo com fácil usabilidade para o contexto da empresa, rompendo eventuais barreiras técnicas.

Entregável de Valor: Assistente virtual de IA operacional, configurado e treinado, integrado aos processos da Sotreq com foco em dúvidas frequentes, direcionamento de atividades e apoio à tomada de decisão operacional.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 19 -->

Etapa 6 - Manual Conversacional

Entrega: ChatBot

![](GoogleShape485p31.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 20 -->

Etapa 7 - Documentação Final
Objetivo Estratégico: consolidar todo o estudo e as entregas realizadas em um formato de fácil acesso e disseminação para a equipe da Sotreq.
Principais Atividades:

Estruturação de uma documentação executiva contendo as principais entregas e análises do projeto de forma enxuta;

Criação de um site específico e personalizado para uso interno da Sotreq contendo os documentos produzidos pela equipe da Poli Júnior e formatado de forma intuitiva para fácil usabilidade.

Entregável de Valor: documentação executiva e site personalizado para a Sotreq.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 21 -->

Etapa 7 - Documentação Final

Entrega: Repositório Online

![](GoogleShape523p33.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 22 -->

Entregas Principais

![](GoogleShape542p34.jpg)

Mapeamentos AS IS e TO BE dos processos com a identificação de gargalos, suas priorizações e soluções propostas.
Documentação final do projeto, com a consolidação da forma otimizada e padronizada e, um site personalizado a ser seguida nas áreas estudadas.
Manuais e POPs de execução do processo em sua forma ideal, integrados a um Assistente Inteligente, orientando os colaboradores na realização otimizada dos fluxos.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 23 -->

![](GoogleShape580p35.jpg)

![](GoogleShape581p35.jpg)

![](GoogleShape579p35.jpg)

Benefícios
Dimensão
Cenário Atual
Cenário Futuro
Impacto
Processos mapeados, estruturados e validados, com visão ponta a ponta da operação, maior clareza dos gaps que devem ser priorizados a fim de atingir a otimização desejada.
Processos executados sem documentação formal consolidada, com baixa visibilidade estruturada dos problemas, causando diversos retrabalhos e atividades manuais
No case da Gerdau, a identificação e priorização assertiva dos gargalos, permitiu a otimização de processos que gerou economia anual estimada de R$1,90 milhão.

Eficiência Operacional

![](GoogleShape573p35.jpg)
No projeto com o Grupo Bravante, foram documentados mais de 30 processos, disseminando o conhecimento dos processos otimizados e deixando a operação mais fluida.
Conhecimento institucionalizado por meio de documentação estruturada e centralizada, com material acessível e apoio tecnológico integrado, garantindo continuidade, autonomia do time e escalabilidade da área.

Gestão do Conhecimento e Sustentabilidade dos Processos
Conhecimento concentrado na vivência prática da equipe, com risco de perda de informação e necessidade recorrente de alinhamentos operacionais.

![](GoogleShape574p35.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 24 -->

![](GoogleShape604p36.jpg)

![](GoogleShape605p36.jpg)

![](GoogleShape603p36.jpg)

Equipe Dedicada ao Projeto e Parceria
2 Consultores por 7 semanas
Graduandos Engenheiros Politécnicos da USP da área de Gestão Empresarial e Consultoria da Poli Júnior
1 Coordenador
Membro sênior de projetos da área na empresa
Como será nossa parceria?
Serão realizados reports semanais entre os stakeholders e a equipe para alinhamentos sobre os pontos de atuação e revisão dos resultados;
Os stakeholders colaboram facilitando os insumos necessários (como acesso a documentos e contatos) e com a validação das entregas;
Serão realizadas constantes consultas de experiência e satisfação no decorrer da execução e após sua implementação.
A Poli Júnior se propõe a realizar termos aditivos para contratação de serviços adicionais.

### Notes:

<!-- Slide number: 25 -->

Cases de Sucesso

![](GoogleShape616p37.jpg)

### Notes:

<!-- Slide number: 26 -->
Eletromidia
PROBLEMA
SOLUÇÃO
Gestão de Processos

A empresa enfrentava dificuldades na padronização e eficiência dos processos operacionais, especialmente na gestão e manutenção de ativos distribuídos em diferentes regiões.
 A falta de integração entre sistemas e de visibilidade sobre o funcionamento dos equipamentos gerava falhas operacionais, atrasos em campanhas e perdas financeiras recorrentes, comprometendo o nível de serviço prestado.

A equipe realizou o mapeamento completo dos processos, identificando gargalos críticos e propondo soluções de integração e automação.
 Foram estruturados fluxogramas “AS-IS” e “TO-BE”, análises financeiras e planos de ação priorizados via matrizes de esforço e impacto, visando melhorar a comunicação entre áreas, otimizar o atendimento técnico e reduzir falhas nos ativos.

IMPACTO

As soluções implementadas trouxeram maior eficiência operacional, redução de custos e padronização dos processos internos. Com a integração e automatização das atividades, foi estimada uma economia anual de R$ 1,58 milhão, considerando a quase eliminação dos casos de overbooking e a redução de 50% nas perdas financeiras por falhas operacionais e erros de agência.

### Notes:

<!-- Slide number: 27 -->
Banco Pine
PROBLEMA
SOLUÇÃO
Gestão de Processos

Mapeamento e identificação de gargalos, alcançando algumas quick wins, como a automatização de
tarefas em planilhas e ajustes na comunicação entre as áreas. Por fim, documentação do fluxograma
realizado com mais de 120 funcionários (As Is) e modelo que deverá ser implementado (To Be).

Dificuldade na área de fechamento contábil por falta de padronização dos processos internos,
atividades manuais e falha de comunicação entre as áreas, causando reprocessamentos contábeis em grande escala e atrasos.
IMPACTO

Implementação de metodologias ágeis para a realização dos processos, proporcionando redução de aproximadamente 50% no tempo de execução dos processos de Fechamento Contábil.

### Notes:

<!-- Slide number: 28 -->

![](GoogleShape740p40.jpg)

![](GoogleShape741p40.jpg)

![](GoogleShape738p40.jpg)

Proposta Comercial

![](GoogleShape742p40.jpg)

EQUIPE
DURAÇÃO
INVESTIMENTO

2 Consultores
1 Coordenador

7 semanas
R$28.000,00
Pagamento: Cartão, Boleto ou Transferência | Em até 4x com parcelas a serem pagas nos Dia 10, 20 ou 30 do mês

### Notes:

<!-- Slide number: 29 -->

![](GoogleShape754p41.jpg)

![](GoogleShape755p41.jpg)

![](GoogleShape753p41.jpg)

Esclarecimentos Comerciais
Nossa minuta padrão contratual - que engloba questões jurídicas como garantias, deveres e responsabilidades, entre outras informações - está disponível neste link.

O CNAE (Classificação Nacional de Atividades Econômicas) da Poli Júnior, a empresa júnior da Escola Politécnica da USP, é 7112-0/00 - Serviços de Engenharia. Essa classificação engloba atividades como consultoria, projetos e outros serviços relacionados à engenharia.

Pareceres: Nossa proposta está em conformidade com a legislação aplicável e nos comprometemos com a qualidade do projeto - assim como para todos nossos clientes. Estamos disponíveis para tiragens de dúvidas durante todo o contato (dados ao final do documento).

Em caso de necessidade de números de contas bancárias, estatuto social, cartão CNPJ, Inscrição Municipal ou outras questões, entrar em contato.

Nosso valor engloba todos os custos estabelecidos pelo projeto, incluindo impostos.

### Notes:

<!-- Slide number: 30 -->

![](GoogleShape768p42.jpg)

![](GoogleShape769p42.jpg)

![](GoogleShape767p42.jpg)

Esclarecimentos Comerciais
Para esta proposta comercial, são válidas as seguintes condições:

No decorrer do projeto, serão realizadas reuniões entre a equipe da Poli Júnior e o cliente para coleta de dados, discussão do andamento do projeto e apresentação de resultados – o cliente se compromete em ter disponibilidade para tais encontros e troca de informações;
As atividades têm início e fim a partir das datas que serão estabelecidas no contrato, documento elaborado mediante a aprovação desta proposta por ambas as partes, Poli Júnior e cliente;
As informações contidas nesta proposta são confidenciais, não devendo ser utilizadas ou apresentadas por qualquer outra pessoa sem o consentimento de ambas as partes;
A equipe da Poli Júnior não trabalhará durante as semanas de prova da Escola Politécnica;
Essa proposta comercial possui validade de 1 mês a contar da data de sua apresentação 09/06/2026;
O projeto poderá ser iniciado 15 dias úteis após a assinatura do contrato;
A contratante deve agir com respeito a todos os envolvidos no serviço em questão, sob pena de rescisão do contrato;
Serão realizadas coletas de satisfação em relação ao projeto no decorrer da execução e ao final do projeto;
No caso de atraso no pagamento de até 10 dias úteis, o projeto será congelado, com retomada prevista em até 5 dias úteis após o devido pagamento ter sido realizado.

### Notes:

<!-- Slide number: 31 -->

![](GoogleShape805p43.jpg)

![](GoogleShape829p43.jpg)

![](GoogleShape804p43.jpg)

Nosso Contato e Próximos Passos

Gabriel Beyruti

Davi Holanda

Coordenador de Negócios

Consultor de Negócios

gabriel.beyruti@polijunior.com.br

davi.holanda@polijunior.com.br

11 97561-6380

85 99950-8676

Próximos Passos:
Aprovação Verbal
Validação jurídica da minuta contratual
Assinatura do contrato pelos representantes

### Notes:
