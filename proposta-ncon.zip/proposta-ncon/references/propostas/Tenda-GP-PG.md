<!-- Slide number: 1 -->

Estruturação da Implementação do Novo Sistema de Viabilidade
Financeira

Proposta de Parceria
23 de Julho, 2026

![](GoogleShape176p25.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 2 -->

Poli Júnior - Empresa Júnior da Escola Politécnica da USP

A Poli Júnior é uma instituição constituída por alunos de Graduação da Escola Politécnica de Engenharia da USP.

Localizados na melhor faculdade de engenharia da América Latina, seu projeto é impulsionado pelo mais alto rigor e talentos da Escola Politécnica, garantindo o que há de mais inovador em tecnologias, resultando em soluções ágeis e criativas. Além disso, criando uma forte conexão da empresa com a POLI-USP.

Nossa excelência e agilidade é refinada por treinamentos e parcerias com as maiores consultorias do mundo visando aplicar o mesmo padrão de excelência e pensamento estratégico em nossos projetos.

1º
+1100
90%
lugar
entre as Empresas Juniores do Brasil
Projetos concluídos
Índice de Satisfação
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 3 -->

Quem conta com as soluções da Poli Júnior

![](GoogleShape246p27.jpg)

### Notes:

<!-- Slide number: 4 -->

![](GoogleShape275p28.jpg)

Sumário - Nosso Entendimento do Seu Contexto e Objetivos

Recomendamos a estruturação da transição para o novo sistema de viabilidade financeira — processos, papéis, ritos, manuais e um chatbot de suporte,  para que a implementação ganhe tração sem sobrecarregar a equipe.

Contexto:
A área de Inteligência de Mercado e Estudos Econômicos conduz as análises de viabilidade financeira dos empreendimentos da Tenda, hoje em Excel, com projetos entrando toda semana e 20 a 30 usuários em 9 regionais.
Um novo sistema, contratado para substituir a planilha, está em fase de testes, mas a implementação avança devagar: a equipe central é reduzida (5 pessoas), os processos e diretrizes mapeados ainda não incluem o sistema, e os treinamentos atuais (PDFs, vídeos e sessões a cada 2 meses) não sustentam a adoção. Na prática, os usuários recorrem à equipe por telefone, gerando retrabalho, rechecagens e sobrecarga.

Entregas frequentes que geram valor rápido
Conexão com a USP e talentos da Escola Politécnica

Projetos que integram otimização e tecnologias inovadoras à sua empresa
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 5 -->

![](GoogleShape303p29.jpg)

Principais objetivos da Tenda

Objetivos:
Estruturar a transição do Excel para o novo sistema de viabilidade, mapeando os processos atuais (AS IS) e redesenhando os fluxos no padrão da nova ferramenta (TO BE), eliminando retrabalho e rechecagens.

"Nossa maior dificuldade é na implementação dessa ferramenta."
Dar clareza de papéis, responsabilidades e ritos sobre os fluxos redesenhados, definindo quem executa, valida e aprova cada atividade, sem sobrecarregar a equipe central.

Institucionalizar o conhecimento da operação em manuais e POPs consultáveis e em um chatbot de IA alimentado por eles, substituindo os treinamentos dispersos e o suporte por telefone.

Consolidar a implementação em um plano acionável, com diagrama de Gantt, sequência de rollout nas 9 regionais e marcos de desligamento do Excel.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 6 -->

Cronograma do projeto - Consultoria

Imersão no contexto e Diagnóstico de Maturidade
Papéis e Responsabilidades
Mapeamento TO BE
Mapeamento AS IS

Entrega 1
Entrega 2
Entrega 3
Entrega 4
Semanas 2
Semana 3-4
Semana 1
Semana 5

Redesenhar os fluxos incorporando o novo sistema.

Mapear os fluxos de trabalho como são realizados hoje.

Entender o sistema, o Excel atual e diagnosticar a maturidade da implementação.

Clareza de quem executa, valida e aprova no fluxo novo.

### Notes:

<!-- Slide number: 7 -->

Cronograma do projeto - Consultoria

Plano de Implementação e Documentação Final
Desenvolvimento de ChatBOT
Manuais e POPs
Reuniões e Ritos

Entrega 1
Entrega 2
Entrega 3
Entrega 4
Semanas 7
Semana 8
Semana 6
Semana 9

ChatBOT de IA de suporte aos usuários, alimentado pelos manuais.

Manuais e POPs do novo sistema, substituindo PDFs e vídeos dispersos.

Ritos de rollout, acompanhamento e suporte.

Plano de implementação (Gantt), doc. executiva e repositório online.

### Notes:

<!-- Slide number: 8 -->

Etapa 1.1 - Imersão e Diagnóstico
Objetivo Estratégico: alinhar os principais pontos do projeto e compreender o funcionamento atual da viabilidade financeira, o novo sistema em fase de testes e o contexto de uso nas regionais.
Principais Atividades:

Realização do kickoff com a equipe da Tenda: definição dos pontos focais da equipe central e das regionais, expectativas e alinhamentos iniciais;

Entendimento aprofundado do novo sistema (funcionalidades, inputs e status da fase de testes) e da planilha de viabilidade que ele substitui, incluindo as customizações construídas ao longo do tempo;

Agendamento das reuniões de mapeamento e dos reports semanais, adequado à rotina e à disponibilidade da equipe.

Entregável de Valor:  elaboração do Canvas de Escopo e Cronograma do projeto.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 9 -->

Etapa 1.2 - Imersão e Diagnóstico

Objetivo Estratégico: mapear a estrutura atual da área, evidenciando papéis, hierarquias e o que é executado internamente ou por terceiros.
Principais Atividades: Organograma AS IS

Reuniões para levantamento da estrutura organizacional atual;

Elaboração do organograma AS IS no Lucidspark, destacando cargos, hierarquias e as funções prestadas por serviços externos;

Entregável de Valor: organograma AS IS estruturado, refletindo a estrutura real da área, incluindo o que é interno e o que é terceirizado.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 10 -->

Etapa 1.3 - Imersão e Diagnóstico
Objetivo Estratégico: retratar o cenário atual da implementação, mapeando como adoção, processos, treinamentos e suporte funcionam hoje em cada regional, para servir de base às próximas etapas.
Principais Atividades: Matriz Diagnóstico AS IS

Condução de reuniões com o gestor e a equipe central para mapear o cenário AS IS das principais dimensões da transição (adoção do sistema, processos e diretrizes, materiais de treinamento e dúvidas recorrentes);

Consolidação das informações na Matriz Diagnóstico AS IS, estruturada por dimensão e por regional;

Identificação dos principais pontos de atenção que travam a implementação hoje, priorizando o que será endereçado nas etapas seguintes.

Entregável de Valor: Matriz Diagnóstico AS IS, consolidando o retrato real da implementação em cada regional.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 11 -->

Apêndice 1.3 - Diagnóstico de Maturidade de Governança

Entregável de Valor: Matriz Diagnóstico AS IS

![](GoogleShape461p35.jpg)

![](GoogleShape462p35.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 12 -->

Etapa 2 - Mapeamento AS-IS dos processos
Objetivo Estratégico: construir os fluxogramas dos processos atuais da operação de viabilidade financeira, que servirão de base para a padronização e o redesenho orientado à transição ao novo sistema.
Principais Atividades:

Realização de entrevistas com responsáveis e envolvidos nos processos:
Reuniões de mapeamento com os principais colaboradores da equipe central e das regionais, capturando o passo a passo real das análises de viabilidade;
Limitado a 6 reuniões de mapeamento de 1 hora cada.

Entendimento do fluxograma (mapeamento e modelagem AS IS):
Atividades e atores que participam dos processos da área;
Identificação das construções customizadas da planilha e das etapas manuais de conferência e rechecagem;
Comunicação entre áreas, fontes de dados e canais de informação;

Entregável de Valor:  Fluxos construídos e validados pelos stakeholders.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 13 -->

Etapa 2 - Mapeamento AS-IS dos processos

VALIDAÇÃO
MAPEAMENTO
Validar o mapeamento de um processo com os gestores da área garante maior assertividade nas análises e documentação.
O mapeamento permite a consolidação de processos e análise mais assertiva da execução das atividades do dia a dia da empresa.

FERRAMENTA UTILIZADA

Já utilizamos plataformas como Bizagi Modeler, Figma e Lucid Chart para a construção dos fluxogramas, permitindo a edição e facilidade de acesso, o que, por sua vez, permite a manutenção dos fluxos.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 14 -->

Etapa 3 - Mapeamento TO BE
Objetivo Estratégico: garantir padronização e maturidade operacional por meio do redesenho dos processos futuros (TO BE), já estruturados para a transição da operação ao novo sistema de viabilidade.
Principais Atividades:

Estruturação dos novos processos (modelagem TO-BE):
Construção dos processos ideais visando padronização e clareza, substituindo as construções e conferências manuais da planilha por fluxos estruturados no padrão do novo sistema;
Redesenho dos fluxos com a eliminação das etapas de retrabalho e rechecagem identificadas no AS IS, deixando os fluxos mais inteligentes e transparentes;
Definição das informações e análises que a operação passará a consumir a partir do sistema, e do que sai do Excel em cada momento da transição.

Garantir uma execução mais consistente, reduzindo a dependência do conhecimento individual e padronizando o método de trabalho entre os analistas.

Entregável de Valor: Novos mapeamentos com a correção dos principais gaps, prontos para orientar a transição ao sistema
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 15 -->

Etapa 3 - Mapeamento TO BE

Entrega: Fluxos redesenhados

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 16 -->

Etapa 4.1 - Papéis e Responsabilidades
Objetivo Estratégico: identificar e priorizar os gargalos de atribuição de funções, verificando se há clareza sobre quem executa, decide, valida e acompanha cada atividade dos fluxos redesenhados.
Principais Atividades: Identificação de Gargalos e Matriz RACI

Reuniões com o gestor para analisar a divisão de responsabilidades entre equipe central e regionais sobre os fluxos TO BE;

Identificação dos gargalos de clareza no escopo e nas responsabilidades de cada função, incluindo o suporte de primeiro nível ao novo sistema em cada regional;

Construção da Matriz RACI, formalizando quem executa, decide, é consultado e é informado em cada atividade do novo fluxo.

Entregável de Valor: gargalos de atribuição de funções identificados e Matriz RACI estruturada sobre os fluxos redesenhados.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 17 -->

Etapa 4.2 - Papéis e Responsabilidades
Objetivo Estratégico: consolidar as melhorias de responsabilidades em um documento executivo, garantindo maior clareza na governança e na coordenação entre áreas.
Principais Atividades: Playbook de Papéis e Funções

Definição das melhorias na estrutura de responsabilidades com base nos gargalos priorizados

Preenchimento do Playbook de Papéis e Funções consolidando as propostas de solução

Entregável de Valor: Playbook de Papéis e Funções com as responsabilidades formalizadas e as melhorias propostas documentadas.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 18 -->

Etapa 5.1 - Reuniões e Ritos
Objetivo Estratégico: identificar os gargalos na estrutura e no funcionamento dos ritos e reestruturá-los para garantir maior padronização, previsibilidade e eficiência no rollout do sistema.
Principais Atividades: Identificação de Gargalos e Reestruturação de Ritos

Reuniões com o gestor para analisar os ritos existentes entre a equipe central e as regionais;

Verificação de gargalos como ausência de objetivo claro, falta de registro de decisões, frequência inadequada e ausência de acompanhamento pós-reunião;

Definição das melhorias com base nos gargalos identificados, podendo envolver criação de novos ritos, ajuste de periodicidade, redefinição de agendas, padronização das dinâmicas e estruturação dos ritos de rollout, dúvidas e suporte, substituindo a lógica de treinamentos a cada 2 meses.

Entregável de Valor: gargalos de ritos identificados e estrutura de ritos reestruturada com as melhorias propostas.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 19 -->

Etapa 5.2 - Reuniões e Ritos
Objetivo Estratégico: consolidar as melhorias na estrutura de ritos em um documento executivo, garantindo maior padronização, previsibilidade e eficiência na tomada de decisão da área.
Principais Atividades: Playbook de Ritos

Preenchimento do Playbook de Ritos consolidando as propostas de solução definidas

Formalização da estrutura de reuniões, com objetivos, periodicidade, agendas e dinâmicas padronizadas

Entregável de Valor: Playbook de Ritos com a estrutura de reuniões formalizada e as melhorias propostas documentadas.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 20 -->

Etapa 5.2 - Reuniões e Ritos

Entregável de Valor:  Página online de armazenamento de ritos.

![](GoogleShape639p44.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 21 -->

Etapa 6 - Elaboração de manuais
Objetivo Estratégico: transformar conhecimento tácito em conhecimento institucional, assegurando eficiência, qualidade e continuidade dos resultados.
Principais Atividades:

Desenvolvimento de manuais e/ou documentos POPs das atividades do seu formato mais otimizado (TO BE):
Passo a passo detalhado do processo;
Fluxograma das etapas;
Ferramentas utilizadas;
Glossário com siglas, caso necessário.

Conferência de uma estrutura que garanta a qualidade das entregas - mesmo com a possível troca de funcionários - a regulamentação dos processos, aprofundamento de atividades e facilidade do acesso pelos colaboradores;

Entregável de Valor: manuais padronizados e validados, com material de boas práticas, prontos para uso e disseminação interna.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 22 -->

Etapa 6 - Elaboração de manuais

Entrega: POPS

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 23 -->

Etapa 7 - Manual Conversacional
Objetivo Estratégico: transformar a documentação e o mapeamento de processos em suporte inteligente à operação diária.
Principais Atividades:

Estruturação de um assistente chatbot de IA para direcionar as principais dúvidas e respostas frequentes no processo, a partir dos dados e inputs obtidos nas etapas de mapeamento, além do direcionamento das equipes envolvidas;

Alimentar e treinar o chatbot com o uso das informações coletadas ao longo do projeto, direcionando os outputs assertivos para cada situação específica da operação;

Treinamento de um modelo com fácil usabilidade para o contexto da empresa, rompendo eventuais barreiras técnicas.

Entregável de Valor: Assistente virtual de IA operacional, configurado e treinado, integrado aos processos da Sotreq com foco em dúvidas frequentes, direcionamento de atividades e apoio à tomada de decisão operacional.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 24 -->

Etapa 7 - Manual Conversacional

Entrega: ChatBot

![](GoogleShape708p48.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 25 -->

Etapa 8 - Plano de Implementação e Documentação Final
Objetivo Estratégico: consolidar as entregas do projeto em um plano de implementação acionável e em uma documentação de fácil acesso e disseminação para a equipe da Tenda.
Principais Atividades:

Construção do plano de implementação do novo sistema, consolidando o roadmap definido no TO BE:
Diagrama de Gantt com a sequência de rollout por regional, atividades, responsáveis e prazos;
Marcos de transição e critérios de desligamento do Excel em cada frente da operação;
Priorização das ações com base no diagnóstico de maturidade e nos gargalos mapeados.

Estruturação de uma documentação executiva contendo as principais entregas e análises do projeto de forma enxuta;

Criação de um site específico e personalizado para uso interno da Tenda, com todos os documentos produzidos pela equipe da Poli Júnior organizados de forma intuitiva;

Entregável de Valor: Plano de implementação em Diagrama de Gantt, documentação executiva e repositório online personalizado para a Tenda.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 26 -->

Etapa 8 - Plano de Implementação e Documentação Final

Entrega: Repositório Online

![](GoogleShape750p50.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 27 -->

Etapa 8 - Plano de Implementação e Documentação Final

Entrega: Repositório Online

![](GoogleShape764p51.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 28 -->

![](GoogleShape786p52.jpg)

Equipe Dedicada ao Projeto e Parceria
2 Consultores por 9  semanas
Graduandos Engenheiros Politécnicos da USP da área de Gestão Empresarial e Consultoria da Poli Júnior

1 Coordenador
Membro sênior de projetos da área na empresa
Como será nossa parceria?
Serão realizados reports semanais entre os stakeholders e a equipe para alinhamentos sobre os pontos de atuação e revisão dos resultados;
Os stakeholders colaboram facilitando os insumos necessários (como acesso a documentos e contatos) e com a validação das entregas;
Serão realizadas constantes consultas de experiência e satisfação no decorrer da execução e após sua implementação.
A Poli Júnior se propõe a realizar termos aditivos para contratação de serviços adicionais.

### Notes:

<!-- Slide number: 29 -->

Cases de Sucesso

![](GoogleShape797p53.jpg)

### Notes:

<!-- Slide number: 30 -->
PROBLEMA
SOLUÇÃO
Grupo EPR

Performance & Governança
O Grupo EPR possui verba anual destinada à inovação, porém sua gestão ocorria de forma descentralizada e pouco estruturada. Cada unidade conduzia iniciativas de maneira independente, sem processos, ritos ou diretrizes comuns, gerando retrabalho, repetição de erros e baixa eficiência no uso dos recursos. Além disso, a ausência de uma área responsável pela coordenação reduzia a visibilidade sobre os projetos e dificultava o acompanhamento estratégico, e a empresa ainda enfrentava o risco de penalidades tarifárias.
A equipe estruturou do zero a área de Inovação do Grupo  EPR, definindo escopo, governança e ritos de funcionamento da área. Foram mapeados e organizados os macro e microprocessos de inovação, estabelecendo fluxos claros para desenvolvimento e acompanhamento das iniciativas, em conjunto com a sponsor do projeto. Além disso, foram realizados estudos de potenciais parceiros e investidores, ampliando as possibilidades de conexão da EPR com o ecossistema de inovação.

.

![](GoogleShape839p54.jpg)
IMPACTO

A estruturação da área permitiu maior alinhamento e comunicação entre as unidades, reduzindo inconsistências e retrabalhos nas iniciativas de inovação. Como resultado, a empresa fortaleceu seu posicionamento como organização inovadora, além de promover maior organização interna e eficiência na gestão das iniciativas, contribuindo para o desenvolvimento estratégico da companhia.

### Notes:

<!-- Slide number: 31 -->
PROBLEMA
SOLUÇÃO
Pernambucanas

Gestão de Processos
A equipe estudou os papéis e responsabilidades, os ritos existentes, indicadores acompanhados e pontos recorrentes de travamento. Em seguida, estruturou uma Arquitetura de Decisões, Métricas e Ritos, definindo quais decisões a área precisa tomar, quais métricas sustentam essas decisões e como cada rito deve funcionar. Por fim, foram propostos ajustes de estrutura e interfaces entre times para reduzir dependência de validações centralizadas e aumentar clareza de responsabilidades.

A Pernambucanas apresentava dificuldades na governança da operação fiscal e financeira, com controle distribuído entre diferentes sistemas e planilhas, o que reduzia a visibilidade e a confiabilidade das informações. Na prática, a área operava com ritos de acompanhamento pouco padronizados e com critérios de decisão inconsistentes, gerando retrabalho, atrasos em validações/aprovações e baixa previsibilidade sobre prazos e pendências.

IMPACTO

As propostas permitiram tornar o acompanhamento fiscal-financeiro mais previsível e rastreável, com cadência de gestão mais resolutiva, redução de retrabalho por falta de alinhamento e maior consistência na tomada de decisão. Com isso, a área ganhou agilidade, segurança e controle, sustentando uma operação mais confiável mesmo em um contexto de alta complexidade tributária.

### Notes:

<!-- Slide number: 32 -->

![](GoogleShape925p56.jpg)

Proposta Comercial
Proposta Comercial

![](GoogleShape924p56.jpg)

EQUIPE
DURAÇÃO
INVESTIMENTO

2 Consultores
1 Coordenador

R$ 41.400,00
09 semanas
Cartão, boleto ou transferência. Parcelamento em até 4x.
Pagamento:

### Notes:

<!-- Slide number: 33 -->

![](GoogleShape936p57.jpg)

Esclarecimentos Comerciais
Nossa minuta padrão contratual - que engloba questões jurídicas como garantias, deveres e responsabilidades, entre outras informações - está disponível neste link.

O CNAE (Classificação Nacional de Atividades Econômicas) da Poli Júnior, a empresa júnior da Escola Politécnica da USP, é 7112-0/00 - Serviços de Engenharia. Essa classificação engloba atividades como consultoria, projetos e outros serviços relacionados à engenharia.

Pareceres: Nossa proposta está em conformidade com a legislação aplicável e nos comprometemos com a qualidade do projeto - assim como para todos nossos clientes. Estamos disponíveis para tiragens de dúvidas durante todo o contato (dados ao final do documento).

Em caso de necessidade de números de contas bancárias, estatuto social, cartão CNPJ, Inscrição Municipal ou outras questões, entrar em contato.

Nosso valor engloba todos os custos estabelecidos pelo projeto, incluindo impostos.

### Notes:

<!-- Slide number: 34 -->

![](GoogleShape948p58.jpg)

Esclarecimentos Comerciais
Para esta proposta comercial, são válidas as seguintes condições:

No decorrer do projeto, serão realizadas reuniões entre a equipe da Poli Júnior e o cliente para coleta de dados, discussão do andamento do projeto e apresentação de resultados – o cliente se compromete em ter disponibilidade para tais encontros e troca de informações;
As atividades têm início e fim a partir das datas que serão estabelecidas no contrato, documento elaborado mediante a aprovação desta proposta por ambas as partes, Poli Júnior e cliente;
As informações contidas nesta proposta são confidenciais, não devendo ser utilizadas ou apresentadas por qualquer outra pessoa sem o consentimento de ambas as partes;
A equipe da Poli Júnior não trabalhará durante as semanas de prova da Escola Politécnica;
Essa proposta comercial possui validade de 1 mês a contar da data de sua apresentação 30/06/2026;
O projeto poderá ser iniciado 60 dias após a assinatura do contrato;
A contratante deve agir com respeito a todos os envolvidos no serviço em questão, sob pena de rescisão do contrato;
Serão realizadas coletas de satisfação em relação ao projeto no decorrer da execução e ao final do projeto;
No caso de atraso no pagamento de até 10 dias úteis, o projeto será congelado, com retomada prevista em até 5 dias úteis após o devido pagamento ter sido realizado.

### Notes:

<!-- Slide number: 35 -->

![](GoogleShape983p59.jpg)

Nosso Contato e Próximos Passos

João Lucas Castanheira

Gabriel Cury Beyruti

Consultor de Negócios

Coordenador de Negócios

joao.castanheira@polijunior.com.br

gabriel.beyruti@polijunior.com.br

62 99802-2007

11 97561-6380

Próximos Passos:
Aprovação Verbal até data estipulada
Validação jurídica da minuta contratual
Assinatura do contrato pelos representantes

### Notes:
