<!-- Slide number: 1 -->

Estruturação da governança para a área comercial da T4S com foco em profissionalização e resultado

Proposta de Parceria
17 de Junho, 2026

![](GoogleShape176p25.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 2 -->

Poli Júnior - Empresa Júnior da Escola Politécnica da USP

A Poli Júnior é uma instituição constituída por alunos de Graduação da Escola Politécnica de Engenharia da USP.

Localizados na melhor faculdade de engenharia da América Latina, seu projeto é impulsionado pelo mais alto rigor e talentos da Escola Politécnica, garantindo o que há de mais inovador em tecnologias, resultando em soluções ágeis e criativas. Além disso, criando uma forte conexão da empresa com a POLI-USP.

Nossa excelência e agilidade é refinada por treinamentos e parcerias com as maiores consultorias do mundo visando aplicar o mesmo padrão de excelência e pensamento estratégico em nossos projetos.

1º
+1100
90%
lugar
entre as Empresas Juniores do Brasil
Projetos concluídos
Índice de Satisfação
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 3 -->

Quem conta com as soluções da Poli Júnior

![](GoogleShape246p27.jpg)

### Notes:

<!-- Slide number: 4 -->

![](GoogleShape276p28.jpg)

Sumário - Nosso Entendimento do Seu Contexto e Objetivos
Uma Proposta para estruturar a governança da área comercial da T4S e profissionalizar a operação de vendas

Recomendamos a estruturação da governança comercial da T4S (organograma, papéis, ritos, indicadores e padronização das boas práticas de venda), visando uma operação mais previsível, escalável e menos dependente de pessoas-chave, capaz de sustentar o crescimento e a entrada de novas soluções como a Guardian Tower.
Contexto:
A T4S vive um momento de crescimento e de profissionalização da área comercial. À medida que a operação ganha escala e novas soluções entram no mercado, como a Guardian Tower, sustentar previsibilidade e consistência nos resultados passa a exigir uma estrutura comercial cada vez mais organizada. Quanto mais a área cresce, mais valor tem contar com papéis bem definidos, ritos de acompanhamento e indicadores que apoiem a tomada de decisão, além de um padrão de atuação comercial que possa ser replicado por todo o time e acompanhe a evolução da equipe. É nesse contexto que a Poli Júnior atua como um braço de estruturação da T4S, propondo e organizando os meios para que essa profissionalização ocorra de forma sustentável.

Entregas frequentes que geram valor rápido
Conexão com a USP e talentos da Escola Politécnica

Projetos que integram otimização e tecnologias inovadoras à sua empresa
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:
SOMENTE ENVIADO EM PDF

<!-- Slide number: 5 -->

![](GoogleShape304p29.jpg)

Principais objetivos da T4S

Objetivos:
Fortalecer a governança da área comercial, com papéis, ritos e indicadores claros que apoiem a tomada de decisão e acompanhem o crescimento.

"Precisamos que nossos vendedores apliquem o SPIN Selling e que a gente consiga medir isso no dia a dia."
Apoiar a profissionalização da operação de vendas, consolidando metodologias e boas práticas comerciais (como o SPIN Selling) em um padrão de atuação que possa ser replicado por toda a equipe.

Tornar a operação mais previsível e escalável, com clareza sobre quem executa, decide e valida cada atividade.

Organizar e documentar o conhecimento comercial, dando suporte à continuidade da operação, ao onboarding e à entrada de novas soluções, como a Guardian Tower.

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 6 -->

![](GoogleShape344p30.jpg)

Cronograma do projeto

Análise & Direcionamento
Imersão no contexto
Papéis e Responsabilidades

Benchmark de Referências Comerciais
Diagnóstico de Maturidade
Implementação do Fathom
Reuniões e Ritos

Entrega 1
Entrega 2
Entrega 3
Entrega 4
Entrega 5
Entrega 6
Semanas 1-3
Semana 5
Semana 4
Semana 6
Semana 7

Propor papéis, responsabilidades e hierarquias mais claros e organizados.

Estruturar e otimizar os ritos de gestão para mais eficiência e padronização.

Entender a estrutura, cultura e principais desafios da organização.

Avaliar o nível de maturidade da governança em estrutura, ritos e indicadores.

Implementar o Fathom para registrar e analisar as reuniões comerciais da área.

Estudar práticas comerciais de players de referência para embasar a estruturação da área.

### Notes:

<!-- Slide number: 7 -->

![](GoogleShape416p31.jpg)

Cronograma do projeto

Cultura e Engajamento
Gestão do Conhecimento

Plano de Implementação

Documentação Final
Indicadores

Entrega 7
Entrega 8
Entrega 9
Entrega 10
Entrega 11
Semana 11
Semana 9
Semana 10
Semana 12
Semana 8

Reestruturar os indicadores com foco em profissionalizar a operação comercial.

Consolidação de todas as análises e entregas.

Definir iniciativas, prioridades e um roadmap para implementação das melhorias.

Identificar e fortalecer fatores de cultura e engajamento dos colaboradores

Organizar o conhecimento comercial e estruturar o padrão de atuação da área.

### Notes:

<!-- Slide number: 8 -->

![](GoogleShape441p32.jpg)

Etapa 1 - Imersão no contexto
Semanas 1-3
Objetivo Estratégico: alinhar os principais pontos do projeto, garantindo conformidade entre as equipes da T4S e da Poli Júnior.
Principais Atividades:

Realização do kick-off com a equipe da T4S: definição dos pontos focais do projeto, expectativas da diretoria e alinhamentos iniciais;

Agendamento dos reports semanais e checkpoints para contato e alinhamento contínuo com a equipe da T4S.

Criação de um site específico e personalizado para uso interno da T4S contendo os documentos produzidos pela equipe da Poli Júnior e formatado de forma intuitiva para fácil usabilidade.

Entregável de Valor:  elaboração do Canvas de Escopo e Cronograma do projeto.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 9 -->

![](GoogleShape461p33.jpg)

Etapa 1 - Imersão no contexto

Semanas 1-3
Entrega: Repositório Online

![](GoogleShape458p33.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 10 -->

![](GoogleShape487p34.jpg)

Etapa 1.1 - Imersão no Contexto

Semanas 1-3

Objetivo Estratégico: capturar a percepção dos colaboradores sobre clima, cultura, governança e organização da empresa, complementando o diagnóstico com o olhar interno do time.
Principais Atividades: Pesquisa Organizacional

Reuniões com gestores para entender as especificidades do Cliente e estruturar o formulário;

Elaboração do formulário no Lucidspark para validação com o Cliente e no Google Forms para aplicação;

Orientação ao Cliente sobre a aplicação interna do formulário com os colaboradores;

Entregável de Valor: formulário organizacional validado e aplicado internamente, gerando insumos sobre clima, cultura e governança a partir da perspectiva dos colaboradores (rodagem feita pela própria empresa).
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 11 -->

Etapa 1.1 - Imersão no Contexto

Entregável de Valor: formulário organizacional

![](GoogleShape497p35.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 12 -->

![](GoogleShape526p36.jpg)

Etapa 1.2 - Imersão no Contexto
Semanas 1-3
Objetivo Estratégico: compreender como o valor é gerado ao longo da operação, identificando quais responsáveis e atividades compõem cada etapa do processo.
Principais Atividades: Cadeia de Valor

Entrevistas com gestores e lideranças da área Comercial para levantar as principais atividades realizadas e responsabilidades de cada uma;

Identificação de como cada responsabilidade contribui para a geração e entrega de valor;

Organização das atividades nas etapas correspondentes da cadeia de valor;

Entregável de Valor: cadeia de valor preenchida, ilustrando de forma estruturada como o valor é gerado ao longo do processo e quais responsabilidades participam de cada etapa.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 13 -->

![](GoogleShape549p37.jpg)

Etapa 1.3 - Imersão no Contexto

Semanas 1-3

Objetivo Estratégico: mapear a estrutura formal da área comercial, evidenciando cargos, hierarquias e conexões entre times como base para o diagnóstico.
Principais Atividades: Organograma AS IS

Reuniões com a alta gestão para levantamento da estrutura organizacional atual

Elaboração do organograma AS IS no Lucidspark, destacando cargos, hierarquias e conexões interáreas

Entregável de Valor: organograma AS IS estruturado no Lucidspark, refletindo a estrutura real da área com cargos, hierarquias e conexões entre times.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 14 -->

![](GoogleShape578p38.jpg)

Etapa 2.1 - Diagnóstico de Maturidade de Governança
Semanas 1-3

Objetivo Estratégico: compreender o nível de maturidade da governança da área/empresa, avaliando estrutura, ritos, indicadores, operações e cultura para identificar os principais pontos críticos e oportunidades de melhoria.
Principais Atividades: Formalização do Diagnóstico AS-IS

Condução de reuniões com gestores para mapear o cenário AS IS dos principais aspectos de governança;

Avaliação da maturidade de cada dimensão, identificando os pontos mais críticos para evolução.

Consolidação das informações em matrizes, estruturadas com abas para cada dimensão de governança analisada;

Desenvolvimento da Dashboard a partir da Pesquisa Organizacional e identificação das principais informações, padrões e gargalos observados ao longo do diagnóstico;

Entregável de Valor: Matriz Diagnóstico AS IS, MMG (Matriz de Maturidade de Governança) e Dashboard
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 15 -->

![](GoogleShape594p39.jpg)

Etapa 2.1 - Diagnóstico de Maturidade de Governança

Semanas 1-3

Entregável de Valor:  Dashboard consolidado com os dados obtidos na Pesquisa Organizacional.

![](GoogleShape583p39.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 16 -->

![](GoogleShape620p40.jpg)

Etapa 2.2 - Diagnóstico de Maturidade de Governança
Semanas 1-3

Objetivo Estratégico: apresentar o diagnóstico realizado para a equipe da T4S e entender os principais pontos de melhoria e objetivos nos próximos passos.
Principais Atividades: Avaliação de Requisitos

Apresentação dos dados coletados na pesquisa organizacional e nas reuniões de imersão;

Identificação das principais informações, padrões e gargalos observados ao longo do diagnóstico;

Entendimento dos principais requisitos e pontos de melhoria que a equipe da T4S planeja para a área.

Entregável de Valor: consolidado dos requisitos que fundamentarão a estruturação da área
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 17 -->

![](GoogleShape646p41.jpg)

Etapa 3 - Implementação do Fathom
Semana 4

Objetivo Estratégico: implementar uma ferramenta de registro e análise das reuniões comerciais (Fathom), criando a base de dados que permitirá à T4S medir, de forma objetiva, a aplicação das boas práticas de venda no dia a dia.
Principais Atividades: Implementação do Fathom

Reuniões com a liderança comercial para definir o que deve ser captado e analisado nas reuniões de venda (por exemplo, aplicação do SPIN Selling, definição de próximos passos e perfil das objeções);

Configuração da ferramenta de acordo com esses critérios, deixando-a pronta para uso pela equipe da T4S;

Disponibilização das contas para os vendedores da área, com o custo de uso coberto pela Poli Júnior nos dois primeiros meses

Entregável de Valor: Fathom implementado e configurado para os vendedores da área, gerando os dados que alimentarão os indicadores comerciais e a evolução do time.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 18 -->

![](GoogleShape662p42.jpg)

Etapa 3 - Implementação do Fathom

Semana 4

Entregável de Valor:  Fathom implementado e configurado para os vendedores da área

![](GoogleShape663p42.jpg)

Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 19 -->

![](GoogleShape689p43.jpg)

Etapa 4 - Benchmark de Referências Comerciais
Semana 5
Objetivo Estratégico: realizar um análise das principais práticas realizadas na área comerciais de players de referência do setor, entendendo quais as metodologias base, processos padrão, gargalos comuns e, principalmente, como a governança é estruturada.
Principais Atividades: Benchmark de Referências Comerciais

Identificação e contato com empresas que possuem a área comercial bem estruturada para estudo de caso e benchmark;

Mapeamento das características e destaques das empresas entrevistadas, com foco em:
Metodologias utilizadas;
Forma de treinamento da equipe;
Organograma da área;
Governança e Gestão do Conhecimento;
Indicadores chave utilizados.

Apresentação para a equipe da T4S dos dados obtidos para tomada de decisão acerca dos critérios mais relevantes que basearão os próximos passos

Entregável de Valor: Relatório com os dados obtidos e consolidado de critérios para os próximos passos
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 20 -->

![](GoogleShape718p44.jpg)

Etapa 5.1 - Papéis e Responsabilidades
Semana 6
Objetivo Estratégico: identificar os gargalos de atribuição de funções e propor uma estrutura organizacional otimizada, garantindo maior clareza de hierarquias e conexões entre áreas.
Principais Atividades: Identificação de Gargalos e Organograma TO BE

Reuniões com gestores para analisar ritos e processos da área

Identificação dos gargalos de clareza no escopo e nas responsabilidades de cada função

Elaboração do organograma TO BE no Lucidspark com base nos gargalos identificados

Definição de cargos, hierarquias, conexões interáreas e critérios de acompanhamento

Entregável de Valor: gargalos de atribuição de funções identificados e organograma TO BE estruturado no Lucidspark
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 21 -->

![](GoogleShape741p45.jpg)

Etapa 5.2 - Papéis e Responsabilidades
Semana 6
Objetivo Estratégico: consolidar as melhorias de responsabilidades em um documento executivo, garantindo maior clareza na governança e coordenação entre áreas.
Principais Atividades: Playbook de Papéis e Funções

Definição das melhorias na estrutura de responsabilidades com base nos gargalos priorizados

Preenchimento do Playbook de Papéis e Funções consolidando as propostas de solução

Entregável de Valor: Playbook de Papéis e Funções com as responsabilidades formalizadas e as melhorias propostas documentadas.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 22 -->

![](GoogleShape767p46.jpg)

Etapa 6.1 - Reuniões e Ritos
Semana 7
Objetivo Estratégico: identificar os gargalos na estrutura e funcionamento dos ritos e reestruturá-los para garantir maior padronização, previsibilidade e eficiência.
Principais Atividades: Identificação de Gargalos e Reestruturação de Ritos

Reuniões com gestores para analisar os ritos existentes;

Verificação de gargalos como ausência de objetivo claro, falta de registro de decisões, frequência inadequada e ausência de acompanhamento pós-reunião

Definição das melhorias com base nos gargalos identificados, podendo envolver criação de novos ritos, ajuste de periodicidade, redefinição de agendas e padronização das dinâmicas

Entregável de Valor: gargalos de ritos identificados e estrutura de ritos reestruturada com as melhorias propostas.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 23 -->

![](GoogleShape790p47.jpg)

Etapa 6.2 - Reuniões e Ritos
Semana 7
Objetivo Estratégico: consolidar as melhorias na estrutura de ritos em um documento executivo, garantindo maior padronização, previsibilidade e eficiência na tomada de decisão da área.
Principais Atividades: Playbook de Ritos

Preenchimento do Playbook de Ritos consolidando as propostas de solução definidas

Formalização da estrutura de reuniões, com objetivos, periodicidade, agendas e dinâmicas padronizadas

Entregável de Valor: Playbook de Ritos com a estrutura de reuniões formalizada e as melhorias propostas documentadas.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 24 -->

![](GoogleShape807p48.jpg)

Etapa 6.2 - Reuniões e Ritos
Semana 7

Entregável de Valor:  Página online de armazenamento de ritos.

![](GoogleShape802p48.jpg)
Exemplo de Playbook
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 25 -->

![](GoogleShape833p49.jpg)

Etapa 7.1 - Cultura e Engajamento
Semana 8
Objetivo Estratégico: identificar os gargalos de cultura e engajamento, propondo soluções direcionadas para cada um deles.
Principais Atividades: Identificação de gargalos e proposição de soluções

Organização dos gargalos de cultura identificados no Diagnóstico AS IS;

Elaboração de propostas de solução para gargalos como baixo senso de pertencimento, ausência de reconhecimento, resistência a mudanças e falta de cultura de feedback;

Adequar a cultura aos objetivos estratégicos da T4S.

Entregável de Valor: mapeamento dos gargalos de cultura e engajamento com propostas de solução para cada um.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 26 -->

![](GoogleShape862p50.jpg)

Etapa 7.2 - Cultura e Engajamento
Semana 8
Objetivo Estratégico: promover o crescimento individual e profissionalização dos colaboradores, alinhando desenvolvimento e desempenho às expectativas da liderança e da organização.
Principais Atividades: Plano de Desenvolvimento Individual

Alinhamento dos critérios de avaliação com a equipe da T4S;

Elaboração do questionário no Google Forms contemplando autoavaliação e avaliação dos membros;

Orientação ao Cliente sobre aplicação trimestral do PDI;

Consolidação das respostas no documento de PDI com geração automática de gráficos;

Entregável de Valor: PDI estruturado com acompanhamento periódico de desempenho e desenvolvimento individual de cada colaborador e fluxo de automação N8n para geração dos gráficos
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 27 -->

![](GoogleShape878p51.jpg)

Etapa 7.2 - Cultura e Engajamento
Semana 8

Entregável de Valor: Fluxo de automação N8n para geração dos gráficos

![](GoogleShape875p51.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 28 -->

![](GoogleShape893p52.jpg)

Etapa 7.2 - Cultura e Engajamento
Semana 8

Entregável de Valor: Fluxo de automação N8n para geração dos gráficos

![](GoogleShape894p52.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 29 -->

![](GoogleShape920p53.jpg)

Etapa 8 - Gestão do Conhecimento
Semana 9
Objetivo Estratégico: organizar o conhecimento comercial da T4S em um Playbook que padronize o atendimento de cada tipo de venda, conectando jobs to be done, perguntas de descoberta e soluções, e que evolua a partir dos dados das próprias reuniões.
Principais Atividades: Manual do Vendedor

Levantamento das boas práticas dos vendedores de melhor desempenho e das referências do benchmark, que servem de base para o conteúdo do Playbook

Estruturação do Playbook conectando jobs to be done, perguntas de situação, problema, implicação e necessidade de solução, e as soluções da T4S ligadas a cada um (incluindo a Guardian Tower)

Análise dos padrões das reuniões registradas no Fathom, transformando o que tende a funcionar (e onde costuma travar) em direcionamentos práticos dentro do Playbook, ligados a cada tipo de venda

Entregável de Valor: Playbook Comercial estruturado e conectado às reuniões reais, servindo de referência replicável para todo o time e que evolui com os dados da operação.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 30 -->

![](GoogleShape936p54.jpg)

Etapa 8 - Gestão do Conhecimento
Semana 9

Entregável de Valor:  Playbook Comercial

![](GoogleShape937p54.jpg)
Link para o Site de Exemplo
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 31 -->

![](GoogleShape963p55.jpg)

Etapa 9 - Indicadores
Semana 10
Objetivo Estratégico: reestruturar os indicadores da área com foco em profissionalizar a operação comercial, estabelecendo uma estrutura de métricas clara que apoie a evolução contínua do time.
Principais Atividades: Reestruturação de indicadores com foco em profissionalização

Reformulação dos indicadores, definindo objetivo, responsável e periodicidade de cada um, com foco na utilidade para a tomada de decisão

Proposição de novos indicadores adequados ao contexto da empresa, voltados à qualidade e à evolução da execução comercial;

Apoio à aplicação de boas práticas de venda, como o SPIN Selling, na condução das reuniões comerciais, por exemplo, perguntas de implicação e identificação de necessidades implícitas do Cliente

Entregável de Valor: estrutura de indicadores reformulada e profissionalizada, com métricas claras, responsáveis definidos e periodicidade de acompanhamento estabelecida.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 32 -->

![](GoogleShape989p56.jpg)

Etapa 10 - Plano de Implementação
Semanas 11
Objetivo Estratégico: estruturar um plano claro e priorizado para implementação das soluções propostas, garantindo alinhamento entre as equipes e orientação para a execução das iniciativas.
Principais Atividades: Roadmap de Implementação

Consolidação das iniciativas e soluções definidas ao longo do projeto;

Organização das ações em uma sequência lógica de implementação a partir de Diagrama de Gantt;

Desenvolvimento de planos de ação (Initiative Charter) para as diferentes soluções propostas;

Entregável de Valor: Initiative Charters e Roadmap estruturado com as iniciativas priorizadas, facilitando o acompanhamento das entregas e a implementação das melhorias.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 33 -->

![](GoogleShape1005p57.jpg)

Etapa 10 - Plano de Implementação

Entrega: Initiative Charter

![](GoogleShape1002p57.jpg)
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 34 -->

![](GoogleShape1028p58.jpg)

Etapa 11 - Documentação Final
Semana 12
Objetivo Estratégico: consolidar todo o estudo e as entregas realizadas em um formato de fácil acesso e disseminação para a equipe da T4S.
Principais Atividades:

Estruturação de uma documentação executiva contendo as principais entregas e análises do projeto de forma enxuta;

Criação de um Hub Comercial centralizando a governança da área comercial, incluindo ritos, papéis, métricas, boas práticas, metodologias e outros fatores de interesse da equipe da T4S.

Entregável de Valor: documentação executiva e site personalizado para a T4S.
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 35 -->

![](GoogleShape1044p59.jpg)

Etapa 11 - Documentação Final
Semana 12

Entregável de Valor:  Hub Comercial

![](GoogleShape1045p59.jpg)
Link para o Site de Exemplo
Gestão Empresarial e Consultoria - Poli Júnior

### Notes:

<!-- Slide number: 36 -->

![](GoogleShape1067p60.jpg)

Equipe Dedicada ao Projeto e Parceria
2 Consultores por 12 semanas
Graduandos Engenheiros Politécnicos da USP da área de Gestão Empresarial e Consultoria da Poli Júnior

1 Coordenador
Membro sênior de projetos da área na empresa
Como será nossa parceria?
Serão realizados reports semanais entre os stakeholders e a equipe para alinhamentos sobre os pontos de atuação e revisão dos resultados;
Os stakeholders colaboram facilitando os insumos necessários (como acesso a documentos e contatos) e com a validação das entregas;
Serão realizadas constantes consultas de experiência e satisfação no decorrer da execução e após sua implementação.
A Poli Júnior se propõe a realizar termos aditivos para contratação de serviços adicionais.

### Notes:

<!-- Slide number: 37 -->

Cases de Sucesso

![](GoogleShape1078p61.jpg)

### Notes:

<!-- Slide number: 38 -->
PROBLEMA
SOLUÇÃO
Grupo EPR

Performance & Governança
O Grupo EPR possui verba anual destinada à inovação, porém sua gestão ocorria de forma descentralizada e pouco estruturada. Cada unidade conduzia iniciativas de maneira independente, sem processos, ritos ou diretrizes comuns, gerando retrabalho, repetição de erros e baixa eficiência no uso dos recursos. Além disso, a ausência de uma área responsável pela coordenação reduzia a visibilidade sobre os projetos e dificultava o acompanhamento estratégico, e a empresa ainda enfrentava o risco de penalidades tarifárias.
A equipe estruturou do zero a área de Inovação do Grupo  EPR, definindo escopo, governança e ritos de funcionamento da área. Foram mapeados e organizados os macro e microprocessos de inovação, estabelecendo fluxos claros para desenvolvimento e acompanhamento das iniciativas, em conjunto com a sponsor do projeto. Além disso, foram realizados estudos de potenciais parceiros e investidores, ampliando as possibilidades de conexão da EPR com o ecossistema de inovação.

.

![](GoogleShape1120p62.jpg)
IMPACTO

A estruturação da área permitiu maior alinhamento e comunicação entre as unidades, reduzindo inconsistências e retrabalhos nas iniciativas de inovação. Como resultado, a empresa fortaleceu seu posicionamento como organização inovadora, além de promover maior organização interna e eficiência na gestão das iniciativas, contribuindo para o desenvolvimento estratégico da companhia.

### Notes:

<!-- Slide number: 39 -->

![](GoogleShape1163p63.jpg)

Proposta Comercial
Proposta Comercial

![](GoogleShape1162p63.jpg)

EQUIPE
DURAÇÃO
INVESTIMENTO

2 Consultores
1 Coordenador

R$ 56.160,00
12 semanas
Cartão, boleto ou transferência. Parcelamento em até 5x.
Pagamento:

### Notes:

<!-- Slide number: 40 -->

![](GoogleShape1206p64.jpg)

Proposta Comercial
Proposta Comercial

![](GoogleShape1205p64.jpg)
15% de desconto
Assinatura até 29/06/2026

EQUIPE
DURAÇÃO
INVESTIMENTO

2 Consultores
1 Coordenador

R$ 47.736,00
12 semanas
Cartão, boleto ou transferência. Parcelamento em até 5x.*Em caso de assinatura até 29/06/2026
Pagamento:

### Notes:

<!-- Slide number: 41 -->

![](GoogleShape1217p65.jpg)

Esclarecimentos Comerciais
Nossa minuta padrão contratual - que engloba questões jurídicas como garantias, deveres e responsabilidades, entre outras informações - está disponível neste link.

O CNAE (Classificação Nacional de Atividades Econômicas) da Poli Júnior, a empresa júnior da Escola Politécnica da USP, é 7112-0/00 - Serviços de Engenharia. Essa classificação engloba atividades como consultoria, projetos e outros serviços relacionados à engenharia.

Pareceres: Nossa proposta está em conformidade com a legislação aplicável e nos comprometemos com a qualidade do projeto - assim como para todos nossos Clientes. Estamos disponíveis para tiragens de dúvidas durante todo o contato (dados ao final do documento).

Em caso de necessidade de números de contas bancárias, estatuto social, cartão CNPJ, Inscrição Municipal ou outras questões, entrar em contato.

Nosso valor engloba todos os custos estabelecidos pelo projeto, incluindo impostos.

### Notes:

<!-- Slide number: 42 -->

![](GoogleShape1229p66.jpg)

Esclarecimentos Comerciais
Para esta proposta comercial, são válidas as seguintes condições:

No decorrer do projeto, serão realizadas reuniões entre a equipe da Poli Júnior e o Cliente para coleta de dados, discussão do andamento do projeto e apresentação de resultados – o Cliente se compromete em ter disponibilidade para tais encontros e troca de informações;
As atividades têm início e fim a partir das datas que serão estabelecidas no contrato, documento elaborado mediante a aprovação desta proposta por ambas as partes, Poli Júnior e Cliente;
As informações contidas nesta proposta são confidenciais, não devendo ser utilizadas ou apresentadas por qualquer outra pessoa sem o consentimento de ambas as partes;
A equipe da Poli Júnior não trabalhará durante as semanas de prova da Escola Politécnica;
Essa proposta comercial possui validade de 1 mês a contar da data de sua apresentação 17/06/2026;
O projeto poderá ser iniciado 15 dias úteis após a assinatura do contrato;
A contratante deve agir com respeito a todos os envolvidos no serviço em questão, sob pena de rescisão do contrato;
Serão realizadas coletas de satisfação em relação ao projeto no decorrer da execução e ao final do projeto;
No caso de atraso no pagamento de até 10 dias úteis, o projeto será congelado, com retomada prevista em até 5 dias úteis após o devido pagamento ter sido realizado.

### Notes:

<!-- Slide number: 43 -->

![](GoogleShape1310p67.jpg)

Nosso Contato e Próximos Passos

Gabriel Beyruti

Enzo Rêgo

Ulisses Fontoura

Coordenador de Negócios

Diretor Comercial
Coordenador de Tecnologia

gabriel.beyruti@polijunior.com.br

enzo.rego@polijunior.com.br

ulisses.fontoura@polijunior.com.br

11 97561-6380

21  99925-6405

62  98181-0051

Próximos Passos:
Aprovação Verbal até 24/06
Validação jurídica da minuta contratual
Assinatura do contrato pelos representantes até 29/06

### Notes:
