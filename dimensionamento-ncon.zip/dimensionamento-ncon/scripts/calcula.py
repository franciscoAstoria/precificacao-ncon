#!/usr/bin/env python3
"""Dimensionamento NCon: semanas por etapa x analistas, com selo de confianca.

Exemplos:
  python calcula.py --portfolio gp --reunioes 20 --analistas 2
  python calcula.py --portfolio gp --processos 20-30 --opcionais-sem 2
  python calcula.py --portfolio pm --modo benchmark --benchmarks 12 --nicho
  python calcula.py --portfolio ai-scan --reunioes 11-20 --dados dispersos
  python calcula.py --portfolio gto --reunioes 20 --pg-semanas 4

Faixas ("20-30") rodam a formula nos dois extremos, em vez de chutar um ponto.
Saida em JSON. So biblioteca padrao. Os parametros abaixo vem das conversas de
16/11/2026; o selo de cada etapa diz o quanto confiar (F fato, R regra de 1 voz,
A em aberto). Ver SKILL.md.
"""
import argparse
import json
import math

PARAM = {
    "reunioes_por_analista_semana": 4,    # [F]
    "processos_por_reuniao": 3,           # [R]
    "benchmarks_por_analista_semana": 3,  # [R]
    "imersao_gp": 1,                      # [R]
    "imersao_gto": 2,                     # decisao do time 16/11 (a validar)
    "imersao_ai_scan": 2,                 # decisao do time 16/11 (a validar)
    "marcacao_extra_nicho": 1,            # [A] ponto de partida do time 16/11
    "ai_scan_base": 6,                    # decisao do time 16/11 (a validar)
    "ai_scan_max": 8,
    "ai_scan_limiar_mapeamento": 3,       # [A] limiar provisorio, a validar
    "pop_alerta_processos": 200,          # [A] sem limiar definido; maior case = Motiva, 218
    "horas_por_semana": (15, 20),         # decisao do time 16/11 (a validar)
}

# Faixa historica do banco de propostas (semanas). None = sem banda.
BANDA = {"gp": (6, 13), "pm": (5, 7), "pg": (7, 15), "pd": (8, 8), "ai-scan": (6, 8), "gto": None}


def faixa(txt):
    a, _, b = str(txt).partition("-")
    lo = int(a)
    hi = int(b) if b else lo
    return min(lo, hi), max(lo, hi)


def soma(etapas):
    return sum(e["semanas"] for e in etapas)


def et(nome, semanas, selo, nota=""):
    d = {"etapa": nome, "semanas": semanas, "selo": selo}
    if nota:
        d["nota"] = nota
    return d


def resumo(total, analistas):
    sa = total * analistas
    h0, h1 = PARAM["horas_por_semana"]
    return {"semanas": total, "analistas": analistas, "sa": sa, "horas_aprox": [sa * h0, sa * h1]}


def gp_like(reunioes, an, imersao, nicho, pg_semanas=None):
    m = math.ceil(reunioes / (PARAM["reunioes_por_analista_semana"] * an))
    garg = max(1, m // 2)
    doc = max(1, m - garg)
    pad = [et("Imersão", imersao, "R"), et("Mapeamento AS IS", m, "F", f"{reunioes} reuniões ÷ (4 × {an})")]
    if nicho:
        pad.append(et("Marcação extra (setor nichado ou sem contatos)", PARAM["marcacao_extra_nicho"], "A", "ponto de partida do time"))
    pad += [
        et("Gargalos", garg, "A", "regra do Bastos: máx(1, ⌊map/2⌋)"),
        et("Documentação (TO BE + POP)", doc, "A", "regra do Bastos: map − gargalos; POP = 1 dentro dela"),
    ]
    teto = [e for e in pad if e["etapa"] not in ("Gargalos", "Documentação (TO BE + POP)")]
    teto += [
        et("Soluções (gargalos)", 2, "A", "regra do áudio"),
        et("TO BE", max(1, m - 1), "A", "regra do áudio: map − 1"),
        et("POP", 1, "R"),
    ]
    if pg_semanas is not None:
        pg = et("P&G (sem diagnóstico, já contado na imersão)", pg_semanas, "A", "informado pelo CN, sem regra validada")
        pad.append(pg)
        teto.append(pg)
    return m, pad, teto


# ---- catalogo de etapas (orquestrador-ncon/references/catalogo-etapas.md) ----
def _e(id_, nome, port, sem, selo="", calculo=""):
    return {"id": id_, "nome": nome, "portfolio": port, "semanas": sem, "semana_inicio": None, "semana_fim": None,
            "compartilha_semana_com": None, "opcional": False, "calculo": calculo, "selo": selo}


def catalogar(portfolio, etapas, doc_final=True):
    """Converte as etapas do script em ids do catalogo e calcula o calendario.
    Etapa com semanas = 0 divide a semana com a indicada em compartilha_semana_com."""
    port = {"gp": "GP", "gto": "GP", "pm": "PM", "ai-scan": "AI Scan"}[portfolio]
    out = []
    for x in etapas:
        n, w, selo, nota = x["etapa"], x["semanas"], x["selo"], x.get("nota", "")
        if n == "Imersão":
            out.append(_e({"gp": "gp.imersao", "gto": "gp.imersao", "pm": "pm.imersao", "ai-scan": "ai.imersao"}[portfolio], n, port, w, selo, nota))
        elif n == "Mapeamento AS IS":
            out.append(_e("gp.asis", n, port, w, selo, nota))
        elif n.startswith("Marcação extra") and portfolio != "pm":
            out[-1]["semanas"] += w
            out[-1]["calculo"] = (out[-1]["calculo"] + f" + {w} sem de marcação extra").strip()
        elif n.startswith("Marcação extra"):
            out[-1]["semanas"] += w
            out[-1]["calculo"] = (out[-1]["calculo"] + f" + {w} sem de marcação extra").strip()
        elif n in ("Gargalos", "Soluções (gargalos)"):
            out.append(_e("gp.gargalos", n, port, w, selo, nota))
        elif n.startswith("Documentação (TO BE + POP)"):
            out.append(_e("gp.tobe", "TO BE", port, w - 1, selo, "documentação − 1 semana de POP"))
            out.append(_e("gp.pop", "POP", port, 1, "R", "POP = 1 semana"))
        elif n == "TO BE":
            out.append(_e("gp.tobe", n, port, w, selo, nota))
        elif n == "POP":
            out.append(_e("gp.pop", n, port, w, selo, nota))
        elif n.startswith("P&G"):
            out.append(_e("pg.outro:modulos-pg", n, "P&G", w, selo, nota))
        elif n == "Rodagem da terceirizada":
            out.append(_e("pm.rodagem", n, port, w, selo, nota))
        elif n == "Análise":
            out.append(_e("pm.analise", n, port, w, selo, nota))
        elif n == "Marcação e entrevistas de benchmark":
            out.append(_e("pm.benchmark", n, port, w, selo, nota))
        elif n == "Versão e ajuste":
            out.append(_e("pm.outro:versao-e-ajuste", n, port, w, selo, nota))
        elif n == "Documentação final":
            out.append(_e("pm.doc", n, port, w, selo, nota))
        elif n.startswith("Demais etapas"):
            out.append(_e("ai.discovery", "Discovery e casos de uso de IA", port, w, selo, nota))
        else:
            out.append(_e(f"{portfolio}.outro:{n.lower().replace(' ', '-')}", n, port, w, selo, nota))
    if doc_final and portfolio in ("gp", "gto", "ai-scan"):
        ultima = out[-1]["id"]
        d = _e("gp.doc" if portfolio != "ai-scan" else "ai.doc", "Documentação Final", port, 0, "R",
               "divide a última semana com " + ultima)
        d["compartilha_semana_com"] = ultima
        out.append(d)
    cur = 1
    for x in out:
        if x["semanas"] > 0:
            x["semana_inicio"], x["semana_fim"] = cur, cur + x["semanas"] - 1
            cur += x["semanas"]
    por_id = {x["id"]: x for x in out}
    for i, x in enumerate(out):
        if x["semanas"] == 0:
            alvo = por_id.get(x["compartilha_semana_com"])
            if x["id"] == "gp.tobe":  # TO BE de 0 sem divide a semana do POP
                alvo = por_id["gp.pop"]; x["compartilha_semana_com"] = "gp.pop"
            ref = alvo["semana_fim"] if alvo else cur - 1
            x["semana_inicio"] = x["semana_fim"] = ref
    return out


def cenario_gp(args, reunioes, gto=False):
    imersao = PARAM["imersao_gto"] if gto else PARAM["imersao_gp"]
    m, pad, teto = gp_like(reunioes, args.analistas, imersao, args.nicho, args.pg_semanas if gto else None)
    tp, tt = soma(pad), soma(teto)
    alertas = []
    banda = BANDA["gto" if gto else "gp"]
    if banda:
        if tp < banda[0] or tp > banda[1]:
            alertas.append(f"Padrão de {tp} sem fora da banda do banco ({banda[0]} a {banda[1]}). Avise o CP, não corrija sozinho.")
        if tt > banda[1]:
            alertas.append(f"Teto de {tt} sem acima da banda do banco ({banda[0]} a {banda[1]}).")
    if gto:
        alertas.append("GTO sem banda no banco [A]. Referências: Tenda GP+P&G 2 × 9; Mantiqueira 10 sem × 3 consultores + 26 sem × 1.")
        if args.pg_semanas is None:
            alertas.append("Semanas de P&G não informadas: o total cobre só o GP + imersão de 2 sem. Peça ao CP.")
    return {
        "mapeamento_semanas": m,
        "etapas_padrao": pad,
        "etapas_teto": teto,
        "etapas_catalogo_padrao": catalogar("gto" if gto else "gp", pad),
        "etapas_catalogo_teto": catalogar("gto" if gto else "gp", teto),
        "opcao_A_nucleo": {"padrao": resumo(tp, args.analistas), "teto": resumo(tt, args.analistas)},
        "opcao_B_com_opcionais": {"padrao": resumo(tp + args.opcionais_sem, args.analistas),
                                  "teto": resumo(tt + args.opcionais_sem, args.analistas),
                                  "opcionais_sem": args.opcionais_sem},
        "alertas": alertas,
    }


def cenario_pm(args, n_bench):
    an = args.analistas
    alertas = []
    if args.modo == "terceirizada":
        pad = [et("Imersão", 1, "R"), et("Rodagem da terceirizada", 3, "R", "3 a 4 sem conforme a terceirizada"),
               et("Análise", 1, "R"), et("Documentação final", 1, "R")]
        tp, tt = soma(pad), soma(pad) + 1
        alertas.append("Prazo dominado pela capacidade da terceirizada: se ela pedir 4 sem, o total vai a 7.")
    else:
        sb = math.ceil(n_bench / (PARAM["benchmarks_por_analista_semana"] * an))
        pad = [et("Imersão", 1, "R"),
               et("Marcação e entrevistas de benchmark", sb, "R", f"{n_bench} benchmarks ÷ (3 × {an})")]
        if args.nicho:
            pad.append(et("Marcação extra (setor nichado ou sem contatos)", PARAM["marcacao_extra_nicho"], "A", "ponto de partida do time"))
        pad += [et("Versão e ajuste", 1, "R"), et("Documentação final", 1, "R")]
        tp = tt = soma(pad)
    lo, hi = BANDA["pm"]
    if tp < lo or tp > hi:
        alertas.append(f"Padrão de {tp} sem fora da banda do banco ({lo} a {hi}). Avise o CP, não corrija sozinho.")
    return {
        "etapas_padrao": pad,
        "etapas_catalogo_padrao": catalogar("pm", pad),
        "opcao_A_nucleo": {"padrao": resumo(tp, an), "teto": resumo(tt, an)},
        "opcao_B_com_opcionais": {"padrao": resumo(tp + args.opcionais_sem, an),
                                  "teto": resumo(tt + args.opcionais_sem, an),
                                  "opcionais_sem": args.opcionais_sem},
        "alertas": alertas,
    }


def cenario_ai_scan(args, reunioes):
    an = args.analistas
    m = math.ceil(reunioes / (PARAM["reunioes_por_analista_semana"] * an))
    total = PARAM["ai_scan_base"]
    drivers = []
    if m >= PARAM["ai_scan_limiar_mapeamento"]:
        total += 1
        drivers.append(f"mapeamento de {m} sem na conta do GP (≥ {PARAM['ai_scan_limiar_mapeamento']}): +1 sem")
    if args.dados == "dispersos":
        total += 1
        drivers.append("dados do cliente dispersos ou sem dono: +1 sem")
    total = min(total, PARAM["ai_scan_max"])
    alertas = ["Regra de 6 a 8 sem decidida em 16/11 e ainda sem validação de CP; o limiar do mapeamento é provisório [A]."]
    if args.dados == "parciais":
        alertas.append("Dados parciais contam +0 por ora [A]: confirme com o CP se parcial já pesa.")
    if m + 1 > total - 3:
        alertas.append(f"AS IS de AI Scan (GP + 1 = {m + 1} sem) ocupa quase todo o prazo restante ({total - 2} sem após a imersão): "
                       "confira se casos de uso, priorização e roadmap cabem.")
    alertas.append("O preço fixo atual de 2 sem × 2 analistas não vale para este formato: avise a precificacao-ncon.")
    pad = [et("Imersão", PARAM["imersao_ai_scan"], "R", "decisão do time 16/11"),
           et("Demais etapas (AS IS, casos de uso, priorização e roadmap)", total - PARAM["imersao_ai_scan"], "A",
              "divisão interna ainda não validada")]
    return {
        "mapeamento_gp_equivalente_semanas": m,
        "decididores": drivers or ["base de 6 sem"],
        "etapas_padrao": pad,
        "etapas_catalogo_padrao": catalogar("ai-scan", pad),
        "opcao_A_nucleo": {"padrao": resumo(total, an), "teto": resumo(PARAM["ai_scan_max"], an)},
        "nota_equipe": "analistas = consultores; a equipe é N consultores + 1 coordenador (não há Arquiteto de IA)",
        "alertas": alertas,
    }


def main():
    ap = argparse.ArgumentParser(description="Dimensionamento NCon")
    ap.add_argument("--portfolio", required=True, choices=["gp", "pm", "ai-scan", "gto", "pg", "pd"])
    ap.add_argument("--reunioes", help="nº de reuniões de mapeamento, ou faixa 'a-b'")
    ap.add_argument("--processos", help="nº de processos, ou faixa 'a-b' (÷ 3 por reunião)")
    ap.add_argument("--benchmarks", help="nº de benchmarks (PM), ou faixa 'a-b'")
    ap.add_argument("--modo", choices=["terceirizada", "benchmark"], default="terceirizada")
    ap.add_argument("--analistas", type=int, default=2)
    ap.add_argument("--nicho", action="store_true", help="setor nichado ou cliente sem base de contatos")
    ap.add_argument("--dados", choices=["organizados", "parciais", "dispersos"], default="organizados")
    ap.add_argument("--opcionais-sem", type=int, default=0, help="semanas dos opcionais (opção B)")
    ap.add_argument("--pg-semanas", type=int, default=None, help="semanas de P&G no GTO, sem o diagnóstico")
    args = ap.parse_args()

    if args.portfolio in ("pg", "pd"):
        refs = {"pg": "T4S 2 × 12, FS 2 × 7 e 2 × 15 (sa = soma dos módulos contratados)", "pd": "Arauco 2 × 8 (n=1)"}
        print(json.dumps({"portfolio": args.portfolio, "resultado": None,
                          "alerta": "Sem regra validada [A]. Não invente número: liste os direcionadores e pergunte ao CP.",
                          "referencia_banco": refs[args.portfolio], "banda": BANDA[args.portfolio]},
                         ensure_ascii=False, indent=2))
        return

    if args.portfolio == "pm" and args.modo == "benchmark":
        base = args.benchmarks
    else:
        base = args.reunioes
        if base is None and args.processos is not None:
            lo, hi = faixa(args.processos)
            f = PARAM["processos_por_reuniao"]
            base = f"{math.ceil(lo / f)}-{math.ceil(hi / f)}"
    if base is None and not (args.portfolio == "pm" and args.modo == "terceirizada"):
        ap.error("informe --reunioes, --processos ou --benchmarks (um número ou faixa)")

    lo, hi = faixa(base if base is not None else 0)
    fn = {"gp": lambda a, n: cenario_gp(a, n), "gto": lambda a, n: cenario_gp(a, n, gto=True),
          "pm": cenario_pm, "ai-scan": cenario_ai_scan}[args.portfolio]

    out = {"portfolio": args.portfolio, "entrada": {k: v for k, v in vars(args).items() if v not in (None, False)}}
    out["menor_extremo" if lo != hi else "cenario"] = fn(args, lo)
    if lo != hi:
        out["maior_extremo"] = fn(args, hi)

    notas = []
    if args.analistas != 2:
        notas.append("Equipe padrão é 2 analistas [F]; 3 só com prazo apertado ou projeto grande [R]; 1 é raro.")
    if args.processos is not None and faixa(args.processos)[1] >= PARAM["pop_alerta_processos"]:
        notas.append("Volume perto do maior case conhecido (Motiva, 218 processos): POP pode pedir 2 sem. Sem limiar definido [A]: pergunte ao CP.")
    if notas:
        out["alertas_gerais"] = notas
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
