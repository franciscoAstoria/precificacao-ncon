# Pop-ups do dimensionamento NCon

Duas seções. A **seção 1** é o que o CN responde a cada proposta. A **seção 2** é o que o time e os CPs respondem para calibrar as regras; não vai para o CN. Em cada opção, o texto segue o padrão **parâmetro · escolha se · exemplo**. Exemplos de propostas só quando o escopo é conhecido; senão, escreva "confirmar". Tudo que é julgamento do time leva "(a validar)".

## Seção 1. Por proposta (CN)

Monte um pop-up por vez, com no máximo 4 perguntas. Pule o que o Fathom ou o CN já responderam.

### Pop-ups de contexto (antes da ficha, só quando a ferramenta não resolver sozinha)

- **Qual deal é o do lead?** (Pipedrive devolveu mais de um candidato). Uma opção por deal: título · estágio · valor · data de criação. Recomendado: o aberto mais recente com o mesmo nome de empresa.
- **Quais reuniões do Fathom usar?** (multisseleção, até 3). Uma opção por reunião: título · data · convidados. Recomendado: a AT e o aprofundamento do cliente. Em backtest, só as anteriores à proposta.
- **Gastar 1 crédito do Apollo para enriquecer [domínio]?** Antes, escreva em texto: "Enriching [domínio] will consume 1 credit (no charge if not found). Do you want to proceed?" Opções: Sim, enriquecer (Recomendado se o Pipedrive não trouxe faturamento e setor) · Não, usar o Pipedrive e uma faixa do CN · Informar o faturamento aqui.

### Pop-up 0. Portfólio (sempre; a skill sugere, o CN decide)

Antes do pop-up, mostre em texto a sugestão, os 2 ou 3 trechos da transcrição ou da ata que a sustentam e a pasta do Drive que serve de exemplo. A pergunta cita a sugestão: "Qual portfólio seguir para [Empresa]? A sugestão é [X]." Cabem 4 opções: a sugerida primeiro, com "(Recomendado)", depois as duas mais plausíveis; os demais (PD e P&G inclusive, que são [A]) entram por "Outro". Se o CN trocar a sugestão, registre o motivo.

- **GP.** Mapeamento e melhoria de processos de uma ou mais áreas. Escolha se: a dor é processo, gargalo, retrabalho ou falta de padrão. Exemplo: Tenda GP (Drive: "2026 GP 33. Construtora Tenda").
- **PM.** Pesquisa de mercado ou benchmarking. Escolha se: o produto é uma decisão sobre mercado, território ou demanda. Exemplo: Mitt Incorporadora, 1 × 6 (Drive: "2025 PM 14. Mitt Incorporadora").
- **GTO.** GP + P&G. Escolha se: além do processo, há papéis, ritos ou indicadores a redesenhar. Escopo aberto [A]. Exemplo: metodologia em "2026 INTERNO 2. Unificação GP + P&G".
- **AI Scan.** Mapeia onde dados e IA entram e prepara projeto para o Núcleo de Dados. Escolha se: o cliente quer saber onde automatizar. Exemplo: confirmar (sem pasta própria no Drive).
- **P&G (Outro).** Papéis, ritos, indicadores e cultura, sem mapeamento. Escolha se: o processo já está padronizado e falta a gestão em volta. Sem regra [A].
- **PD (Outro).** Descoberta de produto com usuários. Escolha se: o cliente tem uma ideia de produto ou software a validar. Sem regra [A].

### Pop-up GP (também usado no GTO, em parte)

1. **Qual o volume do mapeamento?** (faixas de reuniões; ≈ 3 processos por reunião)
   - **Até 10 reuniões** (até ~30 processos). Escolha se: 1 área pequena.
   - **11 a 20 reuniões** (~33 a 60 processos). Escolha se: 1 área média. Exemplo: Tenda GP, 20 reuniões, 7 entrevistados.
   - **21 a 30 reuniões** (~63 a 90 processos). Escolha se: 2 ou 3 áreas.
   - **Mais de 30 reuniões.** Escolha se: empresa grande ou várias áreas. Roda com 3 analistas e alerta o CP.
2. **Qual o prazo e o tamanho da equipe?**
   - **Sem prazo fixo, 2 analistas.** Equipe padrão [F]; 13 de 16 cenários do banco.
   - **Prazo apertado, 3 analistas.** Escolha se: o cliente tem data (evento, orçamento do ano) [R]. Exemplo: QuintoAndar, 3 × 6.
   - **Projeto grande, 3 analistas.** Escolha se: mais de 30 reuniões [R].
   - **1 analista.** Raro; escolha se: escopo muito pequeno.
3. **Marcar as reuniões depende de gente de fora ou de setor difícil?**
   - **Não, entrevistados internos e acessíveis.** Sem marcação extra.
   - **Setor nichado.** +1 semana de marcação (ponto de partida, a validar). Exemplo: Jacto, "muito difícil marcar".
   - **Cliente não fornece contatos.** +1 semana (prospecção por LinkedIn e e-mail).
   - **Os dois.** +1 semana por ora [A]; avise o CP.
4. **Quais opcionais entram na opção B?** (multisseleção)
   - **Manual conversacional (chatbot).** +1 semana. Exemplo: Tenda GP.
   - **Documentação final (repositório ou site).** +1 semana. Exemplo: Tenda GP.
   - **Cronoanálise, VSM, A3 ou RACI.** Sem parâmetro [A]: o script soma o que o CP informar.
   - **Nenhum.** Opção B = opção A.

### Pop-up PM

1. **Como a pesquisa é rodada?**
   - **Terceirizada com questionário.** 6 semanas (3 de rodagem, 3 a 4 conforme a terceirizada) [R]. Exemplos: Tenda PM 2 × 6, Mitt 1 × 6.
   - **Benchmarking pelo time.** 3 reuniões por analista por semana [R]. Exemplo: Basalto, 28 benchmarkings nichados.
2. **Quantos benchmarks?** (só se benchmarking)
   - **Até 8.** · **9 a 15** (exemplo do áudio: 12 benchmarks com 2 analistas = 5 semanas). · **16 a 28.** · **Mais de 28** (alerta o CP).
3. **O cliente fornece contatos, e o setor é nichado?** Mesmas opções da pergunta 3 do pop-up GP (+1 semana de marcação).
4. **Opcionais?** Hoje sem parâmetro [A]; pule se o CN não citar nenhum.

### Pop-up AI Scan (6 a 8 semanas, a validar)

1. **Qual o volume do mapeamento?** Mesmas faixas do pop-up GP. Mapeamento ≥ 3 semanas na conta do GP soma +1 semana.
2. **Como estão os dados do cliente?**
   - **Organizados e acessíveis.** +0. Escolha se: há base única, dono definido e histórico.
   - **Parciais.** +0 por ora [A]; confirme com o CP se parcial já pesa.
   - **Dispersos ou sem dono.** +1 semana. Escolha se: planilhas soltas, vários sistemas sem integração.
3. **Qual a equipe?** (consultores; o template soma 1 Arquiteto de IA e 1 coordenador) 2 consultores como padrão [F]; 3 só com prazo apertado [R].

### Pop-up GTO (além das perguntas do pop-up GP)

1. **Quantas semanas de P&G além do diagnóstico?** (o diagnóstico já está na imersão única de 2 semanas)
   - **2 semanas.** · **4 semanas.** · **6 semanas.** · **8 ou mais.** Sem regra validada [A]: o número vale como hipótese do CN e vai marcado. Referências sem banda: Tenda GP+P&G 2 × 9; Mantiqueira, 10 sem × 3 consultores + 26 sem × 1.
2. **O escopo é fechado por etapas ou aberto por entregável?** Fechado: soma de etapas. Aberto: peça o entregável final e as fases ao CP (Mantiqueira, em duas fases).

### PD e P&G

Sem regra: não calcule. Liste os direcionadores e pergunte ao CP (JL para PD).
- **PD:** nº de hipóteses, segmentos de usuário, entrevistas com usuários, stakeholders, complexidade técnica, protótipo. Referência: Arauco 2 × 8.
- **P&G:** módulos contratados dentre os 7. Referências: T4S 2 × 12, FS 2 × 7 e 2 × 15.

### Pop-ups de validação (depois do cálculo, uma chamada de até 4 perguntas)

Mostre antes, em texto: o escopo núcleo × opcionais (com as pastas do Drive que serviram de base), a tabela de etapas com selos e a faixa padrão a teto. Cada pergunta cita o número que está sendo validado. Toda resposta diferente da primeira opção vira o "motivo do ajuste" do log.

1. **Escopo.** "Opção B: [etapas], com [opcionais]. De acordo?"
   - **De acordo (Recomendado).** Segue com o escopo mostrado.
   - **Tirar opcionais.** Escolha se: o cliente quer o menor preço ou prazo.
   - **Incluir outro opcional.** Escolha se: a transcrição citou algo que ficou de fora (chatbot, documentação final, cronoanálise).
   - **Trocar o escopo.** Escolha se: a base do Drive mostra um escopo mais parecido com o lead.
2. **Dimensionamento.** "[Portfólio], [M] analistas × [N] semanas (teto: [T]). De acordo?"
   - **Padrão (Recomendado).** Número da conta, sem folga.
   - **Usar o teto.** Escolha se: projeto resolutivo, cliente com muitas áreas ou prazo flexível.
   - **Ajustar a equipe.** Escolha se: o cliente tem prazo (3 analistas) ou o escopo é muito pequeno (1).
   - **Ajustar as semanas.** O CN informa o número e o motivo; o script recalcula o sa.
3. **Opções a montar** (multisseleção).
   - **A. Só o núcleo.** Sempre.
   - **B. Núcleo + opcionais (Recomendado).** Se houver opcionais citados ou aplicáveis.
   - **C. Fixo + success fee.** Só se o filtro passar: GP, P&G, GTO, PD ou AI Scan (nunca PM), indicador que o cliente já mede e decisor presente. Se não passar, não mostre a opção e diga por quê.
4. **Próximo passo.**
   - **Seguir para a precificação (Recomendado).** Chama a `precificacao-ncon` com tudo.
   - **Seguir com success fee.** Chama a `success-fee`, que depois chama a `precificacao-ncon`.
   - **Ajustar antes.** Recalcula e repete só a pergunta alterada.
   - **Parar aqui.** Entrega só o dimensionamento.

Se o CN ajustar algo, recalcule no script, mostre só o que mudou e repita a pergunta alterada até o "De acordo".

## Seção 2. Calibração (time e CPs, fora do fluxo do CN)

Status em 16/11/2026, com o que o time respondeu. Itens sem decisão seguem [A].

| # | Pergunta | Opções | Status |
|---|---|---|---|
| 1 | Pós-mapeamento do GP: qual regra é o padrão? | Bastos padrão e áudio teto · só áudio · só Bastos | **Decidido:** Bastos padrão, áudio teto. "Documentação" do Bastos = TO BE + POP ainda a confirmar com ele |
| 2 | AI Scan: tamanho padrão? | 2 sem · 8 sem · dois tamanhos | **Decidido:** 6 a 8 semanas com 2 de imersão; decidem o nº de processos e os dados do cliente |
| 3 | GTO: como somar GP e P&G? | imersão única de 1 sem · de 2 sem · soma simples · por entregável | **Decidido:** imersão única de 2 semanas |
| 4 | Horas por semana por analista | até 10 h · 10 a 15 h · 15 a 20 h · mais de 20 h | **Decidido:** 15 a 20 h (a validar) |
| 5 | Setor nichado ou sem contatos: semanas extras | +1 · +2 · +50% da marcação · só alerta | **Decidido:** +1 semana (ponto de partida) |
| 6 | Buffer explícito no dimensionamento | sem buffer · 10 a 20% · 10 a 20% ou 25 a 50% por risco · só se o CN pedir | Sem decisão: segue sem buffer |
| 7 | POP passa a 2 sem a partir de quantos processos | 100 · 200 · 500 · 1.000 | Sem decisão: segue 1 semana, alerta a partir de 200 |
| 8 | Semanas dos opcionais (cronoanálise, VSM, A3, RACI) | por opcional · por volume · caso a caso | Aberta |
| 9 | Produtividade de TO BE e POP (processos por analista por semana) | a levantar com os CPs | Aberta |
| 10 | Dados "parciais" no AI Scan contam +1? E o limiar de 3 semanas de mapeamento? | sim · não | Aberta |
| 11 | P&G e PD: quem tem parâmetros (JL)? | a levantar | Aberta |
| 12 | O orador do áudio é o Bastos? (se for, o 4 reuniões por analista vira regra de 1 voz) | sim · não | Aberta |
| 13 | Tenda GP+P&G 2 × 9 do banco e Tenda GP 2 × 9 do v0.2: mesma proposta? | sim · não | Aberta |
